import {t,type TranslationKey} from "./i18n";
import {useState,useEffect} from 'react';
import {newLine, type Quote, type CostLine} from '../shared/model';
import {lineAmount} from '../shared/calculate';
import {money} from './api';
function AmountInput({value,onChange,...props}:any){
 const [blank,setBlank]=useState(false);
 useEffect(()=>{if(value!==0)setBlank(false);},[value]);
 return <input {...props} type="number" min="0" value={blank?'':value} onChange={e=>{setBlank(e.target.value==='');onChange(Number(e.target.value));}}/>;
}
const sectionKeys:Record<string,TranslationKey>={"daily": "common.daily.transport", "transport": "common.additional.transport", "guide": "common.accompagnateur.guide.tl.services", "guide-stay": "common.guide.tl.accommodation", "driver-stay": "common.driver.accommodation", "crew-meals": "common.driver.guide.meals", "other": "common.other.shared.costs", "hotel": "common.guest.hotels", "meal": "common.guest.meals", "activity": "common.tickets.activities", "additional": "common.additional.costs.per.participant", "Sewa perlengkapan grup": "common.operational.costs"};
const collective=[
 ['daily','Transport harian','transport','Layanan transport'],
 ['transport','Tambahan transport','operational','Tol / parkir / tunnel / empty run'],
 ['guide','Jasa accompagnateur / guide / TL','guide','Jasa guide / TL'],
 ['guide-stay','Akomodasi guide / TL','operational','Hotel / city tax guide'],
 ['crew-meals','Makan driver & guide','operational','Makan driver / guide'],
 ['other','Biaya bersama lainnya','operational','Biaya bersama lainnya'],
];
const individual=[
 ['hotel','Hotel tamu','hotel','Hotel tamu'],
 ['meal','Makan tamu','meal','Makan tamu'],
 ['activity','Tiket & aktivitas','activity','Tiket / aktivitas'],
 ['additional','Biaya tambahan per peserta','additional','Asuransi / visa / biaya lainnya'],
];
const suggestions:Record<string,string[]>={
 daily:['Airport transfer','Full day service','Half day service','City tour','Transfer antarkota','Transfer stasiun','Transfer resor ski'],
 transport:['Tol','Parkir','Tunnel','Empty run','Ferry kendaraan','Biaya lintas negara','Overtime driver'],
 guide:['Accompagnateur','Tour leader','Local guide','Guide berbahasa Indonesia','Instruktur ski'],
 'guide-stay':['Hotel TL / guide','City tax TL / guide','Breakfast TL / guide','Hotel driver','City tax driver','Hotel driver saat empty run','City tax saat empty run'],
 'crew-meals':['Makan siang driver','Makan malam driver','Makan siang guide / TL','Makan malam guide / TL','Makan siang Swiss','Makan malam Swiss','Air minum tamu'],
 other:['Sewa perlengkapan grup','Biaya operasional','Biaya administrasi'],
 hotel:['Kamar double','Kamar twin','Kamar single','Kamar triple','Extra bed','City tax tamu','Breakfast tamu'],
 meal:['Sarapan','Makan siang','Makan malam','Meal voucher'],
 activity:['Tiket museum','Téléphérique / cable car','Seine cruise','Ski pass','Sewa alat ski','Tiket atraksi','Tiket pertunjukan'],
 additional:['Asuransi perjalanan','Visa','Bagasi tambahan','Tiket kereta','Tiket pesawat','Airport porter','Biaya pribadi lainnya']
};
function ServiceName({value,options,onChange}:{value:string;options:string[];onChange:(value:string)=>void}){
 const [open,setOpen]=useState(false);
 const matches=options.filter(x=>x.toLowerCase().includes(value.toLowerCase()));
 return <div className="ca-service-picker"><input aria-label={t("collectivetable.service.name")} aria-expanded={open} autoComplete="off" value={value} placeholder={t("collectivetable.select.or.enter.a.service")} onFocus={()=>setOpen(true)} onBlur={()=>setOpen(false)} onKeyDown={e=>{if(e.key==='Escape')setOpen(false);}} onChange={e=>{onChange(e.target.value);setOpen(true);}}/>
 {open&&matches.length>0&&<div className="ca-service-options">{matches.map(name=><button key={name} type="button" onMouseDown={e=>e.preventDefault()} onClick={()=>{onChange(name);setOpen(false);}}>{name}</button>)}</div>}</div>;
}
function section(l:CostLine):string {
 // Keep persisted legacy sections intact; combine them only for display.
 if(l.caSection)return l.caSection==='driver-stay'?'guide-stay':l.caSection;
 if(l.side==='individual')return ['hotel','meal','activity'].includes(l.category)?l.category:'additional';
 const name=l.label.toLowerCase();
 if(/hotel|accom|akomodasi|city tax/.test(name)&&/driver|sopir/.test(name))return 'guide-stay';
 if(/hotel|accom|akomodasi|city tax/.test(name)&&/guide|\btl\b/.test(name))return 'guide-stay';
 if(/lunch|dinner|makan|meal|water|air minum/.test(name))return 'crew-meals';
 if(/toll?|park|tunnel|empty run/.test(name))return 'transport';
 if(l.category==='guide')return 'guide';
 return l.category==='transport'?'daily':'other';
}
export function CollectiveTable({quote:q,side='collective',onChange,onEdit}: {quote:Quote;side?:'collective'|'individual';onChange:(lines:CostLine[])=>void;onEdit:(line:CostLine)=>void}) {
 const dates:string[]=[];
 if(q.start&&q.end)for(let t=Date.parse(q.start);t<=Date.parse(q.end)&&dates.length<366;t+=86400000)dates.push(new Date(t).toISOString().slice(0,10));
 const definitions=side==='collective'?collective:individual;
 function fresh(def:string[],date=''):CostLine {return {...newLine(),id:crypto.randomUUID(),side,caSection:def[0],category:def[2] as CostLine['category'],label:'',start:date,end:date,quantity:1,factor:1,currency:q.baseCurrency,basis:def[0]==='hotel'?'room-night':def[0]==='daily'?'vehicle-day':'pax-day',unit:def[0]==='hotel'?'kamar':'unit'};}
 function row(l:CostLine) {
 const update=(patch:Partial<CostLine>)=>onChange(q.lines.map(x=>x.id===l.id?{...x,...patch}:x));
 return <tr key={l.id}>
 <td>{dates.includes(l.start)&&<small>{t("collectivetable.day")}{" "}{dates.indexOf(l.start)+1}</small>}<input aria-label={t("cost.dateNamed", {name:l.label})} type="date" value={l.start} onChange={e=>update({start:e.target.value,...(l.start===l.end?{end:e.target.value}:{})})}/></td>
 <td><ServiceName value={l.label} options={suggestions[section(l)]||[]} onChange={label=>update({label})}/>{l.addon&&<small>{l.included?t("collectivetable.selected.extras"):t("collectivetable.not.selected")}</small>}</td>
 <td>{l.basis==='supplier-total'?'1':<AmountInput aria-label={t("cost.quantityNamed", {name:l.label})} value={l.quantity} onChange={(quantity:number)=>update({quantity})}/>}</td>
 <td>{['vehicle-day','room-night','pax-day'].includes(l.basis)?<AmountInput aria-label={t("cost.durationNamed", {name:l.label})} value={l.factor} onChange={(factor:number)=>update({factor})}/>:'1'}</td>
 <td><small>{l.currency}{l.basis==='supplier-total'?t('common.oneTimeSuffix'):''}</small><input aria-label={t("cost.priceNamed", {name:l.label})} type="number" min="0" placeholder={t("collectivetable.not.entered")} value={l.unitPrice??''} onChange={e=>update({unitPrice:e.target.value===''?null:Number(e.target.value)})}/></td>
 <td>{money(lineAmount(l),l.currency)}</td>
 <td><button onClick={()=>onEdit(l)}>{t("collectivetable.detail")}</button>{<button className="text-button danger" aria-label={t("cost.deleteNamed", {name:l.label})} onClick={()=>onChange(q.lines.filter(x=>x.id!==l.id))}>{t("collectivetable.delete")}</button>}</td>
 </tr>;
 }
 return <div className="collective-table">{definitions.map(def=>{
 const lines=q.lines.filter(l=>l.side===side&&!l.addon&&section(l)===def[0]);
 return <section className="ca-cost-section" key={def[0]}><h3>{t(sectionKeys[def[0]])}</h3>
 {lines.length>0&&<div className="table-scroll"><table><thead><tr><th>{t("collectivetable.day.date")}</th><th>{t("collectivetable.service")}</th><th>{t("collectivetable.quantity")}</th><th>{def[0]==='hotel'?t("collectivetable.nights"):t("collectivetable.days.uses")}</th><th>{t("collectivetable.rate")}</th><th>{t("collectivetable.total")}</th><th/></tr></thead><tbody>
 {lines.slice().sort((a,b)=>a.start.localeCompare(b.start)).map(l=>row(l))}
 </tbody></table></div>}
 <button className="text-button" onClick={()=>onChange([...q.lines,fresh(def)])}>{t("collectivetable.add.item")}</button>
 </section>;
 })}</div>;
}
