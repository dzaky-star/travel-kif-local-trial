import {t,stateLabel} from "./i18n";
import React from "react";
export function Field({
  label,
  value,
  onChange,
  type = "text",
  options,
  nullable = false,
  wide = false,
  disabled = false,
}: any) {
  return (
    <label className={"field " + (wide ? "wide" : "")}>
      <span>{label}</span>
      {options ? (
        <select
          value={value ?? ""}
          disabled={disabled}
          onChange={(e) => onChange(e.target.value)}
        >
          {options.map((o: any) =>
            typeof o === "string" ? (
              <option key={o} value={o}>{stateLabel(o)}</option>
            ) : (
              <option key={o.value} value={o.value}>
                {o.label}
              </option>
            ),
          )}
        </select>
      ) : type === "textarea" ? (
        <textarea
          value={value ?? ""}
          disabled={disabled}
          onChange={(e) => onChange(e.target.value)}
        />
      ) : (
        <input
          type={type}
          value={value ?? ""}
          disabled={disabled}
          step={type === "number" ? "any" : undefined}
          onChange={(e) =>
            onChange(
              type === "number"
                ? nullable && e.target.value === ""
                  ? null
                  : Number(e.target.value)
                : e.target.value,
            )
          }
        />
      )}
    </label>
  );
}
export function Check({ label, value, onChange, disabled = false }: any) {
  return (
    <label className="check">
      <input
        type="checkbox"
        checked={!!value}
        disabled={disabled}
        onChange={(e) => onChange(e.target.checked)}
      />
      <span>{label}</span>
    </label>
  );
}
export function Modal({ title, children, onClose, wide = false }: any) {
  return (
    <div className="overlay" onClick={onClose}>
      <section
        className={"modal " + (wide ? "modal-wide" : "")}
        role="dialog"
        aria-modal="true"
        aria-label={title}
        onClick={(e) => e.stopPropagation()}
      >
        <header>
          <h2>{title}</h2>
          <button aria-label={t("common.close")} onClick={onClose}>
            ×
          </button>
        </header>
        {children}
      </section>
    </div>
  );
}
export function Badge({ children, tone = "" }: any) {
  return <span className={"badge " + tone}>{children}</span>;
}
export const currencies = ["EUR", "IDR", "USD", "GBP", "CHF"];
export const categoryOptions = [
  { value: "transport", label: "Transport" },
  { value: "hotel", label: "Hotel" },
  { value: "meal", get label(){return t("common.restaurant.meal");} },
  { value: "guide", label: "Guide / TL" },
  { value: "activity", get label(){return t("common.activity.ticket");} },
  { value: "operational", get label(){return t("common.operational.costs");} },
  { value: "additional", get label(){return t("common.additional.services");} },
  { value: "route", get label(){return t("lineeditor.city.route");} },
];
