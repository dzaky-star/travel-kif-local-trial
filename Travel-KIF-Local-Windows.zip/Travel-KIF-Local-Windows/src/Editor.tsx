import {errorMessage,t,stateLabel} from "./i18n";
import {salesStatuses,salesStatusLabel} from "./QuotationList";
import {DashboardFx} from "./QuoteFx";
import {ItineraryAssistant} from './ItineraryAssistant';
import { paxSummary } from "../shared/pax-summary";
import {CollectiveTable} from "./CollectiveTable";
import {CostApproval} from "./CostApproval";
import { structuredDay, updateHotel, hotelLines } from "../shared/itinerary-options";
import { ItineraryPlaces } from "./ItineraryPlaces";
import { TravelSearchResults } from "./TravelSearchResults";
import { useEffect, useRef, useState } from "react";
import {
  ArrowLeft,
  Plus,
  Save,
  Download,
  Sparkles,
  CheckCircle2,
} from "lucide-react";
import {
  blankQuote,
  QuoteInput,
  newLine,
  type Quote,
  type CostLine,
} from "../shared/model";
import { calculate, convert, days, formula, lineAmount } from "../shared/calculate";
import { passenger } from "../shared/fixtures";
import { WorkbookSource } from "./WorkbookSource";
import { api, money, percent } from "./api";
import { Field, Check, Modal, Badge, currencies } from "./components";
import { LineEditor } from "./LineEditor";
const steps = () => [
  t("common.trip.participant.information"),
  "Itinerary",
  t("editor.cost.analysis"),
  t("common.pricing.negotiation"),
  "Review & Quotation",
];
export function Editor({ record, me, onSaved, onBack, onNew, beforeLeave }: any) {
  const [q, setQ] = useState<Quote>(record?.input ? {...record.input,itinerary:record.input.itinerary.map(structuredDay)} : { ...blankQuote(), ownerName: me.user.name, pricing: { ...blankQuote().pricing, finalRounding: 1 } }),
    [step, setStep] = useState(record?.openStep ?? 0),
    [status, setStatus] = useState(record?.status ?? "Draft"),
    [saving, setSaving] = useState(""),
    [error, setError] = useState(""),
    [editLine, setEditLine] = useState<CostLine | null>(null),
    [catalog, setCatalog] = useState<any[] | null>(null),
    [catalogSearch, setCatalogSearch] = useState(""),
    [refresh, setRefresh] = useState<any>(),
    [deleteConfirm,setDeleteConfirm]=useState(false),
    [actionBusy,setActionBusy]=useState(false),
    [preview, setPreview] = useState<any>(),
    [ops, setOps] = useState<any[] | null>(null),
    [planner,setPlanner]=useState(false),
    [snapshotOpen, setSnapshotOpen] = useState(false),
    [imageSource, setImageSource] = useState(""),
    [imageRights, setImageRights] = useState("");
  const draftContent=(input:Quote)=>{const {fx,policy,ownerName,...content}=input;return JSON.stringify(Object.fromEntries(Object.entries(content).sort(([a],[b])=>a.localeCompare(b))));};
  const emptyDraft=useRef(draftContent(q));
  const requestKey = useRef<string | null>(null);
  const savingRequest=useRef<Promise<boolean>|null>(null),ownSaved=useRef<string|null>(null),serverRecord=useRef(record);
  const latestDraft=useRef({q,status,saving});latestDraft.current={q,status,saving};
  useEffect(()=>{serverRecord.current=record;},[record]);

  useEffect(() => {
    if (!record?.id) return;
    let active = true;
    const refreshReview = async () => {
      if (document.hidden || document.activeElement?.matches("input, textarea, select, [contenteditable=true]")) return;
      try {
        const version = await api(`/quotes/${encodeURIComponent(record.id)}/version`);
        if (!active || version.current_revision === record.current_revision) return;
        const latest = await api(`/quotes/${encodeURIComponent(record.id)}`);
        if (!active || latest.current_revision === record.current_revision) return;
        if (savingRequest.current || ["Belum disimpan","Gagal disimpan"].includes(latestDraft.current.saving)) {
          setError("Ada revisi baru dari pengguna lain. Simpan perubahanmu atau buka ulang quotation untuk memuat revisi terbaru.");
        } else onSaved(latest);
      } catch { /* Keep the open form intact during connection interruptions. */ }
    };
    const timer=setInterval(refreshReview,60000);
    window.addEventListener("focus",refreshReview);
    document.addEventListener("visibilitychange",refreshReview);
    return () => { active = false; clearInterval(timer);window.removeEventListener("focus",refreshReview);document.removeEventListener("visibilitychange",refreshReview); };
  }, [record?.id, record?.current_revision, saving]);
  useEffect(() => {
    let active = true;
    if(record&&ownSaved.current===record.id+':'+record.current_revision){ownSaved.current=null;return;}
    if (record) {
      setQ({
        ...record.input,
        ownerName: record.input.ownerName || record.owner_name || "",
      });
      setStatus(record.status);
    } else {
      const initialDraft={ ...blankQuote(), ownerName: me.user.name, pricing: { ...blankQuote().pricing, finalRounding: 1 } };
      emptyDraft.current=draftContent(initialDraft);
      setQ(initialDraft);
      setStatus("Draft");
      setSaving("");
      api("/settings")
        .then((s) => {
          if (active)
            setQ((current) => ({
              ...current,
              policy: s.policies[0] ?? current.policy,
              fx: s.fx.filter(
                (f: any, i: number, all: any[]) =>
                  all.findIndex(
                    (x: any) =>
                      x.from === f.from && x.to === f.to && x.kind === f.kind,
                  ) === i,
              ),
            }));
        })
        .catch((e) => setError(e.message));
    }
    setError("");
    return () => {
      active = false;
    };
  }, [record?.id, record?.revision]);
  const reviewAssignment=record?.costReview?.context?JSON.parse(record.costReview.context):{};
  const opsCostEditable = !!record && record.costReview?.status === "ApprovalWaiting" && (me.user.roles.includes("Admin") || (me.user.roles.includes("OPS") && (!reviewAssignment.opsReviewerId || reviewAssignment.opsReviewerId===me.user.id)));
  const managerReviewEditable = !!record && ["ManagerWaiting","ApprovalApproved"].includes(record.costReview?.status) && (me.user.roles.includes("Admin") || (me.user.roles.includes("Director") && (!reviewAssignment.managerReviewerId || reviewAssignment.managerReviewerId===me.user.id)));
  const reviewEditable=opsCostEditable||managerReviewEditable;
  const editable = reviewEditable ||
    me.user.roles.includes("Admin") ||
    (me.user.roles.some((r:string)=>["TC","OPS","Finance"].includes(r)) &&
      (!record || record.owner_id === me.user.id)) ||
    (me.user.roles.includes("Director") && !!me.user.can_edit);
  const caEditable = reviewEditable;
  const change = (next: Quote) => {
    setQ(next);
    setSaving("Belum disimpan");
    requestKey.current = null;
  };
  const put = (key: keyof Quote, value: any) => change({ ...q, [key]: value });
  const pricing = (key: string, value: any) =>
    put("pricing", {
      ...q.pricing,
      [key]: value,
      ...(key === "commission" && value.kind === "none"
        ? { targetAfterCommission: false }
        : {}),
    });
  let c: ReturnType<typeof calculate>;
  let tripNights: number | null = null;
  try {
    tripNights = days(q.start, q.end);
  } catch {
    // Dates may be incomplete while the user is filling the form.
  }
  try {
    c = calculate(q);
  } catch {
    c = calculate({ ...blankQuote(), customer: "Draft", trip: "Draft" });
  }
  const perform = async (fn: () => Promise<any>) => {
    setError("");
    try {
      return await fn();
    } catch (e) {
      setError((e as Error).message);
      return null;
    }
  };
  const save = async ():Promise<boolean> => {
    if(savingRequest.current)return savingRequest.current;
    const snapshot=latestDraft.current,base=serverRecord.current;
    if(!QuoteInput.safeParse(snapshot.q).success){setError('Lengkapi nama pelanggan, nama trip, dan kolom wajib sebelum draft dapat disimpan.');setSaving('Gagal disimpan');return false;}
    setSaving('Menyimpan…');
    const id=requestKey.current??crypto.randomUUID();requestKey.current=id;
    const task=(async()=>{
      const r=await perform(()=>reviewEditable?api('/cost-approvals/'+base.id,{action:managerReviewEditable?'managerSave':'save',input:snapshot.q,lines:snapshot.q.lines,expectedRevision:base.current_revision}):api(base?'/quotes/'+base.id:'/quotes',{input:snapshot.q,status:snapshot.status,requestId:id,expectedRevision:base?.current_revision},base?'PUT':'POST'));
      if(!r){setSaving('Gagal disimpan');return false;}
      serverRecord.current=r;ownSaved.current=r.id+':'+r.current_revision;requestKey.current=null;
      const changed=JSON.stringify([latestDraft.current.q,latestDraft.current.status])!==JSON.stringify([snapshot.q,snapshot.status]);
      setSaving(changed?'Belum disimpan':'Tersimpan');onSaved(r);return !changed;
    })();
    savingRequest.current=task;
    try{return await task;}finally{savingRequest.current=null;}
  };
  const untouchedNew=()=>!serverRecord.current && draftContent(latestDraft.current.q)===emptyDraft.current;
  const flush=async()=>{
    if(savingRequest.current&&!await savingRequest.current)return false;
    if(untouchedNew())return true;
    if(['Belum disimpan','Gagal disimpan'].includes(latestDraft.current.saving)){setError(t('editor.save.before.leaving'));return false;}
    return true;
  };
  useEffect(()=>{if(beforeLeave)beforeLeave.current=flush;return()=>{if(beforeLeave)beforeLeave.current=null;};});
  useEffect(()=>{const warn=(e:BeforeUnloadEvent)=>{if(!untouchedNew()&&['Belum disimpan','Menyimpan…','Gagal disimpan'].includes(latestDraft.current.saving)){e.preventDefault();e.returnValue='';}};window.addEventListener('beforeunload',warn);return()=>window.removeEventListener('beforeunload',warn);},[]);
  const saveLine = (l: CostLine) => {
    const exists = q.lines.some((x) => x.id === l.id);
    put(
      "lines",
      exists ? q.lines.map((x) => (x.id === l.id ? l : x)) : [...q.lines, l],
    );
    setEditLine(null);
  };
  const buildDays = () => {
    try {
      const n = days(q.start, q.end) + 1;
      if (n > 100) throw Error("Maksimal 100 hari.");
      put(
        "itinerary",
        Array.from({ length: n }, (_, i) => {
          const date = new Date(Date.parse(q.start) + i * 864e5)
            .toISOString()
            .slice(0, 10);
          return (
            q.itinerary.find((d) => d.date === date) ?? {
              id: crypto.randomUUID(),
              date,
              city: "",
              title: `Hari ${i + 1}`,
              description: "",
            }
          );
        }),
      );
    } catch (e) {
      setError((e as Error).message);
    }
  };
  return (
    <div className="editor">
      <button className="back" onClick={async()=>{if(await flush())onBack();}}>
        <ArrowLeft size={16} />{t("editor.all.quotations")}</button>
      <div className="page-heading editor-heading">
        <div>
          {!record&&<div className="eyebrow">{t("editor.new.quotation")}</div>}
          <h1>{q.trip || t("editor.plan.a.new.trip")}</h1>
          <p>
            {q.customer ||
              t("editor.start.with.customer.information.and.travel.requirements")}
          </p>
        </div>
        <div className="actions">
          <Badge tone="amber">{status === 'Negotiation' ? 'Nego' : salesStatusLabel(status)}</Badge>
          {!record && <button className="danger-text" disabled={saving==='Menyimpan…'} onClick={()=>{if(!untouchedNew()&&!window.confirm(t('editor.discardNewConfirm')))return;onBack();}}>{t('editor.discardNew')}</button>}
          {record && editable && <select aria-label={t("app.quotation.status")} value={record.status==='Cancelled'?'Lost':record.status} disabled={reviewEditable||saving==='Menyimpan…'||saving==='Belum disimpan'} onChange={async e=>{const next=e.target.value;if(['Confirmed','Lost','Cancelled'].includes(record.status)&&!window.confirm('Ubah status quotation final? Riwayat dan approval tetap tersimpan.'))return;setSaving('Menyimpan…');const r=await perform(()=>api('/quotes/'+record.id,{input:record.input,status:next,reopen:true,expectedRevision:record.current_revision,requestId:crypto.randomUUID()},'PUT'));if(r){onSaved(r);setSaving('Tersimpan');}else setSaving('Gagal disimpan');}}>{salesStatuses.map(s=><option key={s} value={s}>{salesStatusLabel(s)}</option>)}</select>}
          {record && <>
            {(record.owner_id===me.user.id||me.user.roles.includes('Admin'))&&<button className="danger-text" disabled={actionBusy||saving==='Menyimpan…'} onClick={()=>setDeleteConfirm(true)}>{t("collectivetable.delete")}</button>}
            {(me.user.roles.some((r:string)=>['TC','OPS','Finance','Admin'].includes(r))||(me.user.roles.includes('Director')&&!!me.user.can_edit))&&<button disabled={actionBusy||saving==='Menyimpan…'} onClick={async()=>{setActionBusy(true);try{if(!await flush())return;const copy=await perform(()=>api('/quotes/'+serverRecord.current.id+'/duplicate',{requestId:crypto.randomUUID()}));if(copy){setStep(0);onSaved(copy);}}finally{setActionBusy(false);}}}>{t("quotations.duplicate")}</button>}
          </>}
        </div>
      </div>
      {record && <details className="card quote-record-details"><summary>{t("editor.quotation.information")}</summary><dl><div><dt>{t("editor.quotation.id")}</dt><dd>{record.id}</dd></div><div><dt>{t("app.owner")}</dt><dd>{record.owner_name || q.ownerName}</dd></div><div><dt>{t("editor.created")}</dt><dd>{new Date(record.created_at).toLocaleString('id-ID')}</dd></div><div><dt>{t("editor.last.edited")}</dt><dd>{new Date(record.updated_at).toLocaleString('id-ID')}</dd></div><div><dt>{t("editor.exchange.rate.snapshot")}</dt><dd><DashboardFx q={q}/></dd></div></dl></details>}
      {q.sourceWorkbook && (
        <WorkbookSource
          q={q}
          editable={editable}
          onChoose={(line) => {
            setStep(1);
            setEditLine(line);
          }}
        />
      )}
      {q.exampleAssumptions && (
        <details className="card">
          <summary>{t("editor.simulation.example.missing.data.filled.with.assumptions")}</summary>
          <ul>{q.exampleAssumptions.map((a, i) => <li key={i}>{a}</li>)}</ul>
        </details>
      )}
      <div className="steps">
        {steps().map((s, i) => (
          <button
            className={step === i ? "current" : step > i ? "done" : ""}
            key={s}
            disabled={saving === "Menyimpan…"}
            onClick={() => setStep(i)}
          >
            <span>{step > i ? <CheckCircle2 size={17} /> : i + 1}</span>
            {s}
          </button>
        ))}
      </div>
      {error && (
        <p role="alert" className="error">
          {errorMessage(error)}
        </p>
      )}
      {step >= 3 && record?.costReview?.status !== "ManagerApproved" && <div className="info" role="status"><strong>{t("editor.internal.approval.is.incomplete")}</strong>{" "}{t("editor.review.flow.ops.manager")}</div>}
      <fieldset
        disabled={(!reviewEditable && (['Sent','Confirmed','Lost','Cancelled'].includes(record?.status) || ["ManagerWaiting", "ApprovalApproved"].includes(record?.costReview?.status))) || (!editable && !caEditable) || (record?.costReview?.status === "ApprovalWaiting" && step < 3 && !caEditable) || saving === "Menyimpan…"}
        className="editor-fieldset"
      >
        {step === 0 && (
          <>
            <section className="card">
              <div className="section-heading">
                <h2>{t("editor.trip.information")}</h2>
                <Badge>01 / Trip</Badge>
              </div>
              <div className="form-grid three">
                <Field
                  label={t("editor.customer")}
                  value={q.customer}
                  onChange={(v: any) => put("customer", v)}
                />
                <Field
                  label={t("editor.agent.optional")}
                  value={q.agent}
                  onChange={(v: any) => put("agent", v)}
                />
                <Field
                  label={t("editor.quotation.type")}
                  value={q.mode}
                  options={[
                    { value: "trip", label: t("common.travel.package") },
                    { value: "transfer", label: "Airport transfer" },
                    { value: "hotel", label: t("common.hotel.only") },
                    { value: "ticket", label: t("common.tickets.only") },
                    { value: "custom", label: t("common.custom.service") },
                  ]}
                  onChange={(v: any) => put("mode", v)}
                />
                <Field
                  label={t("editor.trip.name")}
                  value={q.trip}
                  onChange={(v: any) => put("trip", v)}
                  wide
                />
                <Field
                  label={t("editor.destination.route")}
                  value={q.destination}
                  onChange={(v: any) => put("destination", v)}
                />
                <Field
                  label={t("editor.start.date")}
                  type="date"
                  value={q.start}
                  onChange={(v: any) => put("start", v)}
                />
                <Field
                  label={t("editor.end.date")}
                  type="date"
                  value={q.end}
                  onChange={(v: any) => put("end", v)}
                />
                <div className="field">
                  <span>{t("editor.trip.duration")}</span>
                  <div className="computed">
                    {tripNights === null
                      ? t("editor.check.the.start.and.end.dates")
                      : t("editor.tripDuration", {days:tripNights+1,nights:tripNights})}
                  </div>
                </div>
                <Field
                  label={t("editor.arrival.city.airport")}
                  value={q.entry}
                  onChange={(v: any) => put("entry", v)}
                />
                <Field
                  label={t("editor.departure.city.airport")}
                  value={q.exit}
                  onChange={(v: any) => put("exit", v)}
                />
                <Field
                  label={t("editor.valid.until")}
                  type="date"
                  value={q.validUntil}
                  onChange={(v: any) => put("validUntil", v)}
                />
                <Field
                  label={t("editor.base.cost.currency")}
                  value={q.baseCurrency}
                  options={currencies}
                  onChange={(v: any) => put("baseCurrency", v)}
                />
                <Field
                  label={t("editor.client.quotation.currency.required")}
                  value={q.sellCurrencyConfirmed ? q.sellCurrency : ""}
                  options={[
                    { value: "", label: t("common.select.currency") },
                    ...currencies.map((v: string) => ({
                      value: v,
                      label: v === "IDR" ? t("common.idr.rupiah.commonly.used") : v,
                    })),
                  ]}
                  onChange={(v: any) =>
                    change({
                      ...q,
                      sellCurrency: v || "IDR",
                      sellCurrencyConfirmed: !!v,
                    })
                  }
                />
                <p className="muted">{t("editor.supplier.costs.and.client.prices.may.use.different.currencies")}</p>
                <Field
                  label={t("editor.customer.preferences")}
                  type="textarea"
                  value={q.preferences}
                  onChange={(v: any) => put("preferences", v)}
                  wide
                />
                <Field
                  label={t("editor.internal.notes")}
                  type="textarea"
                  value={q.notes}
                  onChange={(v: any) => put("notes", v)}
                />
              </div>
            </section>
            <section className="card">
              <div className="section-heading">
                <div>
                  <h2>{t("editor.participants")}</h2>
                  <p>
                    {c.travelers}{" "}{t("editor.travelling")}{" "}{c.paying}{t("editor.paying.tl.and.foc.are.counted.per.person")}</p>
                </div>
                <button
                  onClick={() =>
                    put("passengers", [
                      ...q.passengers,
                      { ...passenger(), name: "", age: null },
                    ])
                  }
                >
                  <Plus size={16} />{t("editor.add.participant")}</button>
              </div>
              <div className="table-scroll">
                <table className="input-table">
                  <thead>
                    <tr>
                      <th>{t("editor.name.label")}</th>
                      <th>{t("editor.category")}</th>
                      <th>{t("editor.age.at.travel")}</th>
                      <th>{t("editor.role")}</th>
                      <th>{t("editor.foc")}</th>
                      <th>{t("editor.vehicle")}</th>
                      <th>{t("editor.luggage")}</th>
                      <th />
                    </tr>
                  </thead>
                  <tbody>
                    {q.passengers.map((p, i) => {
                      const update = (key: string, v: any) =>
                        put(
                          "passengers",
                          q.passengers.map((x, j) =>
                            j === i ? { ...x, [key]: v } : x,
                          ),
                        );
                      return (
                        <tr key={p.id}>
                          <td>
                            <input
                              aria-label={t("participant.name", {number:i+1})}
                              value={p.name}
                              onChange={(e) => update("name", e.target.value)}
                            />
                          </td>
                          <td>
                            <select
                              aria-label={t("participant.category", {number:i+1})}
                              value={p.category}
                              onChange={(e) =>
                                update("category", e.target.value)
                              }
                            >
                              <option value="adult">{t("editor.adult")}{q.policy.childMaxAge != null
                                  ? t("editor.ageMinimum", {age:q.policy.childMaxAge+1})
                                  : t("editor.reference.age.11")}
                                )
                              </option>
                              <option value="child">{t("editor.child")}{q.policy.childMinAge ?? 3}–
                                {q.policy.childMaxAge ?? 10}{t("editor.years")}</option>
                              <option value="infant">{t("editor.infant.toddler.0")}{q.policy.infantMaxAge ?? 2}{" "}{t("editor.years")}</option>
                            </select>
                          </td>
                          <td>
                            <input
                              aria-label={t("participant.age", {number:i+1})}
                              type="number"
                              value={p.age ?? ""}
                              onChange={(e) =>
                                update(
                                  "age",
                                  e.target.value === ""
                                    ? null
                                    : Number(e.target.value),
                                )
                              }
                            />
                          </td>
                          <td>
                            <select
                              aria-label={t("participant.role", {number:i+1})}
                              value={p.role}
                              onChange={(e) => update("role", e.target.value)}
                            >
                              <option value="customer">{t("editor.customer")}</option>
                              <option value="TL">{t("editor.internal.tl")}</option>
                              <option value="staff">{t("editor.staff")}</option>
                            </select>
                          </td>
                          <td>
                            <input
                              aria-label={t("participant.foc", {number:i+1})}
                              type="checkbox"
                              checked={p.foc}
                              onChange={(e) => update("foc", e.target.checked)}
                            />
                          </td>
                          <td>
                            <input
                              aria-label={t("participant.vehicle", {number:i+1})}
                              type="checkbox"
                              checked={p.usesVehicle}
                              onChange={(e) =>
                                update("usesVehicle", e.target.checked)
                              }
                            />
                          </td>
                          <td>
                            <input
                              aria-label={t("participant.luggage", {number:i+1})}
                              type="number"
                              value={p.bags}
                              onChange={(e) =>
                                update("bags", Number(e.target.value))
                              }
                            />
                          </td>
                          <td>
                            <button
                              aria-label={t("participant.delete", {number:i+1})}
                              onClick={() =>
                                put(
                                  "passengers",
                                  q.passengers.filter((x) => x.id !== p.id),
                                )
                              }
                            >
                              ×
                            </button>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
              {!q.passengers.length && (
                <p className="empty">{t("editor.add.participants.where.relevant.standalone.services.can.use.group")}</p>
              )}
            </section>
          </>
        )}
        {step === 1 && (
          <>
            <section className="card itinerary-compact">
              <div className="section-heading">
                <div>
                  <h2>{t("editor.daily.itinerary")}</h2>
                  <p>{t("editor.plan.the.daily.schedule.and.trip.notes.paid.services")}</p>
                </div>
                <div className="actions">
                  <button onClick={buildDays}>{t("editor.generate.days.from.dates")}</button>
                  <button onClick={()=>setPlanner(true)}><Sparkles size={16}/>{" "}{t("editor.generate.itinerary.with.ai")}</button>
                </div>
              </div>
              {q.itinerary.map((d, i) => (
                <article key={d.id} className="day">
                  <div className="day-number">
                    {String(i + 1).padStart(2, "0")}
                  </div>
                  <div className="day-body">
                    <div className="form-grid three">
                      {(["date", "city", "title"] as const).map((k) => (
                        <Field
                          key={k}
                          label={
                            {
                              date: t("messages.date"),
                              city: t("lineeditor.city.route"),
                              title: t("common.activity.title"),
                            }[k]
                          }
                          type={k === "date" ? "date" : "text"}
                          value={d[k]}
                          onChange={(v: any) =>
                            put(
                              "itinerary",
                              q.itinerary.map((x) =>
                                x.id === d.id ? { ...x, [k]: v } : x,
                              ),
                            )
                          }
                        />
                      ))}
                    </div>
                    <Field
                      label={t("editor.trip.description")}
                      type="textarea"
                      value={d.description}
                      onChange={(v: any) =>
                        put(
                          "itinerary",
                          q.itinerary.map((x) =>
                            x.id === d.id ? { ...x, description: v } : x,
                          ),
                        )
                      }
                    />
                    <ItineraryPlaces day={d} editable={editable} onChange={(patch:any)=>put("itinerary",q.itinerary.map(x=>x.id===d.id?{...x,...patch}:x))} onHotel={(name:string,rooms:number)=>{const itinerary=updateHotel(q.itinerary,d.date,name,rooms);change({...q,itinerary,lines:hotelLines(itinerary,q.lines) as CostLine[]});}} />
                    <div className="actions">
                      <button
                        onClick={() =>
                          put(
                            "itinerary",
                            q.itinerary.filter((x) => x.id !== d.id),
                          )
                        }
                      >{t("collectivetable.delete")}</button>

                    </div>
                  </div>
                </article>
              ))}
              {!q.itinerary.length && (
                <p className="empty">{t("editor.a.multi.day.itinerary.is.optional.for.standalone.services")}</p>
              )}
            </section>

          </>
        )}
        {step === 2 && (
          <>
            <div className="section-heading">
              <div>
                <h2>{t("editor.cost.analysis")}</h2>
                <p>{t("editor.collective.shared.costs.individual.costs.per.participant.room.or")}</p>
              </div>
              <div className="actions">
                <button
                  onClick={() =>
                    perform(async () => setCatalog(await api("/catalog")))
                  }
                >{t("editor.service.catalog")}</button>

              </div>
            </div>
            <div className="ca-grid">
              {(["collective", "individual"] as const).map((side) => (
                <section className="ca-panel" key={side}>
                  <header>
                    <div>
                      <span>
                        {side === "collective"
                          ? t("editor.shared.costs")
                          : t("editor.participant.unit.costs")}
                      </span>
                      <h2>
                        {side === "collective"
                          ? t("editor.collective.fixed")
                          : t("editor.individual.variable")}
                      </h2>
                    </div>
                    <Badge>{q.baseCurrency}</Badge>
                  </header>
                  <div className="ca-lines">
                    <CollectiveTable quote={q} side={side} onChange={lines=>put("lines",lines)} onEdit={setEditLine}/>
                  </div>
                  <footer>
                    <span>{t("editor.selected.subtotal")}</span>
                    <strong>
                      {money(
                        q.lines
                          .filter(
                            (l) => l.side === side && (!l.addon || l.included),
                          )
                          .reduce(
                            (s, l) =>
                              s +
                              (c.lines.find((x) => x.id === l.id)?.total ?? 0),
                            0,
                          ),
                        q.baseCurrency,
                      )}
                    </strong>
                  </footer>
                </section>
              ))}
            </div>
            <section className="total-bar">
              <div>
                <span>{t("editor.total.cost")}{" "}{q.baseCurrency}</span>
                <strong>{money(c.totalCost, q.baseCurrency)}</strong>
              </div>
              <div>
                <span>{t("editor.average.per.paying.participant")}</span>
                <strong>{money(c.costPerPaying, q.baseCurrency)}</strong>
                <small>{t("editor.average.analysis.not.actual.adult.child.costs")}</small>
              </div>
              <div>
                <span>{t("editor.completeness")}</span>
                <Badge tone={c.errors.length ? "amber" : "green"}>
                  {c.errors.length ? t("dashboard.needs.review") : t("messages.complete")}
                </Badge>
                <small>{t("editor.unknown.costs.are.not.treated.as.zero")}</small>
              </div>
            </section>
          </>
        )}
        {step === 3 && (
          <>
            <section className="card">
              <div className="section-heading">
                <div>
                  <h2>{t("editor.pricing.negotiation")}</h2>
                  <QuotationRate q={q} />
                  <p>{t("editor.margin.profit.divided.by.selling.price.markup.profit.divided")}</p>
                </div>
                {record?.initial_offer != null && (record.initial_offer !== c.grandTotal || record.initial_currency !== q.sellCurrency) && <Badge>{t("editor.initial.offer")}{" "}{money(record.initial_offer, record.initial_currency)}</Badge>}
              </div>
              <div className="form-grid three">
                <Field
                  label={t("editor.pricing.basis")}
                  value={q.pricing.basis}
                  options={[
                    { value: "weighted", label: t("common.weighted.per.participant") },
                    { value: "group", label: t("common.group.service.total") },
                    { value: "unit", label: t("common.per.service.unit") },
                  ]}
                  onChange={(v: any) => pricing("basis", v)}
                />
                <Field
                  label={t("editor.target.type")}
                  value={q.pricing.targetType}
                  options={["markup", "margin"]}
                  onChange={(v: any) => pricing("targetType", v)}
                />
                <Field
                  label={t("editor.target")}
                  type="number"
                  value={q.pricing.target * 100}
                  onChange={(v: any) => pricing("target", v / 100)}
                />
                {q.pricing.basis === "unit" && (
                  <Field
                    label={t("editor.units.sold")}
                    type="number"
                    value={q.pricing.units}
                    onChange={(v: any) => pricing("units", v)}
                  />
                )}
              </div>
              <section className="card rounding-section">
                <h3>{t("editor.final.price.rounding")}</h3>
                <label>{t("editor.rounding.increment")}{q.sellCurrency})
                  <select value={q.pricing.finalRounding ?? ""} onChange={e => pricing("finalRounding", Number(e.target.value))}>
                    {!q.pricing.finalRounding && <option value="" disabled>{t("editor.select.rounding")}</option>}
                    {[1,10,100,1000,5000,10000,50000,100000].map(n => {const parsed=QuoteInput.safeParse({...q,pricing:{...q.pricing,finalRounding:n}});const preview=parsed.success?calculate(parsed.data):null;return <option key={n} value={n}>{t("editor.increment")}{" "}{money(n,q.sellCurrency)}{preview&&preview.grandTotal!==null?t("pricing.roundingPreview", {total:money(preview.grandTotal,q.sellCurrency),detail:q.pricing.basis==='weighted'?t("pricing.adultPrice", {price:money(preview.prices.adult.applied,q.sellCurrency)}):q.pricing.basis==='unit'?t("pricing.unitPrice", {price:money(preview.groupSuggested,q.sellCurrency)}):''}):''}</option>;})}
                  </select>
                </label>
                <p>{t("editor.different.increments.may.produce.the.same.price.rounding.follows")}</p>
                <small>{t("editor.total.after.participant.unit.group.rounding.and.adjustments")}{" "}{money(c.unroundedTotal, q.sellCurrency)}{" "}{t("editor.final.payable.total")}{" "}{money(c.grandTotal, q.sellCurrency)}</small>
              </section>
              <div className="scenarios">
                {[10, 15, 20, 25, 30].map((n) => (
                  <button
                    key={n}
                    className={
                      q.pricing.target === n / 100
                        ? "selected"
                        : ""
                    }
                    onClick={() =>
                      put("pricing", {
                        ...q.pricing,
                        target: n / 100,
                      })
                    }
                  >
                    <span>{q.pricing.targetType === "margin" ? t("editor.margin") : t("editor.markup")} {n}%</span>
                    <strong>
                      {money(
                        c.costComplete
                          ? calculate({...q, pricing: {...q.pricing, target: n / 100}}).targetLand
                          : null,
                        q.sellCurrency,
                      )}
                    </strong>
                    <small>{t("editor.base.price.target")}{q.pricing.targetAfterCommission ? " setelah memperhitungkan komisi" : " sebelum komisi"}</small>
                  </button>
                ))}
              </div>
              {q.pricing.basis === "weighted" ? (
                <>
                  <p className="info">{t("editor.the.pricing.weight.method.requires.company.validation.paying.weight")}{" "}
                    {c.weight}{t("editor.child.weights.do.not.change.supplier.costs")}</p>
                  <div className="table-scroll">
                    <table>
                      <thead>
                        <tr>
                          <th>{t("editor.category")}</th>
                          <th>{t("editor.paying.pax")}</th>
                          <th>{t("editor.weight")}</th>
                          <th className="num">{t("editor.calculation")}</th>
                          <th className="num">{t("editor.rounded.suggested")}</th>
                          <th>{t("editor.override.per.pax")}</th>
                          <th className="num">{t("editor.applied.subtotal")}</th>
                        </tr>
                      </thead>
                      <tbody>
                        {(["adult", "child", "infant"] as const).map((k) => (
                          <tr key={k}>
                            <td>
                              {
                                {
                                  adult: t("messages.adult"),
                                  child: t("messages.child"),
                                  infant: "Infant",
                                }[k]
                              }
                            </td>
                            <td>{c.prices[k].count}</td>
                            <td>{percent(q.policy.weights[k])}</td>
                            <td className="num">
                              {money(c.prices[k].calculated, q.sellCurrency)}
                            </td>
                            <td className="num">
                              {money(c.prices[k].rounded, q.sellCurrency)}
                            </td>
                            <td>
                              <input
                                aria-label={t("pricing.overrideCategory", {category:stateLabel(k)})}
                                type="number"
                                placeholder={t("editor.use.suggestion")}
                                disabled={c.prices[k].count === 0}
                                value={c.prices[k].count === 0 ? 0 : q.pricing.overrides[k] ?? ""}
                                onChange={(e) =>
                                  pricing("overrides", {
                                    ...q.pricing.overrides,
                                    [k]:
                                      e.target.value === ""
                                        ? null
                                        : Number(e.target.value),
                                  })
                                }
                              />
                            </td>
                            <td className="num">
                              {money(c.prices[k].subtotal, q.sellCurrency)}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </>
              ) : (
                <div className="form-grid">
                  <div className="computed">
                    <small>{t("editor.before.rounding.per")}{" "}{q.pricing.basis === "unit" ? t("editor.service.unit") : t("messages.group")}</small>
                    <strong style={{display:"block",marginTop:6}}>{money(c.costComplete ? c.groupCalculated : null, q.sellCurrency)}</strong>
                  </div>
                  <div className="computed">
                    <small>{t("editor.after.rounding.per")}{" "}{q.pricing.basis === "unit" ? t("editor.service.unit") : t("messages.group")}</small>
                    <strong style={{display:"block",marginTop:6}}>{money(c.costComplete ? c.groupSuggested : null, q.sellCurrency)}</strong>
                  </div>
                  <Field
                    label={
                      q.pricing.basis==='unit'?t("pricing.overrideUnit"):t("pricing.overrideGroup")
                    }
                    type="number"
                    nullable
                    value={q.pricing.overrides.group}
                    onChange={(v: any) =>
                      pricing("overrides", { ...q.pricing.overrides, group: v })
                    }
                  />
                </div>
              )}
              <div className="subtotal">
                <span>TOTAL LAND ARRANGEMENT REVENUE</span>
                <strong>{money(c.landRevenue, q.sellCurrency)}</strong>
              </div>
            </section>
            <div className="quotation-summary-layout">
              <section className="card">
                <h2>{t("editor.offer.adjustments")}</h2>
                <Field
                  label={t("pricing.groupDiscount", {currency:q.sellCurrency})}
                  type="number"
                  value={q.pricing.discount}
                  onChange={(v: any) => pricing("discount", v)}
                />
                <details>
                  <summary>{t("editor.optional.commission")}</summary>
                  <Field
                    label={t("editor.commission.type")}
                    value={q.pricing.commission.kind}
                    options={["none", "fixed", "percent"]}
                    onChange={(v: any) =>
                      pricing("commission", {
                        ...q.pricing.commission,
                        kind: v,
                      })
                    }
                  />
                  {q.pricing.commission.kind !== "none" && (
                    <>
                      <Field
                        label={
                          q.pricing.commission.kind === "percent"
                            ? t("editor.rate")
                            : t("pricing.amountCurrency", {currency:q.sellCurrency})
                        }
                        type="number"
                        value={q.pricing.commission.value}
                        onChange={(v: any) =>
                          pricing("commission", {
                            ...q.pricing.commission,
                            value: v,
                          })
                        }
                      />
                      <Field
                        label={t("editor.recipient")}
                        value={q.pricing.commission.recipient}
                        onChange={(v: any) =>
                          pricing("commission", {
                            ...q.pricing.commission,
                            recipient: v,
                          })
                        }
                      />
                      <Field
                        label={t("editor.commission.basis")}
                        value={q.pricing.commission.basis}
                        options={["grand", "land"]}
                        onChange={(v: any) =>
                          pricing("commission", {
                            ...q.pricing.commission,
                            basis: v,
                          })
                        }
                      />
                      <Check
                        label={t("editor.final.group.target.after.commission.adjusting.discounts.add.ons")}
                        value={q.pricing.targetAfterCommission}
                        onChange={(v: any) =>
                          pricing("targetAfterCommission", v)
                        }
                      />
                    </>
                  )}
                </details>

              </section>
              <Summary c={c} q={q} />
            </div>
          </>
        )}
        {step === 4 && (
          <div className="quotation-summary-layout">
            <section className="card">
              <h2>{t("editor.review.before.sending")}</h2>
              <p>{t("editor.exporting.does.not.send.the.quotation.to.the.customer")}</p>
              <Field
                label={t("editor.included.services")}
                type="textarea"
                value={q.inclusions}
                onChange={(v: any) => put("inclusions", v)}
              />
              <Field
                label={t("editor.excluded.services")}
                type="textarea"
                value={q.exclusions}
                onChange={(v: any) => put("exclusions", v)}
              />
              <Field
                label={t("editor.company.terms")}
                type="textarea"
                value={q.terms}
                onChange={(v: any) => put("terms", v)}
              />
              <details>
                <summary>{t("editor.quotation.images.usage.rights.must.be.clear")}</summary>
                <p>{t("editor.png.up.to.200.kb.per.image.3000.3000")}</p>
                <Field
                  label={t("editor.image.source")}
                  value={imageSource}
                  onChange={setImageSource}
                />
                <Field
                  label={t("editor.usage.rights.licence.permission")}
                  value={imageRights}
                  onChange={setImageRights}
                />
                <input
                  aria-label={t("editor.add.licensed.image")}
                  type="file"
                  accept="image/png"
                  disabled={
                    !imageSource.trim() ||
                    !imageRights.trim() ||
                    (q.images ?? []).length >= 3
                  }
                  onChange={(e) => {
                    const file = e.target.files?.[0];
                    if (!file) return;
                    if (file.size > 200000) {
                      setError("Gambar maksimal 200 KB.");
                      return;
                    }
                    const reader = new FileReader();
                    reader.onload = () => {
                      setQ((current) => ({
                        ...current,
                        images: [
                          ...(current.images ?? []),
                          {
                            id: crypto.randomUUID(),
                            caption: file.name,
                            source: imageSource,
                            rights: imageRights,
                            dataUrl: String(reader.result),
                          },
                        ],
                      }));
                      setSaving("Belum disimpan");
                      requestKey.current = null;
                    };
                    reader.readAsDataURL(file);
                  }}
                />
                {(q.images ?? []).map((p) => (
                  <div key={p.id}>
                    <img
                      src={p.dataUrl}
                      alt={p.caption}
                      style={{ maxWidth: "100%", maxHeight: 180 }}
                    />
                    <Field
                      label={t("editor.image.caption")}
                      value={p.caption}
                      onChange={(v: any) =>
                        put(
                          "images",
                          q.images.map((x) =>
                            x.id === p.id ? { ...x, caption: v } : x,
                          ),
                        )
                      }
                    />
                    <small>
                      {p.source} · {p.rights}
                    </small>
                    <button
                      onClick={() =>
                        put(
                          "images",
                          q.images.filter((x) => x.id !== p.id),
                        )
                      }
                    >{t("editor.delete.image")}</button>
                  </div>
                ))}
              </details>
              <Field
                label={t("editor.sales.status.manual.recording")}
                disabled={reviewEditable}
                value={status}
                options={salesStatuses.map(value=>({value,label:salesStatusLabel(value)}))}
                onChange={(v:any)=>{setStatus(v);setSaving("Belum disimpan");requestKey.current=null;}}
              />
              <p className="muted">{t("editor.manager.approval.changes.the.status.to.sent.select.draft")}</p>
            </section>
            <div>
              <Summary c={c} q={q} />
              <div className="snapshot-actions"><button onClick={() => setSnapshotOpen(true)}>{t("editor.view.exchange.rates.policies")}</button></div>
            </div>
          </div>
        )}
      {step===2 && <section className="card ca-addon-section"><h2>{t("editor.add.ons.optional.extras")}</h2><p>{t("editor.offered.separately.costs.and.selling.prices.enter.the.total")}</p>
      {q.lines.filter(l=>l.addon).map(l=><div className={"option-row ca-addon "+(l.included?"included":"optional")} key={l.id}>
      <div><strong>{l.label}</strong><small>{l.included?t("editor.selected.included.in.total"):t("editor.offered.excluded.from.total")}</small></div>
      <span>{t("editor.total.selling.price")}{" "}{money(l.selling,q.sellCurrency)}</span>
      <Check label={t("editor.selected")} value={l.included} onChange={(v:any)=>saveLine({...l,included:v})}/>
      <button disabled={!editable && !caEditable} onClick={()=>setEditLine(l)}>{t("editor.edit")}</button>
      <button disabled={!editable && !caEditable} onClick={()=>put("lines",q.lines.filter(x=>x.id!==l.id))}>{t("collectivetable.delete")}</button>
      </div>)}
      <button disabled={(!editable && !caEditable) || (record?.costReview?.status==="ApprovalWaiting" && !caEditable)} onClick={()=>setEditLine({...newLine(),label:"",addon:true,included:false})}>{t("editor.add.add.on")}</button></section>}
      </fieldset>
      {step===4 && <CostApproval record={record} me={me} dirty={saving==="Belum disimpan"} onSaved={onSaved}/>}
      {step === 4 && record && (
        <section className="card">
          <div className="section-heading">
            <div>
              <h2>{t("editor.saved.documents")}</h2>
              <p>{t("editor.save.changes.first.to.include.them.in.documents")}</p>
            </div>
            <div className="actions">
              <button
                onClick={() =>
                  perform(async () =>
                    setPreview(
                      await api(
                        "/quotes/" +
                          record.id +
                          "/customer?revision=" +
                          record.revision,
                      ),
                    ),
                  )
                }
              >{t("editor.customer.preview")}</button>
              <a
                className="button primary"
                href={
                  "/api/quotes/" +
                  record.id +
                  "/pdf?revision=" +
                  record.revision
                }
              >
                <Download size={16} />{t("editor.quotation.pdf")}</a>
              <a
                className="button"
                href={
                  "/api/quotes/" +
                  record.id +
                  "/ca.pdf?revision=" +
                  record.revision
                }
              >{t("editor.internal.ca")}</a>
            </div>
          </div>
        </section>
      )}
      {(step === 2 || step === 3 || step === 4) && (() => {
        const warnings = c.warnings.filter(w => !/^Kurs .* di luar masa berlaku untuk trip\.$/.test(w));
        if (!c.errors.length && !warnings.length) return null;
        return <details className="validation" open={step === 4}>
          <summary>{c.errors.length}{" "}{t("editor.items.need.completion")}{" "}{warnings.length}{" "}{t("editor.reminders")}</summary>
          {c.errors.map(e => <p className="error-text" key={e}>{errorMessage(e)}</p>)}
          {warnings.map(w => <p key={w}>{errorMessage(w)}</p>)}
        </details>;
      })()}
      <div className="savebar">
        <div className="actions">
          {saving === "Tersimpan" && (
            <button onClick={async()=>{if(await flush())onNew();}}>{t("editor.create.new.quotation")}</button>
          )}
          {step < 4 && (
            <button disabled={saving === "Menyimpan…"} onClick={async () => {
              const writable=(editable || caEditable) && (reviewEditable || !['Sent','Confirmed','Lost','Cancelled'].includes(record?.status));
              const needsSave=!serverRecord.current || ['Belum disimpan','Gagal disimpan'].includes(latestDraft.current.saving);
              if(writable && needsSave && !await save())return;
              setStep((current:number) => Math.min(current + 1,4));
            }}>{t("editor.next")}</button>
          )}
          {(editable || caEditable) && (
            <button
              className="primary"
              disabled={saving === "Menyimpan…" || (!reviewEditable && ['Sent','Confirmed','Lost','Cancelled'].includes(record?.status))}
              onClick={()=>void save()}
            >
              <Save size={17} />{" "}{t("common.save")}{" "}
              {reviewEditable ? t("messages.revision") : status === "Draft" ? "Draft" : t("messages.revision")}
            </button>
          )}
        </div>
      </div>
      {editLine && (
        <LineEditor
          line={editLine}
          onClose={() => setEditLine(null)}
          onSave={saveLine}
        />
      )}
      {catalog && (
        <Modal
          title={t("editor.select.a.catalog.service")}
          onClose={() => setCatalog(null)}
          wide
        >
          <Field
            label={t("editor.search.city.service")}
            value={catalogSearch}
            onChange={setCatalogSearch}
          />
          <p className="info">{t("editor.reference.prices.do.not.guarantee.availability.check.season.dates")}</p>
          {catalog
            .filter((x) =>
              (x.label + " " + x.city)
                .toLowerCase()
                .includes(catalogSearch.toLowerCase()),
            )
            .map((x) => (
              <div className="catalog-pick" key={x.id}>
                <div>
                  <strong>{x.label}</strong>
                  <small>
                    {x.city} · {x.data.start} — {x.data.end} · {x.data.source}
                  </small>
                  <small>{x.data.notes}</small>
                </div>
                <span>{money(x.data.unitPrice, x.data.currency)}</span>
                <button
                  onClick={() => {
                    if (x.category === "route") {
                      try {
                        const ds = x.data.routeDays ?? [];
                        if (!ds.length)
                          throw Error(
                            "Template rute belum memiliki rincian hari. Lengkapi katalog terlebih dahulu.",
                          );
                        put("itinerary", [
                          ...q.itinerary,
                          ...ds.map((d: any) => ({
                            id: crypto.randomUUID(),
                            date: new Date(
                              Date.parse(q.start) + d.offset * 864e5,
                            )
                              .toISOString()
                              .slice(0, 10),
                            city: d.city,
                            title: d.title,
                            description: d.description,
                          })),
                        ]);
                        setCatalog(null);
                        setStep(1);
                      } catch (e) {
                        setError((e as Error).message);
                        setCatalog(null);
                      }
                      return;
                    }
                    const l = {
                      ...x.data,
                      id: crypto.randomUUID(),
                      catalogId: x.id,
                      priceStatus: "historical",
                    };
                    setCatalog(null);
                    setEditLine(l);
                  }}
                >{t("editor.review.use")}</button>
              </div>
            ))}
        </Modal>
      )}
      {refresh && (
        <Modal
          title={refresh.fxOnly ? t("editor.preview.exchange.rate.adjustment") : t("editor.preview.snapshot.update")}
          onClose={() => setRefresh(undefined)}
        >
          <p>
            Cost: {money(refresh.before.totalCost, q.baseCurrency)} →{" "}
            {money(refresh.after.totalCost, q.baseCurrency)}
          </p>
          <p>{t("editor.quotation")}{money(refresh.before.grandTotal, q.sellCurrency)} →{" "}
            {money(refresh.after.grandTotal, q.sellCurrency)}
          </p>
          {!refresh.fxOnly && <p>{t("editor.policy")}{" "}{refresh.input.policy.id}</p>}
          {refresh.fxOnly && <p>{t("editor.only.the.exchange.rates.change.manually.entered.selling.prices")}</p>}
          {refresh.input.fx.map((f: any) => (
            <p key={f.id}>
              1 {f.from} = {f.rate.toLocaleString("id-ID")} {f.to}
              <small>{t("editor.recorded")}{" "}{new Date(f.recordedAt).toLocaleString("id-ID")}{" "}{t("editor.valid")}{" "}{f.validFrom}–{f.validTo} · {f.source}</small>
            </p>
          ))}
          <button
            className="primary"
            onClick={() => {
              if (refresh.fxOnly) setStatus("Draft");
              change(refresh.input);
              setRefresh(undefined);
            }}
          >{t("editor.apply.to.form.save.after.review")}</button>
        </Modal>
      )}
      {deleteConfirm&&<Modal title={t("editor.delete.quotation")} onClose={()=>{if(!actionBusy)setDeleteConfirm(false);}}><p>{t("quotations.deleteNamed", {name:q.trip})}</p><div className="actions"><button disabled={actionBusy} onClick={()=>setDeleteConfirm(false)}>{t("common.cancel")}</button><button className="danger-text" disabled={actionBusy} onClick={async()=>{setActionBusy(true);try{if(savingRequest.current&&!await savingRequest.current)return;const result=await perform(()=>api('/quotes/'+record.id,{},'DELETE'));if(result){setDeleteConfirm(false);onBack();}}finally{setActionBusy(false);}}}>{actionBusy?t("messages.deleting"):t("quotations.delete")}</button></div></Modal>}
      {preview && (
        <Modal
          title={t("editor.customer.quotation.preview")}
          onClose={() => setPreview(undefined)}
          wide
        >
          <article className="document">
            <div className="doc-brand">
              <img
                className="brand-document-logo"
                src="/travel-kif-logo.png"
                alt="Travel KIF"
              />
              <span>QUOTATION</span>
            </div>
            <small>
              {preview.id} · {preview.status}
            </small>
            <h1>{preview.trip}</h1>
            <p>
              Untuk {preview.customer} {preview.agent}
            </p>
            <p>
              {preview.start} – {preview.end} · Berlaku sampai{" "}
              {preview.validUntil}
            </p>
            <p>{preview.participants.traveling} peserta bepergian</p>
            {preview.images?.map((p: any) => (
              <figure key={p.id}>
                <img
                  src={p.dataUrl}
                  alt={p.caption}
                  style={{ maxWidth: "100%", maxHeight: 240 }}
                />
                <figcaption>
                  {p.caption}
                  <small>
                    {p.source} · {p.rights}
                  </small>
                </figcaption>
              </figure>
            ))}
            {preview.itinerary.map((d: any, i: number) => (
              <section key={i}>
                <h3>
                  {d.date} · {d.city} · {d.title}
                </h3>
                <p>{d.description}</p>
              </section>
            ))}
            <h3>Layanan</h3>
            {preview.services.map((s: any, i: number) => (
              <p key={i}>
                {s.label} · {s.start} {s.end}
              </p>
            ))}
            {preview.prices.map((p: any) => (
              <p key={p.category}>
                {p.category}: {p.count} × {money(p.price, preview.currency)} ={" "}
                {money(p.subtotal, preview.currency)}
              </p>
            ))}
            <p>
              Land Arrangement: {money(preview.landRevenue, preview.currency)}
            </p>
            <p>
              Add-on terpilih: {money(preview.addonRevenue, preview.currency)}
            </p>
            <p>Diskon grup: {money(preview.discount, preview.currency)}</p>
            <p>Pembulatan: {money(preview.roundingAdjustment ?? 0, preview.currency)}</p>
            <div className="subtotal">
              <strong>Total harga penawaran</strong>
              <strong>{money(preview.total, preview.currency)}</strong>
            </div>
            {preview.options.map((o: any, i: number) => (
              <p key={i}>
                {o.included ? "Termasuk" : "Opsi terpisah"}: {o.label} ·{" "}
                {money(o.price, preview.currency)}
              </p>
            ))}
            <h3>Termasuk</h3>
            <p>{preview.inclusions}</p>
            <h3>Tidak termasuk</h3>
            <p>{preview.exclusions}</p>
            <h3>Syarat perusahaan</h3>
            <p>{preview.terms}</p>
          </article>
        </Modal>
      )}
      {ops && (
        <Modal
          title={t("editor.ops.requests.responses")}
          onClose={() => setOps(null)}
          wide
        >
          {!ops.length && <p>{t("editor.no.requests.linked.to.this.quotation")}</p>}
          {ops.map((o) => (
            <section className="card" key={o.id}>
              <Badge>{o.status}</Badge>
              <p>
                {o.context.route} · {o.context.start} – {o.context.end}
              </p>
              <p>{t("editor.last.updated")}{" "}{o.updated_at}</p>
              {o.response && (
                <>
                  <p>
                    {o.response.supplier} ·{" "}
                    {money(o.response.unitPrice, o.response.currency)}
                  </p>
                  <p>{t("editor.includes")}{" "}
                    {o.response.includedCosts.join(", ") || t("editor.not.detailed")}
                  </p>
                  <p>{t("editor.ensure.included.costs.are.not.counted.twice")}</p>
                  {record.status === "Draft" && editable ? (
                    <>
                      <select
                        aria-label={t("editor.replace.ops.service")}
                        id={"replace-" + o.id}
                      >
                        <option value="">{t("editor.add.as.a.new.service")}</option>
                        {q.lines
                          .filter((l) => l.category === "transport")
                          .map((l) => (
                            <option key={l.id} value={l.id}>{t("editor.replace")}{l.label}
                            </option>
                          ))}
                      </select>
                      <button
                        onClick={() =>
                          perform(async () => {
                            const r = await api("/ops/" + o.id + "/apply", {
                              replaceLineId: (
                                document.getElementById(
                                  "replace-" + o.id,
                                ) as any
                              ).value,
                              expectedRevision: record.current_revision,
                              requestId: crypto.randomUUID(),
                            });
                            onSaved(r);
                            setOps(null);
                          })
                        }
                      >{t("editor.confirm.apply.response")}</button>
                    </>
                  ) : (
                    <p>{t("editor.create.a.draft.revision.to.use.this.response")}</p>
                  )}
                </>
              )}
            </section>
          ))}
        </Modal>
      )}
      <div style={{display:planner?undefined:'none'}}>
        <Modal title={t("editor.itinerary.assistant.gemini.tavily")} onClose={()=>setPlanner(false)} wide>
          <p>{t("editor.several.team.members.can.use.ai.concurrently.within.capacity")}</p>
          <ItineraryAssistant active={planner} key={record?.id??'new'} q={q} enabled={me.integrations.travelSearch} editable={editable} onApply={(items:any[],replace:boolean,stays:any[])=>{
            const generated=stays.map(stay=>{const source=`Pilihan hotel itinerary | ${stay.start} | ${stay.end}`;const old=q.lines.find(l=>l.source===source&&l.label===stay.name);return {...(old||newLine()),label:stay.name,category:'hotel' as const,side:'individual' as const,supplier:stay.name,city:stay.city,start:stay.start,end:stay.end,basis:'room-night' as const,unit:'kamar',quantity:stay.rooms,factor:stay.nights,source,notes:'Hotel pilihan klien/tim. Tarif diisi manual; ketersediaan belum dikonfirmasi.'};});
            const sources=new Set(generated.map(l=>l.source));
            change({...q,itinerary:replace?items:[...q.itinerary,...items].sort((a,b)=>a.date.localeCompare(b.date)),lines:[...q.lines.filter(l=>!sources.has(l.source)&&!(replace&&l.source.startsWith('Pilihan hotel itinerary | '))),...generated]});
          }}/>
        </Modal>
      </div>
      {snapshotOpen && <Modal title={t("editor.quotation.exchange.rates.policies")} onClose={() => setSnapshotOpen(false)} wide>
                <p>{t("editor.policy.version")}{" "}{q.policy.id}</p>
                {q.fx.map((f) => (
                  <p key={f.id}>
                    1 {f.from} = {f.rate.toLocaleString("id-ID", {maximumSignificantDigits: 10})} {f.to}
                    <small>
                      {f.kind} · {f.source} · {f.validFrom} – {f.validTo}
                    </small>
                  </p>
                ))}
                {record?.status === "Draft" && (
                  <button
                    onClick={() =>
                      perform(async () =>
                        { setSnapshotOpen(false); setRefresh(await api("/quotes/" + record.id + "/refresh")); },
                      )
                    }
                  >{t("editor.refresh.from.latest.data")}</button>
                )}
      </Modal>}

    </div>
  );
}
export function Summary({ c, q }: any) {
 const converted = (value: number | null, currency: string) => {
   if (value == null) return null;
   try { return convert(value, q.sellCurrency, currency, q); } catch { return null; }
 };
 const amount = (value: number | null) => <span className="dual-amount"><span>{money(converted(value, "IDR"), "IDR")}</span><small>{money(converted(value, "EUR"), "EUR")}</small></span>;
 const average = (value: number | null) => value == null || !c.paying ? null : value / c.paying;
 const tone = (value: number | null) => value == null ? "metric-unknown" : value < 0 ? "metric-negative" : "metric-positive";
 const perPax = paxSummary(q, c);
 const row = (label: string, value: number | null) => <div className="summary-row" key={label}><span>{label}</span><strong>{amount(value)}</strong></div>;
 const metrics = (profit: number | null, label: string) => <div className="profit-row">
 <div><span>{label}</span><strong className={tone(profit)}>{amount(profit)}</strong></div>
 <div><span>{t("editor.margin")}</span><strong className={tone(c.margin)}>{percent(c.margin)}</strong></div>
 <div><span>{t("editor.markup")}</span><strong className={tone(c.markup)}>{percent(c.markup)}</strong></div>
 </div>;
 let rate: number | null = null;
 try { rate = convert(1, "EUR", "IDR", q); } catch {}
 return <div className="summary-stack compact-summary">
 <section className="summary-card">
 <div className="eyebrow">{t("editor.group.total.idr.eur")}</div>
 <h2>{t("editor.group.quotation.summary")}</h2>
 <p className="summary-context">{rate == null ? t("editor.eur.idr.exchange.rate.unavailable") : t("pricing.quotationRate", {rate:money(rate,"IDR")})}</p>
 <div className="summary-main">
 {row(t("common.package.price"), c.landRevenue)}
 {row(t("collectivetable.selected.extras"), c.addonRevenue)}
 {row(t("messages.discount"), -c.discount)}
 <div className="grand"><span>{t("editor.total.selling.price.cf014")}</span><strong>{amount(c.grandTotal)}</strong></div>
 {row(t("common.total.cost"), c.totalCostSelling)}
 {row(t("messages.commission"), c.commission)}
 </div>
 {metrics(c.profit, t("common.profit.after.commission"))}
 <details className="summary-details"><summary>{t("editor.calculation.details")}</summary>
 {row(t("common.total.rounding.adjustment"), c.totalRoundingAdjustment)}
 {row(t("common.already.included.in.package.price"), c.packageRoundingAdjustment)}
 {row(t("common.additional.rounding.after.discount"), c.roundingAdjustment)}
 <small>{t("editor.package.price.rounding.is.already.included.above.it.is")}</small>
 {row(t("common.trip.costs"), c.baseCostSelling)}
 {row(t("common.additional.costs"), c.costComplete ? c.totalCostSelling-c.baseCostSelling : null)}
 {row(t("common.profit.before.commission"), c.profitBeforeCommission)}
 <p>{t("editor.margin.profit.selling.price.markup.profit.cost.profit.is")}</p>
 </details>
 </section>
 <section className="summary-card pax-summary">
 <div className="eyebrow">{t("editor.per.participant.idr.eur")}</div>
 <h2>{t("editor.price.breakdown.per.participant")}</h2>
 <p className="summary-context">{c.paying}{" "}{t("editor.paying")}{" "}{c.travelers}{" "}{t("editor.travelling.8eebc")}</p>
 <div className="summary-main">
 {(["adult", "child", "infant"] as const).map(k => <div className="summary-row" key={k}><span>{{adult:t("messages.adult"),child:t("messages.child"),infant:t("messages.infant.toddler")}[k]} · {c.counts[k]}{" "}{t("editor.participants.ee2b5")}</span><strong>{c.counts[k] ? amount(perPax[k]) : "—"}</strong></div>)}
 <div className="grand"><span>{t("editor.average.price.participant")}</span><strong>{amount(average(c.grandTotal))}</strong></div>
 {row(t("common.average.cost.participant"), average(c.totalCostSelling))}
 {row(t("common.average.commission.participant"), average(c.commission))}
 </div>
 {metrics(average(c.profit), t("common.average.profit.participant"))}
 <details className="summary-details"><summary>{t("editor.per.participant.allocation.basis")}</summary>
 <p>{q.pricing.basis === "weighted" ? t("editor.the.final.total.is.allocated.proportionally.using.the.applied") : t("pricing.weightExplanation", {adult:percent(q.policy.weights.adult),child:percent(q.policy.weights.child),infant:percent(q.policy.weights.infant)})}</p>
 <p>{t("editor.includes.selected.extras.and.discounts.foc.participants.are.not")}</p>
 <p>{t("editor.margin.and.markup.are.group.ratios.costs.and.profit")}</p>
 </details>
 </section></div>;
}

function QuotationRate({q}: {q: Quote}) {
 const fx = q.fx.find(r => r.kind === "working" && r.from === "EUR" && r.to === "IDR")
   ?? q.fx.find(r => r.kind === "working" && r.from === "IDR" && r.to === "EUR");
 let rate: number | null = null;
 try { rate = convert(1, "EUR", "IDR", q); } catch {}
 const date = fx?.effectiveDate || fx?.sourceDate || fx?.validFrom;
 return <div className="quotation-rate"><strong>{t("editor.exchange.rate.used")}{" "}{rate == null ? t("editor.eur.idr.unavailable") : `1 EUR = ${money(rate, "IDR")}`}</strong>{date && <span> · {new Date(date + "T00:00:00").toLocaleDateString("id-ID", {day:"numeric",month:"short",year:"numeric"})}</span>}</div>;
}
