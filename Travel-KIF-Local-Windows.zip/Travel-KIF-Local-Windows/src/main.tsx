import React from "react";
import { createRoot } from "react-dom/client";
import App from "./App";
import "./style.css";
import "./styles.css";
// Numeric fields are typed manually. Scrolling should move the page, not the value.
document.addEventListener("wheel", () => {
  const field = document.activeElement;
  if (field instanceof HTMLInputElement && field.type === "number") field.blur();
}, { capture: true, passive: true });
document.addEventListener("keydown", (event) => {
  const field = event.target;
  if (field instanceof HTMLInputElement && field.type === "number" &&
      (event.key === "ArrowUp" || event.key === "ArrowDown")) event.preventDefault();
}, true);
createRoot(document.getElementById("root")!).render(<App />);
