import {EmailSettings} from './EmailSettings';
import {activityLabel,errorMessage,t,useLanguage,setLanguage,setLanguageUser} from "./i18n";
import {QuotationList,salesStatuses,salesStatusLabel} from "./QuotationList";
import {Dashboard} from './Dashboard';
import {workspaceMonth} from '../shared/quotation-status';
import {Login} from "./Login";
import {ApprovalDashboard} from "./ApprovalDashboard";
import { useEffect, useState, useRef } from "react";
import {
  LayoutDashboard,
  Files,
  BookOpen,
  MessagesSquare,
  SlidersHorizontal,
  Layers,
  Mail,
  Plus,
  ArrowUpRight,
  Bell,
  Search,
  LogOut,
} from "lucide-react";
import { api, money, percent } from "./api";
import { Badge, Field } from "./components";
import { Editor } from "./Editor";
import { Catalog, Settings, Integrations } from "./Pages";
function navigationLabel(page:string){const labels:Record<string,string>={"Pengaturan Email":t("email.title"),"Persetujuan Itinerary & Biaya":t("app.approvals"),"Katalog Layanan":t("pages.service.catalog"),"Kurs & Kebijakan":t("pages.exchange.rates.policies"),"Integrasi & Salinan Data":t("pages.integrations.data.copies")};return labels[page]||page;}
export default function App() {
  const language=useLanguage();
  const initial=useRef(new URLSearchParams(location.search));
  const [approvalFilters,setApprovalFilters]=useState<any>({period:initial.current.get("period")||"",owner:initial.current.get("owner")||"",stage:initial.current.get("stage")||"",mine:initial.current.get("mine")||""});
  const beforeLeave=useRef<null|(()=>Promise<boolean>)>(null);
  const flushEditor=async()=>!beforeLeave.current||await beforeLeave.current();
  const [me, setMe] = useState<any>(),
    [needsLogin,setNeedsLogin]=useState(false),
    [profiles,setProfiles]=useState<any[]>([]),
    [page, setPage] = useState(initial.current.has("quote")?"Quotations":initial.current.get("page")||"Dashboard"),
    [quotes, setQuotes] = useState<any[]>([]),
    [selected, select] = useState<any>(),
    [error, setError] = useState(""),
    [search, setSearch] = useState(""),
    [year, setYear] = useState(initial.current.get("period")?.slice(0,4)||""),
    [month, setMonth] = useState(initial.current.get("period")?.slice(5,7)||""),
    [status, setStatus] = useState(initial.current.get("status")||""),
    [owner, setOwner] = useState(initial.current.get("owner")||""),
    [notes, setNotes] = useState<any[]>([]),
    [showNotes, setShowNotes] = useState(false);
  const pageRef=useRef(page);pageRef.current=page;
  function navigate(next:string,filters:any={}){select(undefined);setPage(next);setYear(filters.period?.slice(0,4)||'');setMonth(filters.period?.slice(5,7)||'');setOwner(filters.owner||'');setStatus(filters.status||'');setSearch('');setApprovalFilters(filters);const params=new URLSearchParams({page:next,...Object.fromEntries(Object.entries(filters).filter(([,v])=>!!v))} as any);history.pushState(null,'','?'+params);}
  function newQuote(){navigate('Quotations');select('new');}
  async function openQuote(id: string, openStep?: number) {
    if(!await flushEditor())return;
    try { setPage("Quotations");history.pushState(null,"","?page=Quotations&quote="+encodeURIComponent(id));select({...await api("/quotes/" + id), ...(openStep === undefined ? {} : {openStep})}); }
    catch (e) { setError((e as Error).message); }
  }
  const refreshQuotes=()=>api("/quotes").then(setQuotes).catch(e=>setError(e.message));
  const load = async () => {
    try {
      const current=await api("/me");setLanguageUser(current.user.id);setMe(current);setNeedsLogin(false);setError("");
      await Promise.all([api("/notifications").then(setNotes),
        current.user.sessionAdmin?api("/users").then(setProfiles):Promise.resolve()]);
      return true;
    } catch(e:any){if(e.status===401){setMe(undefined);setNeedsLogin(true);}else setError(e.message);}
  };
  function openInitialQuote(ok:any){const id=initial.current.get('quote');if(ok&&id)void openQuote(id,initial.current.get('discussion')==='1'?4:undefined);}
  useEffect(() => {
    load().then(openInitialQuote);
    const pop=()=>location.reload();window.addEventListener('popstate',pop);
    let running = false;
    const timer = setInterval(async () => {
      if (running || document.hidden) return;
      running = true;
      try {
        const sync = location.hostname === "127.0.0.1" || location.hostname === "localhost" ? await api("/sync/tick", {}) : {state:"scheduled"};
        if (sync.state === "failed") setError(`Salinan Google Sheet belum diperbarui: ${sync.error}. Data utama tetap tersimpan di D1.`);
        if(pageRef.current==="Quotations" && !new URLSearchParams(location.search).has("quote"))await api("/quotes").then(setQuotes);
        await api("/notifications").then(setNotes);
      } catch (e) {
        if((e as any).status===401){setMe(undefined);setNeedsLogin(true);}else setError((e as Error).message);
      } finally { running = false; }
    }, 300000);
    return () => {clearInterval(timer);window.removeEventListener("popstate",pop);};
  }, []);
  useEffect(()=>{if(me&&page==="Quotations"&&!selected&&!new URLSearchParams(location.search).has("quote"))void refreshQuotes();},[page,me?.user.id,!!selected]);
  const nav = [
    ["Dashboard", LayoutDashboard],
    ["Quotations", Files],
    ["Persetujuan Itinerary & Biaya", MessagesSquare],
    ["Katalog Layanan", BookOpen],
    ["Kurs & Kebijakan", SlidersHorizontal],
    ["Integrasi & Salinan Data", Layers],
    ["Pengaturan Email", Mail],
  ] as const;
  const roles = me?.user.roles || [];
  const edit =
    roles.some((r:string)=>["TC","OPS","Finance"].includes(r)) ||
    roles.includes("Admin") ||
    (roles.includes("Director") && !!me?.user.can_edit);
  if(needsLogin)return <Login onLogin={()=>{setNeedsLogin(false);load().then(openInitialQuote);}}/>;
  if (!me)
    return (
      <main className="boot">
        <img src="/travel-kif-logo.png" alt="Travel KIF" width="180"/><div className="loading-ring" role="status" aria-label={t("app.loading")}/>
        <p>{error || t("app.opening.workspace")}</p>
        {error && <button onClick={load}>{t("common.retry")}</button>}
      </main>
    );
  const filtered = quotes.filter(
    (q) =>
      [q.input.customer, q.input.trip, q.id]
        .join(" ")
        .toLowerCase()
        .includes(search.toLowerCase()) &&
      (!year || workspaceMonth(q.created_at).slice(0,4) === year) &&
      (!month || workspaceMonth(q.created_at).slice(5,7) === month) &&
      (!status || (q.status==='Cancelled'?'Lost':q.status) === status) &&
      (!owner || q.owner_id === owner),
  );
  const groups = Array.from(
    new Set(filtered.map((q) => workspaceMonth(q.created_at))),
  );
  return (
    <div className="app">
      <aside className="sidebar">
        <a className="brand" href="/" aria-label={t("app.travel.kif.return.to.the.main.menu")} title={t("app.return.to.the.main.menu.and.reload")}>
          <img
            className="brand-logo"
            src="/travel-kif-logo.png"
            alt="Travel KIF"
          />
          <small>QUOTATION WORKSPACE</small>
        </a>
        <div className="workspace-label">{t("app.workspace")}</div>
        <nav>
          {nav
            .filter(
              ([n]) =>
                n === "Pengaturan Email" ? roles.includes("Admin") : n !== "Integrasi & Salinan Data" ||
                roles.some((r: string) => ["Admin", "Finance"].includes(r)),
            )
            .map(([n, Icon]) => (
              <button
                key={n}
                className={page === n ? "active" : ""}
                onClick={async () => {
                  if(!await flushEditor())return;
                  navigate(n);
                }}
              >
                <Icon size={19} />
                {navigationLabel(n)}
              </button>
            ))}
        </nav>
        <div className="sidebar-bottom">
          <div className="profile">
            <span className="avatar">{roles[0]?.[0]}</span>
            <div className="profile-details">
              <strong>{me.user.name}</strong>
              <small>{roles.includes("Admin") ? "Admin" : roles.map((r: string) => r === "Director" ? "Manager" : r).join(" · ")}</small>
            </div>
          </div>
          {me.user.sessionAdmin && <label className="demo-label">{t("app.switch.profile")}<select aria-label={t("app.switch.profile")} value={me.user.id} onChange={async e=>{const id=e.target.value;if(!await flushEditor())return;try{await api("/switch-profile",{id});navigate("Dashboard");pageRef.current="Dashboard";await load();}catch(e){setError((e as Error).message);}}}>
          {profiles.filter(p=>p.active && p.username).map(p=><option key={p.id} value={p.id}>{p.roles.includes("Admin") ? `${p.name} - Admin` : `${p.name} · ${p.roles.map((r:string)=>r==="Director"?"Manager":r).join(" / ")}`}</option>)}
          </select></label>}
          <button
            className="logout"
            onClick={async () => {
              if(!await flushEditor())return;
              await api("/logout", {});setLanguageUser(null);
              navigate("Dashboard");pageRef.current="Dashboard";setMe(undefined);setNeedsLogin(true);select(undefined);setQuotes([]);setNotes([]);
            }}
          >
            <LogOut size={14} />{t("app.sign.out")}</button>
        </div>
      </aside>
      <div className="workspace">
        <header className="topbar">
          <span>
            Workspace <span className="slash">/</span> {navigationLabel(page)}
          </span>
          <div>
            <label className="language-selector"><select aria-label={t("common.interfaceLanguage")} value={language} onChange={e=>setLanguage(e.target.value as 'id'|'en')}><option value="id">Bahasa Indonesia</option><option value="en">English</option></select></label>
            <span className="demo-chip">
              {me.local
                ? t("app.example.workspace.local.d1")
                : "Internal Travel KIF"}
            </span>
            <button
              aria-label={t("app.notifications")}
              className="icon-button"
              onClick={() => setShowNotes(!showNotes)}
            >
              <Bell size={19} />
              {notes.length > 0 && <b>{notes.length}</b>}
            </button>
          </div>
        </header>
        {showNotes && (
          <div className="notifications">
            <div className="actions"><strong>{t("app.notifications")}</strong>{notes.length>0&&<button onClick={async()=>{await api("/notifications/clear",{});setNotes([]);}}>{t("app.clear.notifications")}</button>}</div>
            {notes.length ? (
              notes.map((n) => (
                <button
                  key={n.id}
                  onClick={async () => {
                    if(!await flushEditor())return;
                    await openQuote(n.quote_id,4);
                    setShowNotes(false);
                  }}
                >
                  {n.uiEvent?<>{n.uiEvent.mentioned?t("activity.mentioned",{actor:n.uiEvent.actor,quotation:n.uiEvent.quotation}):t("activity.notification",{actor:n.uiEvent.actor,quotation:n.uiEvent.quotation,action:activityLabel(n.uiEvent)})}{n.uiEvent.message&&<p>{n.uiEvent.message}</p>}</>:n.message}
                  <small>{n.created_at.slice(0, 16)}</small>
                </button>
              ))
            ) : (
              <p>{t("app.no.new.responses")}</p>
            )}
          </div>
        )}
        {error && (
          <div className="error banner">
            {errorMessage(error)}
            <button onClick={() => setError("")}>{t("common.close")}</button>
          </div>
        )}
        <main>
          {page==="Dashboard"&&<Dashboard me={me} canCreate={edit} onNew={newQuote} onOpen={openQuote} onNavigate={navigate}/>}
          {page === "Quotations" &&
            (selected ? (
              <Editor
                beforeLeave={beforeLeave}
                record={selected === "new" ? null : selected}
                me={me}
                onSaved={(r: any) => {
                  select(r);
                }}
                onBack={() => {
                  navigate("Quotations");
                }}
                onNew={newQuote}
              />
            ) : (
              <>
                <div className="page-heading">
                  <div>
                    <div className="eyebrow">{t("app.travel.quotations")}</div>
                    <h1>{t("app.quotations")}</h1>
                    <p>{t("app.plan.trips.calculate.prices.clearly.and.continue.negotiations")}</p>
                  </div>
                  {edit && (
                    <button className="primary" onClick={newQuote}>
                      <Plus size={18} />{t("quotations.create")}</button>
                  )}
                </div>
                <section className="list-surface">
                  <div className="filters">
                    <label className="search">
                      <Search size={17} />
                      <input
                        placeholder={t("app.search.customer.trip.or.id")}
                        value={search}
                        onChange={(e) => setSearch(e.target.value)}
                      />
                    </label>
                    <select
                      aria-label={t("app.year")}
                      value={year}
                      onChange={(e) => setYear(e.target.value)}
                    >
                      <option value="">{t("app.all.years")}</option>
                      {Array.from(
                        new Set(quotes.map((q) => workspaceMonth(q.created_at).slice(0,4))),
                      ).map((y) => (
                        <option key={y}>{y}</option>
                      ))}
                    </select>
                    <select
                      aria-label={t("app.month")}
                      value={month}
                      onChange={(e) => setMonth(e.target.value)}
                    >
                      <option value="">{t("app.all.months")}</option>
                      {Array.from({ length: 12 }, (_, i) => (
                        <option key={i} value={String(i + 1).padStart(2, "0")}>
                          {new Date(2026, i, 1).toLocaleDateString("id-ID", {
                            month: "long",
                          })}
                        </option>
                      ))}
                    </select>
                    <select
                      aria-label={t("app.quotation.status")}
                      value={status}
                      onChange={(e) => setStatus(e.target.value)}
                    >
                      <option value="">{t("app.all.statuses")}</option>
                      {salesStatuses.map((s) => (
                        <option key={s} value={s}>{salesStatusLabel(s)}</option>
                      ))}
                    </select>
                    <select
                      aria-label={t("app.owner")}
                      value={owner}
                      onChange={(e) => setOwner(e.target.value)}
                    >
                      <option value="">{t("app.all.owners")}</option>
                      {Array.from(
                        new Map(
                          quotes.map((q) => [q.owner_id, q.owner_name]),
                        ).entries(),
                      ).map(([id, name]) => (
                        <option key={id} value={id}>
                          {name}
                        </option>
                      ))}
                    </select>
                  </div>
                  {groups.length ? (
                    groups.map((group) => (
                      <details className="month-group" key={group} open>
                        <summary>
                          {new Date(group + "-01T12:00:00").toLocaleDateString(
                            "id-ID",
                            { month: "long", year: "numeric" },
                          )}
                          <span>
                            {
                              filtered.filter((q) =>
                                workspaceMonth(q.created_at)===group,
                              ).length
                            }{" "}
                            quotation
                          </span>
                        </summary>
                        <div className="quotation-list-wrap"><QuotationList quotes={filtered.filter(q=>workspaceMonth(q.created_at)===group)} user={me.user} onOpen={openQuote} onChanged={refreshQuotes}/></div>
                      </details>
                    ))
                  ) : (
                    <div className="empty">
                      <Files size={32} />
                      <h3>{t("app.no.matching.quotations")}</h3>
                      <p>{t("app.create.a.quotation.or.adjust.your.search.filters")}</p>
                    </div>
                  )}
                </section>
                <div className="bottom-note">
                  <span>{filtered.length}{" "}{t("app.results.shown")}</span>
                </div>
              </>
            ))}
          {page === "Persetujuan Itinerary & Biaya" && <ApprovalDashboard me={me} filters={approvalFilters} onOpen={(id:string)=>openQuote(id,4)}/>}
          {page === "Katalog Layanan" && <Catalog me={me} />}{" "}
          {page === "Kurs & Kebijakan" && <Settings me={me} />}{" "}
          {page === "Integrasi & Salinan Data" && <Integrations me={me} />}
          {page === "Pengaturan Email" && roles.includes("Admin") && <EmailSettings />}
        </main>
        <div className="app-footer">
          TRAVEL KIF <span>Quotation Workspace · Internal</span>
        </div>
      </div>
    </div>
  );
}
