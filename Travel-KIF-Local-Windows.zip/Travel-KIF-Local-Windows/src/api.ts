import {t} from "./i18n";
let quotaBlockedUntil=0;
const inFlightReads=new Map<string,Promise<any>>();
export async function api(path:string,body?:unknown,method?:string,signal?:AbortSignal):Promise<any>{
  const read=(method??(body===undefined?'GET':'POST'))==='GET';
  // Never share a read across a mutation or a profile/login transition.
  if(!read)inFlightReads.clear();
  if(!read||signal)return request(path,body,method,signal);
  const existing=inFlightReads.get(path);if(existing)return existing;
  const pending=request(path,body,method,signal);inFlightReads.set(path,pending);
  try{return await pending;}finally{if(inFlightReads.get(path)===pending)inFlightReads.delete(path);}
}
async function request(path:string,body?:unknown,method?:string,signal?:AbortSignal):Promise<any>{
  if(Date.now()<quotaBlockedUntil)throw Object.assign(new Error(t("errors.database.daily.limit")),{status:503,code:"DATABASE_DAILY_LIMIT"});
  const r = await fetch("/api" + path, {
    signal,
    method: method ?? (body === undefined ? "GET" : "POST"),
    headers: body === undefined ? {} : { "Content-Type": "application/json" },
    body: body === undefined ? undefined : JSON.stringify(body),
  });
  const data: any = await r.json();
  if(data.code==="DATABASE_DAILY_LIMIT"){
    const reset=new Date();reset.setUTCHours(24,0,0,0);quotaBlockedUntil=reset.getTime();
  }
  if (!r.ok) { const error = Object.assign(new Error(data.error || "Permintaan gagal"), {status:r.status}); throw error; }
  return data;
}
export function money(n: number | null | undefined, currency = "EUR") {
  return n == null
    ? t("common.unavailable")
    : new Intl.NumberFormat("id-ID", {
        style: "currency",
        currency,
        maximumFractionDigits: 2,
      }).format(n);
}
export function percent(n: number | null | undefined) {
  return n == null
    ? "—"
    : new Intl.NumberFormat("id-ID", {
        style: "percent",
        maximumFractionDigits: 2,
      }).format(n);
}
