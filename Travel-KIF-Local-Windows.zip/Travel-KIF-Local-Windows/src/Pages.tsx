import {errorMessage,t,stateLabel} from "./i18n";
import { isOpsArchived, opsArchiveAt } from "../shared/ops";
import { useEffect, useState } from "react";
import { Plus, Search, Upload, RefreshCw, Download } from "lucide-react";
import { api, money } from "./api";
import {
  Field,
  Modal,
  Badge,
  Check,
  currencies,
  categoryOptions,
} from "./components";
import { LineEditor } from "./LineEditor";
import { newLine } from "../shared/model";
function useAction() {
  const [error, setError] = useState(""),
    [notice, setNotice] = useState("");
  const act = async (fn: () => Promise<any>) => {
    setError("");
    setNotice("");
    try {
      return await fn();
    } catch (e) {
      setError((e as Error).message);
      return null;
    }
  };
  return { act, error, notice, setNotice };
}
function Message({ error, notice }: any) {
  return (
    <>
      {error && (
        <p role="alert" className="error">
          {errorMessage(error)}
        </p>
      )}
      {notice && (
        <p role="status" className="info">
          {errorMessage(notice)}
        </p>
      )}
    </>
  );
}
export function Catalog({ me }: any) {
  const [items, setItems] = useState<any[]>([]),
    [search, setSearch] = useState(""),
    [cat, setCat] = useState(""),
    [edit, setEdit] = useState<any>(),
    [history, setHistory] = useState<any[] | null>(null),
    [importOpen, setImportOpen] = useState(false);
  const a = useAction();
  const can = me.user.roles.some((r: string) => ["Admin", "OPS"].includes(r));
  const canEditCatalog = me.user.roles.some((r: string) => ["Admin", "OPS", "TC", "Finance", "Director"].includes(r));
  const load = () => a.act(async () => setItems(await api("/catalog")));
  useEffect(() => {
    load();
  }, []);
  return (
    <>
      <div className="page-heading">
        <div>
          <div className="eyebrow">{t("pages.reusable.data")}</div>
          <h1>{t("pages.service.catalog")}</h1>
          <p>{t("pages.historical.prices.and.supplier.references.with.usage.context")}</p>
        </div>
        {can && (
          <div className="actions">
            <button onClick={() => setImportOpen(true)}>
              <Upload size={16} />{t("pages.import.catalog")}</button>
            <button className="primary" onClick={() => setEdit(newLine())}>
              <Plus size={16} />{t("pages.add.service")}</button>
          </div>
        )}
      </div>
      <Message {...a} />
      <div className="filters">
        <label className="search">
          <Search size={17} />
          <input
            placeholder={t("pages.search.city.route.or.service")}
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </label>
        <select
          aria-label={t("pages.catalog.category")}
          value={cat}
          onChange={(e) => setCat(e.target.value)}
        >
          <option value="">{t("pages.all.categories")}</option>
          {categoryOptions.map((c) => (
            <option key={c.value} value={c.value}>
              {c.label}
            </option>
          ))}
        </select>
      </div>
      <div className="catalog-grid">
        {items
          .filter(
            (x) =>
              (!cat || x.category === cat) &&
              (x.label + " " + x.city)
                .toLowerCase()
                .includes(search.toLowerCase()),
          )
          .map((x) => (
            <article className="catalog-card" key={x.id}>
              <div className="section-heading">
                <span className="eyebrow">
                  {x.city || t("pages.location.not.entered")}
                </span>
                <Badge tone="amber">{x.data.priceStatus}</Badge>
              </div>
              <h2>{x.label}</h2>
              <p>{x.data.supplier || t("pages.supplier.not.entered")}</p>
              <div className="catalog-price">
                {money(x.data.unitPrice, x.data.currency)}
                <small>
                  /{" "}
                  {x.data.basis === "supplier-total"
                    ? t("pages.supplier.total")
                    : x.data.unit}
                </small>
              </div>
              <p>
                {x.data.start || t("pages.date.not.entered")} —{" "}
                {x.data.end || t("pages.not.entered")}
              </p>
              <p>{x.data.notes}</p>
              <small>{t("pages.source")}{x.data.source}
                <br />{t("pages.recorded")}{x.data.recordedAt?.slice(0, 10)}
              </small>
              <footer>
                <button
                  onClick={() =>
                    a.act(async () =>
                      setHistory(await api("/catalog/" + x.id + "/history")),
                    )
                  }
                >{t("pages.price.history")}</button>
                {canEditCatalog && (
                  <button onClick={() => setEdit({...x.data,id:x.id})}>{t("pages.edit.price.details")}</button>
                )}
              </footer>
            </article>
          ))}
      </div>
      <p className="muted">{t("pages.price.validation.does.not.guarantee.availability.demo.data.is")}</p>
      {edit && (
        <LineEditor
          line={edit}
          title={t("pages.edit.catalog.service.price")}
          onClose={() => setEdit(undefined)}
          onSave={(l) =>
            a.act(async () => {
              await api("/catalog", l);
              setEdit(undefined);
              load();
            })
          }
        />
      )}{" "}
      {history && (
        <Modal title={t("pages.catalog.price.history")} onClose={() => setHistory(null)}>
          {history.map((h) => (
            <section className="card" key={h.id}>
              <strong>
                {money(h.data.unitPrice, h.data.currency)} · {h.data.basis}
              </strong>
              <p>
                {h.created_at} · {h.data.priceStatus}
              </p>
              <p>
                {h.data.source} · {h.data.start} — {h.data.end}
              </p>
            </section>
          ))}
        </Modal>
      )}
      {importOpen && (
        <ImportModal
          onClose={() => setImportOpen(false)}
          onDone={load}
          me={me}
        />
      )}
    </>
  );
}
function parseCSV(text: string) {
  const rows: string[][] = [];
  let row: string[] = [],
    cell = "",
    quote = false;
  for (let i = 0; i < text.length; i++) {
    const ch = text[i];
    if (ch === '"') {
      if (quote && text[i + 1] === '"') {
        cell += '"';
        i++;
      } else quote = !quote;
    } else if (ch === "," && !quote) {
      row.push(cell);
      cell = "";
    } else if (ch === "\n" && !quote) {
      row.push(cell.replace(/\r$/, ""));
      rows.push(row);
      row = [];
      cell = "";
    } else cell += ch;
  }
  if (cell || row.length) {
    row.push(cell.replace(/\r$/, ""));
    rows.push(row);
  }
  if (quote) throw Error("CSV memiliki tanda kutip yang tidak tertutup.");
  return rows;
}
function ImportModal({ onClose, onDone, me }: any) {
  const [rows, setRows] = useState<any[]>([]),
    [preview, setPreview] = useState<any[]>([]),
    [sheet, setSheet] = useState("Transport"),
    [busy, setBusy] = useState(false);
  const a = useAction();
  const inspect = async (raw: any[]) => {
    setRows(raw);
    setPreview(await api("/import/preview", { rows: raw }));
  };
  const read = async (file: File) => {
    if (file.size > 2e6) throw Error("File maksimal 2 MB.");
    let matrix: any[][] = [];
    if (file.name.endsWith(".xlsx")) {
      const ExcelJS = await import("exceljs");
      const wb = new ExcelJS.default.Workbook();
      await wb.xlsx.load(await file.arrayBuffer());
      for (const ws of wb.worksheets) {
        const local: any[][] = [];
        ws.eachRow((row) =>
          local.push(
            (row.values as any[])
              .slice(1)
              .map((v) =>
                v && typeof v === "object"
                  ? "result" in v
                    ? v.result
                    : (v.text ?? "")
                  : v,
              ),
          ),
        );
        if (local.length) {
          const [headers, ...data] = local;
          matrix.push(
            ...data
              .filter((r) => r.some(Boolean))
              .map((r) => headers.map((_: any, i: number) => r[i] ?? "")),
          );
          if (!matrix.length) continue;
        }
      }
      const all: any[] = [];
      for (const ws of wb.worksheets) {
        const data: any[][] = [];
        ws.eachRow((r) =>
          data.push(
            (r.values as any[])
              .slice(1)
              .map((v) =>
                typeof v === "object" && v !== null
                  ? (v.result ?? v.text ?? "")
                  : v,
              ),
          ),
        );
        const [headers, ...rs] = data;
        if (headers)
          all.push(
            ...rs
              .filter((r) => r.some((v) => v !== "" && v != null))
              .map((r) =>
                Object.fromEntries(headers.map((h, i) => [h, r[i] ?? ""])),
              ),
          );
      }
      await inspect(all);
      return;
    }
    matrix = parseCSV(await file.text());
    const [headers, ...data] = matrix;
    await inspect(
      data
        .filter((r) => r.some(Boolean))
        .map((r) =>
          Object.fromEntries(
            headers.map((h, i) => [h.replace(/^\uFEFF/, ""), r[i] ?? ""]),
          ),
        ),
    );
  };
  return (
    <Modal title={t("pages.import.catalog.preview.first")} onClose={onClose} wide>
      <p>{t("pages.d1.becomes.the.authoritative.record.after.import.re.imports")}</p>
      <div className="actions">
        <a className="button" href="/templates/catalog-import.xlsx" download>{t("pages.xlsx.template.7.tabs")}</a>
        <a className="button" href="/templates/catalog-import.csv" download>{t("pages.template.csv")}</a>
        <label className="button">{t("pages.select.csv.xlsx")}<input
            aria-label={t("pages.catalog.import.file")}
            type="file"
            accept=".csv,.xlsx"
            onChange={(e) =>
              e.target.files?.[0] &&
              a.act(async () => {
                setBusy(true);
                try {
                  await read(e.target.files![0]);
                } finally {
                  setBusy(false);
                }
              })
            }
          />
        </label>
      </div>
      <details>
        <summary>{t("pages.fetch.from.google.sheets")}</summary>
        <p>
          {me.integrations.sheetInput
            ? t("pages.input.connection.configured")
            : t("pages.google.sheets.input.is.not.connected")}
        </p>
        <Field label={t("pages.input.tab.name")} value={sheet} onChange={setSheet} />
        <button
          disabled={!me.integrations.sheetInput}
          onClick={() =>
            a.act(async () =>
              inspect(await api("/import/sheets", { tab: sheet })),
            )
          }
        >{t("pages.fetch.validate")}</button>
      </details>
      <Message {...a} />
      {busy && <p>{t("pages.reading.file")}</p>}
      {preview.length > 0 && (
        <>
          <div className="table-scroll">
            <table>
              <thead>
                <tr>
                  <th>{t("pages.row")}</th>
                  <th>{t("pages.status")}</th>
                  <th>{t("pages.service.message")}</th>
                </tr>
              </thead>
              <tbody>
                {preview.map((p) => (
                  <tr key={p.row}>
                    <td>{p.row}</td>
                    <td>
                      <Badge
                        tone={
                          ["error", "duplicate"].includes(p.state)
                            ? "amber"
                            : "green"
                        }
                      >
                        {p.state}
                      </Badge>
                    </td>
                    <td>{p.data?.label ?? p.message}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <button
            className="primary"
            disabled={preview.some((p) =>
              ["error", "duplicate"].includes(p.state),
            )}
            onClick={() =>
              a.act(async () => {
                await api("/import/apply", { rows });
                a.setNotice("Import tersimpan.");
                setPreview(await api("/import/preview", { rows }));
                onDone();
              })
            }
          >{t("pages.apply.import.to.catalog")}</button>
        </>
      )}
    </Modal>
  );
}
export function Ops({ me, onOpen }: any) {
  const [archive, setArchive] = useState(false);
  const [clock, setClock] = useState(Date.now());
  const [items, setItems] = useState<any[]>([]),
    [answer, setAnswer] = useState<any>();
  const a = useAction(),
    can = me.user.roles.some((r: string) => ["OPS", "Admin"].includes(r));
  const load = () => a.act(async () => setItems(await api("/ops")));
  useEffect(() => {
    load();
  }, []);
  useEffect(() => { const id = setInterval(() => setClock(Date.now()), 60000); return () => clearInterval(id); }, []);
  const visible = items.filter(o => isOpsArchived(o, clock) === archive);
  return (
    <>
      <div className="page-heading">
        <div>
          <div className="eyebrow">{t("pages.operational.coordination")}</div>
          <h1>{t("pages.price.requests")}</h1>
          <p>{t("pages.route.participants.and.requirements.come.from.the.quotation")}</p>
        </div>
        <button onClick={load}>
          <RefreshCw size={16} />{t("pages.reload")}</button>
      </div>
      <Message {...a} />
      <div className="actions" style={{ marginBottom: 16 }}>
        <button aria-pressed={!archive} className={!archive ? "primary" : ""} onClick={() => setArchive(false)}>{t("approvaldashboard.active")}{items.filter(o => !isOpsArchived(o, clock)).length})</button>
        <button aria-pressed={archive} className={archive ? "primary" : ""} onClick={() => setArchive(true)}>{t("approvaldashboard.archived")}{items.filter(o => isOpsArchived(o, clock)).length})</button>
      </div>
      <p>{t("pages.completed.requests.are.automatically.archived.one.month.after.tc")}</p>
      {!visible.length && (
        <section className="card empty">
          <h2>{archive ? t("pages.no.archived.requests") : t("pages.no.active.price.requests")}</h2>
          <p>{t("pages.tc.can.request.prices.from.the.cost.analysis.of")}</p>
        </section>
      )}
      <div className="ops-grid">
      {[...visible].sort((a, b) => Number(b.status === "Waiting") - Number(a.status === "Waiting") || b.updated_at.localeCompare(a.updated_at)).map((o) => (
        <section className="card ops-card" key={o.id}>
          <div className="section-heading">
            <div>
              <Badge tone={o.status === "Waiting" ? "amber" : "green"}>
                {archive ? t("approvaldashboard.archived.cfc46") : o.status === "Completed" ? t("pages.complete.applied.by.tc") : o.status === "Waiting" ? t("pages.awaiting.prices") : t("pages.response.available")}
              </Badge>
              <h2>{o.context.trip}</h2>
            </div>
            <button onClick={() => onOpen(o.quote_id)}>{t("pages.open.quotation")}</button>
          </div>
          <div className="form-grid three">
            <div>
              <small>{t("pages.route")}</small>
              <strong>{o.context.route}</strong>
            </div>
            <div>
              <small>{t("dashboard.period")}</small>
              <strong>
                {o.context.start} – {o.context.end}
              </strong>
            </div>
            <div>
              <small>{t("pages.travelling.participants")}</small>
              <strong>{o.context.travelers}{" "}{t("pages.people")}</strong>
            </div>
          </div>
          {o.status === "Completed" && <p><small>{archive ? t("messages.archived") : t("pages.archived")}: {new Date(opsArchiveAt(o.updated_at)).toLocaleDateString("id-ID", {timeZone:"Asia/Jakarta"})}</small></p>}
          {can && o.status !== "Completed" && (
            <button
              className={o.response ? "ops-answer-button" : "primary ops-answer-button"}
              onClick={() =>
                setAnswer({
                  id: o.id,
                  line: o.response ?? {
                    ...newLine(),
                    label: "Transport " + o.context.route,
                    city: o.context.route,
                    start: o.context.start,
                    end: o.context.end,
                  },
                })
              }
            >
              {o.response ? t("pages.edit.supplier.response") : t("pages.enter.supplier.response")}
            </button>
          )}
          <details className="ops-details">
            <summary>{t("pages.view.details")}{" "}{o.context.transport.length}{" "}{t("pages.services")}{o.response ? " · Jawaban supplier tersedia" : ""}</summary>
          <p>{o.context.notes}</p>
          <p>{t("pages.requested")}{o.requester}{" "}{t("pages.assigned.to")}{" "}
            {o.assignee_id || t("pages.not.yet.assigned.to.ops")}{" "}{t("pages.updated")}{" "}{o.updated_at}
          </p>
          {o.context.transport.map((l: any) => (
            <p key={l.id}>
              {l.label} · {l.quantity}{" "}{t("pages.vehicles")}{" "}{l.factor}{" "}{t("pages.days.seats")}{" "}
              {l.capacity ?? t("pages.not.specified")}
            </p>
          ))}
          {o.response && (
            <div className="info">
              {o.response.supplier} ·{" "}
              {money(o.response.unitPrice, o.response.currency)}{" "}{t("pages.includes")}{" "}
              {o.response.includedCosts.join(", ")}
            </div>
          )}
          </details>
        </section>
      ))}
      </div>
      {answer && (
        <LineEditor
          line={answer.line}
          title={t("pages.ops.price.response")}
          onClose={() => setAnswer(undefined)}
          onSave={(line) =>
            a.act(async () => {
              await api("/ops/" + answer.id, { line });
              setAnswer(undefined);
              load();
            })
          }
        />
      )}
    </>
  );
}
export function Settings({ me }: any) {
  const [settings, setSettings] = useState<any>({ policies: [], fx: [] }),
    [fx, setFx] = useState<any>();
  const a = useAction(),
    can = me.user.roles.some((r: string) => ["Finance", "Admin"].includes(r));
  const load = () => a.act(async () => setSettings(await api("/settings")));
  useEffect(() => {
    load();const timer=setInterval(()=>{if(!document.hidden)void load();},60000);return()=>clearInterval(timer);
  }, []);
  const fxUpdated=(f:any)=>f.recordedAt?new Date(f.recordedAt).toLocaleString('id-ID',{timeZone:'Asia/Jakarta',day:'numeric',month:'short',year:'numeric',hour:'2-digit',minute:'2-digit'})+' WIB':t("pages.not.recorded");
  const latestFx = [...settings.fx].filter((f:any)=>f.kind === 'working').filter((f:any,i:number,all:any[])=>all.findIndex(x=>x.from===f.from&&x.to===f.to)===i);
  return (
    <>
      <div className="page-heading">
        <div>
          <div className="eyebrow">{t("pages.one.shared.reference")}</div>
          <h1>{t("pages.exchange.rates.policies")}</h1>
          <p>{t("pages.updates.are.saved.as.new.versions.quotation.snapshots.do")}</p>
        </div>
      </div>
      <Message {...a} />
      <div>
        <section className="card fx-compact">
          <div className="section-heading">
            <h2>{t("pages.exchange.rates.to.rupiah")}</h2>
            {can && <button onClick={() => setFx({ from: "EUR", to: "IDR", rate: latestFx.find((f: any) => f.from === "EUR" && f.to === "IDR")?.rate ?? "", source: "", validFrom: new Date().toISOString().slice(0, 10), validTo: "", kind: "working" })}>{t("pages.set.exchange.rate")}</button>}
          </div>
          {["EUR", "GBP", "CHF", "USD"].map(currency => latestFx.filter((f: any) => f.from === currency && f.to === "IDR").map((f: any) => (
            <div className={`fx-row ${currency === "EUR" ? "fx-primary" : ""}`} key={f.id}>
              <span>1 {f.from}</span>
              <strong>= Rp {Number(f.rate).toLocaleString("id-ID", { maximumFractionDigits: 2 })}</strong>
              <small className="fx-update">{t("pages.last.update")}{" "}{fxUpdated(f)} · {f.origin==='automatic'?'System':f.updatedBy||'Finance'}<br/>{t("pages.source.922ac")}{" "}{f.source||t("pages.not.recorded")}{f.sourceDate&&<>{" "}{t("pages.publication.date")}{" "}{f.sourceDate}</>}</small>
              {can && <button onClick={() => setFx({ ...f, validFrom: new Date().toISOString().slice(0, 10), validTo: "" })} aria-label={t("rates.editPair", {from:f.from,to:'IDR'})}>{t("editor.edit")}</button>}
            </div>
          )))}
          <p className="fx-caption">{t("pages.ecb.check.schedule.daily.at.00.00.wib.finance")}</p>
          {settings.dailyFx?.state === "unavailable" && <p role="status">{errorMessage(settings.dailyFx.message)}</p>}
          <details className="fx-details"><summary>{t("pages.exchange.rate.source.date")}</summary>
            <p>{t("pages.latest.european.central.bank.ecb.publication.with.no.buffer")}</p>
            {Array.from(new Set(latestFx.map((f: any) => t("rates.sourceValidity",{source:f.source,from:f.validFrom,until:f.validTo ? " – " + f.validTo : ""})))).map((source: any) => <p key={source}>{source}</p>)}
            <small>{me.local?t("pages.local.updates.run.while.the.server.and.scheduler.are"):t("pages.onlineExchangeSchedule")}</small>
          </details>
          <details className="fx-details"><summary>{t("pages.other.currency.pairs")}</summary>
            {latestFx.filter((f: any) => f.to !== "IDR").map((f: any) => <div className="fx-row" key={f.id}><span>1 {f.from}</span><strong>= {Number(f.rate).toLocaleString("id-ID", { maximumSignificantDigits: 10 })} {f.to}</strong>{can && <button onClick={() => setFx({ ...f, validFrom: new Date().toISOString().slice(0, 10), validTo: "" })} aria-label={t("rates.editPair", {from:f.from,to:f.to})}>{t("editor.edit")}</button>}<small className="fx-update">{t("pages.last.update")}{" "}{fxUpdated(f)} · {f.origin==='automatic'?'System':f.updatedBy||'Finance'}<br/>{t("pages.source.922ac")}{" "}{f.source||t("pages.not.recorded")}</small></div>)}
          </details>
        </section>

      </div>
      {fx && (
        <Modal title={t("pages.new.exchange.rate.version")} onClose={() => setFx(undefined)}>
          <div className="form-grid">
            <Field
              label={t("pages.from.currency")}
              value={fx.from}
              options={currencies}
              onChange={(v: any) => setFx({ ...fx, from: v })}
            />
            <Field
              label={t("pages.to.currency")}
              value={fx.to}
              options={currencies}
              onChange={(v: any) => setFx({ ...fx, to: v })}
            />
            <Field
              label={`1 ${fx.from} = … ${fx.to}`}
              type="number"
              value={fx.rate}
              onChange={(v: any) => setFx({ ...fx, rate: v })}
            />
            <Field
              label={t("pages.rate.type")}
              value={fx.kind}
              options={["working", "reference"]}
              onChange={(v: any) => setFx({ ...fx, kind: v })}
            />
            <Field
              label={t("pages.source.rate.basis")}
              value={fx.source}
              onChange={(v: any) => setFx({ ...fx, source: v })}
            />
            <Field
              label={t("pages.valid.from")}
              type="date"
              value={fx.validFrom}
              onChange={(v: any) => setFx({ ...fx, validFrom: v })}
            />
            <Field
              label={t("editor.valid.until")}
              type="date"
              value={fx.validTo}
              onChange={(v: any) => setFx({ ...fx, validTo: v })}
            />
          </div>
          <Message {...a} />
          <button
            className="primary"
            onClick={() =>
              a.act(async () => {
                await api("/fx", fx);
                setFx(undefined);
                load();
              })
            }
          >{t("pages.save.exchange.rate.version")}</button>
        </Modal>
      )}

    </>
  );
}
export function Integrations({ me }: any) {
  const [data, setData] = useState<any>(),
    [users, setUsers] = useState<any[]>([]),
    [edit, setEdit] = useState<any>();
  const a = useAction(),
    admin = me.user.roles.includes("Admin");
  const load = () =>
    a.act(async () => {
      setData(await api("/integrations"));
      if (admin) setUsers(await api("/users"));
    });
  useEffect(() => {
    load();
  }, []);
  return (
    <>
      <div className="page-heading">
        <div>
          <div className="eyebrow">{t("pages.verifiable.copies")}</div>
          <h1>{t("pages.integrations.data.copies")}</h1>
          <p>{t("pages.quotations.remain.saved.even.when.external.services.are.unavailable")}</p>
        </div>
        <button onClick={load}>
          <RefreshCw size={16} />{t("pages.reload")}</button>
      </div>
      <Message {...a} />
      <div className="two-col">
        <section className="card">
          <h2>{t("pages.google.sheets")}</h2>
          <Badge tone={data?.status.sheets ? "green" : "amber"}>
            {data?.status.sheets
              ? t("pages.configured.see.sync.status")
              : t("editor.google.sheets.is.not.connected")}
          </Badge>
          <p>{t("pages.d1.google.sheets.all.changes.are.made.in.the")}</p>
          {admin && (
            <div className="actions">
              <button
                disabled={!data?.status.sheets}
                onClick={() =>
                  a.act(async () => {
                    await api("/sheets/setup", {});
                    a.setNotice("Tab siap; hanya tab hasil/snapshot yang diproteksi.");
                  })
                }
              >{t("pages.set.up.output.tabs")}</button>
              <button
                onClick={() =>
                  a.act(async () => {
                    const r = await api("/sync", {});
                    await load();
                    a.setNotice(
                      r.state === "synced"
                        ? "Salinan diperbarui."
                        : r.error || r.state,
                    );
                  })
                }
              >{t("pages.sync.again")}</button>
            </div>
          )}
        </section>

      </div>
      {admin && (
        <section className="card">
          <div className="section-heading">
            <div>
              <h2>{t("pages.independent.backups")}</h2>
              <p>{t("pages.download.a.dated.snapshot.keep.a.copy.outside.this")}</p>
            </div>
            <div className="actions">
              <a className="button" href="/api/backup">
                <Download size={16} />{t("pages.complete.json")}</a>
              <a className="button" href="/api/backup?format=sql">{t("pages.complete.sql")}</a>
              <a className="button" href="/api/backup?format=csv">{t("pages.complete.csv")}</a>
            </div>
          </div>
          <small>{t("pages.see.readme.for.restoring.to.an.empty.local.database")}</small>
        </section>
      )}
      <section className="card">
        <h2>{t("pages.data.copy.queue")}</h2>
        <div className="table-scroll">
          <table>
            <thead>
              <tr>
                <th>{t("pages.quotation")}</th>
                <th>{t("pages.status")}</th>
                <th>{t("pages.attempts")}</th>
                <th>{t("pages.message")}</th>
              </tr>
            </thead>
            <tbody>
              {data?.jobs.map((j: any) => (
                <tr key={j.id}>
                  <td>{j.quote_id}</td>
                  <td>
                    <Badge tone={j.state === "synced" ? "green" : "amber"}>
                      {stateLabel(j.state)}
                    </Badge>
                  </td>
                  <td>{j.attempts}</td>
                  <td>{j.error || "—"}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>
      {admin && (
        <section className="card">
          <div className="section-heading">
            <h2>{t("pages.users.permissions")}</h2>
            <button
              onClick={() =>
                setEdit({
                  id: crypto.randomUUID(),
                  email: "",
                  name: "",
                  roles: ["TC"],
                  active: true,
                  can_edit: false,
                })
              }
            >{t("pages.add.user")}</button>
          </div>
          {users.map((u) => (
            <div className="service-row" key={u.id}>
              <div>
                <strong>{u.name}</strong>
                <small>
                  {u.email} · {u.roles.map((r: string) => r === "Director" ? "Manager" : r).join(", ")}{" "}
                  {u.active ? "" : t("pages.inactive")}
                </small>
              </div>
              <button
                onClick={() =>
                  setEdit({ ...u, active: !!u.active, can_edit: !!u.can_edit })
                }
              >{t("pages.manage.access")}</button>
            </div>
          ))}
        </section>
      )}
      <details className="card">
        <summary>{t("pages.change.history")}</summary>
        {data?.audit.map((e: any) => (
          <p key={e.id}>
            {e.created_at} · {e.actor_id} · {e.action} · {e.entity_id}
          </p>
        ))}
      </details>
      {edit && (
        <Modal title={t("pages.user.permissions")} onClose={() => setEdit(undefined)}>
          <Field
            label={t("itineraryassistant.name")}
            value={edit.name}
            onChange={(v: any) => setEdit({ ...edit, name: v })}
          />
          <Field
            label={t("pages.access.identity.email")}
            value={edit.email}
            onChange={(v: any) => setEdit({ ...edit, email: v })}
          />
          {["TC", "OPS", "Finance", "Director", "Admin"].map((r) => (
            <Check
              key={r}
              label={r === "Director" ? t("costapproval.manager") : r}
              value={edit.roles.includes(r)}
              onChange={(v: boolean) =>
                setEdit({
                  ...edit,
                  roles: v
                    ? [...edit.roles, r]
                    : edit.roles.filter((x: string) => x !== r),
                })
              }
            />
          ))}
          <Check
            label={t("pages.active.user")}
            value={edit.active}
            onChange={(v: any) => setEdit({ ...edit, active: v })}
          />
          <Check
            label={t("pages.explicitly.allow.manager.editing")}
            value={edit.can_edit}
            onChange={(v: any) => setEdit({ ...edit, can_edit: v })}
          />
          <Message {...a} />
          <button
            className="primary"
            onClick={() =>
              a.act(async () => {
                await api("/users", edit);
                setEdit(undefined);
                load();
              })
            }
          >{t("pages.save.permissions")}</button>
        </Modal>
      )}
    </>
  );
}
