import {t} from "./i18n";
import {useState} from 'react';
export function TravelSearchResults({result,start,end,onAdd,editable}:any){
 const [date,setDate]=useState(start),[time,setTime]=useState('12:00'),[added,setAdded]=useState<number[]>([]);
 return <div>
 <div className="form-grid"><label>{t("travelsearchresults.activity.date")}<input type="date" min={start} max={end} value={date} onChange={e=>setDate(e.target.value)}/></label><label>{t("travelsearchresults.activity.time")}<input type="time" value={time} onChange={e=>setTime(e.target.value)}/></label></div>
 {(result.items||[]).map((item:any,i:number)=><section className="card" key={i}>
 <h3>{item.name}</h3><p>{item.city} · {item.address}</p>
 <dl>{[[t("common.opening.hours"),item.hours],['Menu',item.menu],[t("common.public.price"),item.price],[t("common.halal.information"),item.halal]].map(([label,value])=><div key={label}><dt><strong>{label}</strong></dt><dd>{value||t("travelsearchresults.not.found.confirmation.needed")}</dd></div>)}</dl>
 {item.sources.map((s:any,j:number)=><p key={j}><a href={s.url} target="_blank" rel="noreferrer">{s.title}</a></p>)}
 <small>{t("itineraryassistant.searched")}{" "}{new Date(result.checkedAt).toLocaleString('id-ID')}{" "}{t("travelsearchresults.confirm.opening.hours.group.prices.and.availability")}</small>
 <button className="primary" disabled={!editable||added.includes(i)||!date||date<start||date>end||!time} onClick={()=>{onAdd({id:crypto.randomUUID(),date,city:item.city,title:`${time} · ${item.name}`,description:[item.address,`Jam buka: ${item.hours}`,`Menu: ${item.menu}`,`Harga publik (belum dikonfirmasi): ${item.price}`,`Halal: ${item.halal}`,...item.sources.map((s:any)=>`Sumber: ${s.url}`),`Dicari: ${result.checkedAt}`].join('\n').slice(0,4000)});setAdded([...added,i]);}}>{added.includes(i)?t("travelsearchresults.added"):t("travelsearchresults.add.to.itinerary")}</button>
 </section>)}
 <p>{t("travelsearchresults.results.are.added.to.the.draft.itinerary.save.the")}</p>
 </div>;
}
