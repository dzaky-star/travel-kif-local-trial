import {activityLabel,errorMessage,t} from "./i18n";
import {useEffect,useState,useRef} from 'react';
import {api} from './api';
export const approvalStatus:Record<string,string>={get Draft(){return t("common.not.submitted");},get ApprovalWaiting(){return t("common.awaiting.ops.approval");},get ApprovalApproved(){return t("common.ops.approved.awaiting.manager");},get ManagerWaiting(){return t("common.ops.approved.awaiting.manager");},get ManagerApproved(){return t("common.approved.by.ops.manager");},get ManagerReturned(){return t("common.returned.by.manager.owner.changes.needed");},get ManagerRejected(){return t("common.rejected.by.manager");},get ApprovalRejected(){return t("common.rejected.by.ops");},get ApprovalReturned(){return t("common.owner.changes.needed");},get ApprovalCancelled(){return t("common.request.cancelled");},get ApprovalStale(){return t("common.changed.resubmission.needed");}};
export function ApprovalBadge({state}: {state:string}) {return <span className={`approval-badge ${state}`}>{approvalStatus[state]||state}</span>;}
export function CostApproval({record,me,dirty,onSaved}:any){
 const [decision,setDecision]=useState(''),[message,setMessage]=useState(''),[error,setError]=useState(''),[busy,setBusy]=useState(false);
 const [opsReviewerId,setOpsReviewerId]=useState(''),[managerReviewerId,setManagerReviewerId]=useState('');
 const [returnRecipientId,setReturnRecipientId]=useState('');
 const assignment=record?.costReview?.context?JSON.parse(record.costReview.context):{};
 useEffect(()=>{setOpsReviewerId(assignment.opsReviewerId||'');setManagerReviewerId(assignment.managerReviewerId||'');},[record?.id,record?.costReview?.context]);
 const [users,setUsers]=useState<any[]>([]);
 useEffect(()=>{api('/users').then(setUsers).catch(()=>{});},[]);
 const mention=message.match(/@([a-zA-Z0-9._-]*)$/)?.[1];
 const ops=me.user.roles.some((r:string)=>['OPS','Admin'].includes(r)),tc=record&&(((me.user.roles.some((r:string)=>['TC','OPS','Finance'].includes(r))||(me.user.roles.includes('Director')&&me.user.can_edit))&&record.owner_id===me.user.id)||me.user.roles.includes('Admin'));
 const manager=me.user.roles.some((r:string)=>['Director','Admin'].includes(r));
 const isAdmin=me.user.roles.includes('Admin');
 const adminOwned=record?.owner_id===me.user.id?isAdmin:!!users.find(u=>u.id===record?.owner_id)?.roles.includes('Admin');
 const ownAdmin=adminOwned&&record?.owner_id===me.user.id;
 const assignedOps=!ownAdmin&&ops&&(isAdmin||!assignment.opsReviewerId||assignment.opsReviewerId===me.user.id),assignedManager=!ownAdmin&&manager&&(isAdmin||!assignment.managerReviewerId||assignment.managerReviewerId===me.user.id);
 const state=record?.costReview?.status||'Draft',waiting=state==='ApprovalWaiting',managerWaiting=['ManagerWaiting','ApprovalApproved'].includes(state),pending=waiting||managerWaiting;
 const chat=useRef<HTMLDivElement>(null);
 const [history,setHistory]=useState<any[]>([]);
 useEffect(()=>{
   setHistory(record?.costReview?.response?JSON.parse(record.costReview.response):[]);
   if(!record?.id)return;
   let active=true;
   const refresh=()=>api('/cost-approvals/'+record.id).then(r=>{if(active)setHistory(r.history||[]);}).catch(()=>{});
   refresh();
   const timer=setInterval(()=>{if(!document.hidden)void refresh();},60000);
   return()=>{active=false;clearInterval(timer);};
 },[record?.id,record?.current_revision]);

 useEffect(()=>{if(chat.current)chat.current.scrollTop=chat.current.scrollHeight;},[history.length]);
 async function act(action:string){setBusy(true);setError('');try{const r=await api('/cost-approvals/'+record.id,{action,opsReviewerId,managerReviewerId:action==='submit'&&adminOwned?'':managerReviewerId,returnRecipientId,message:action==='comment'?message:'',expectedRevision:record.current_revision});onSaved(r);if(action==='comment')setMessage('');setDecision('');}catch(e){setError((e as Error).message);}finally{setBusy(false);}}
 return <section className="card cost-approval"><div className="section-heading"><h2>{t("costapproval.quotation.approval")}</h2>{assignment.directToManager&&['ManagerWaiting','ManagerApproved'].includes(state)?<span className={`approval-badge ${state}`}>{state==='ManagerApproved'?t("costapproval.approved.by.manager"):t("costapproval.awaiting.manager.approval")}</span>:<ApprovalBadge state={state}/>}</div>
 {!record?<p>{t("costapproval.save.a.draft.to.submit.the.itinerary.and.costs")}</p>:<>
 <div className={`approval-overview ${state}`}>
 {!pending&&state!=='ManagerApproved'&&<p>{t("approval.submitHelp")}</p>}
 {dirty&&<p>{t("costapproval.save.quotation.changes.before.submitting.a.request.or.message")}</p>}
 {waiting&&<p>{ops ? t("costapproval.edit.the.itinerary.cost.items.and.quoted.prices.then") : t("costapproval.ops.is.reviewing.the.itinerary.and.ca.the.owner")}</p>}
 {state==='ManagerApproved'&&<p className="approval-ready">{t("costapproval.approval.complete.ready.to.send.to.the.client")}</p>}
 {managerWaiting&&<p>{assignment.directToManager?t("costapproval.quotation.submitted.directly.to.the.selected.manager"):t("costapproval.ops.has.approved.the.itinerary.and.ca.the.quotation")}</p>}
 {(assignment.opsReviewerName||assignment.managerReviewerName)&&<div className="approval-reviewers"><div><span>OPS</span><strong>{assignment.opsReviewerName||'—'}</strong></div><div><span>Manager</span><strong>{assignment.managerReviewerName||'—'}</strong></div></div>}
 </div>
 <div className="approval-controls actions">
 {((ops&&["ManagerWaiting","ApprovalApproved","ManagerApproved"].includes(state))||(manager&&state==="ManagerApproved"))&&<button disabled={busy||dirty} onClick={()=>act('reopen')}>{t("costapproval.revoke.approval.reopen")}</button>}
 {tc&&!pending&&<button className="approval-submit" disabled={busy||dirty||!(adminOwned?opsReviewerId:(managerReviewerId||opsReviewerId))} onClick={()=>act('submit')}>{history.length?t("costapproval.resubmit.for.approval"):t("costapproval.submit.for.approval")}</button>}
 {tc&&pending&&<><strong>{t("costapproval.request.submitted.awaiting")}{" "}{managerWaiting?assignment.managerReviewerName||t("costapproval.manager"):assignment.opsReviewerName||t("costapproval.ops")}</strong><button disabled={busy||dirty} onClick={()=>{if(window.confirm(t("common.cancel.this.approval.request.the.reviewer.cannot.process.it")))void act('cancel');}}>{t("costapproval.cancel.request")}</button></>}
 {tc&&!pending&&<select aria-label={t("costapproval.request.approval.from")} value={!adminOwned&&managerReviewerId?'manager:'+managerReviewerId:opsReviewerId?'ops:'+opsReviewerId:''} disabled={busy||dirty} onChange={e=>{const [role,id]=e.target.value.split(':');setManagerReviewerId(role==='manager'?id:'');setOpsReviewerId(role==='ops'?id:'');}}><option value="">{t("costapproval.select.a.reviewer.required")}</option>{users.filter(u=>u.active!==0).flatMap(u=>[['OPS','ops','OPS'],['Director','manager','Manager']].filter(([role])=>u.roles.includes(role)&&(!adminOwned||role==='OPS')).map(([,key,label])=><option key={key+u.id} value={key+':'+u.id}>{u.name} · {label}</option>))}</select>}

 {assignedOps&&waiting&&<><label>{t("costapproval.ops.decision")}<select aria-label={t("costapproval.ops.decision")} value={decision} onChange={e=>setDecision(e.target.value)} disabled={busy||dirty}><option value="">{t("costapproval.select.an.action")}</option><option value="approve">{t("costapproval.approve.itinerary.ca")}</option><option value="return">{t("costapproval.return.for.changes")}</option><option value="reject">{t("costapproval.reject.request")}</option></select></label><button className="approval-submit" disabled={busy||dirty||!decision||(decision==='approve'&&!managerReviewerId)} onClick={()=>act(decision)}>{decision==='approve'?t("costapproval.approve.submit.to.manager"):t("costapproval.apply.decision")}</button>{decision==='approve'&&<select aria-label={t("costapproval.request.approval.from")} value={managerReviewerId} disabled={busy||dirty} onChange={e=>setManagerReviewerId(e.target.value)}><option value="">{t("costapproval.select.a.reviewer.required")}</option>{users.filter(u=>u.active!==0&&u.roles.includes('Director')).map(u=><option key={u.id} value={u.id}>{u.name} · Manager</option>)}</select>}</>}
 {assignedManager&&managerWaiting&&<><label>{t("costapproval.manager.decision")}<select aria-label={t("costapproval.manager.decision")} value={decision} onChange={e=>setDecision(e.target.value)} disabled={busy||dirty}><option value="">{t("costapproval.select.an.action")}</option><option value="managerApprove">{t("costapproval.approve.quotation")}</option><option value="managerReturn">{t("costapproval.return.for.changes")}</option><option value="managerReject">{t("costapproval.reject.quotation")}</option></select></label><button className="approval-submit" disabled={busy||dirty||!decision||(decision==='managerReturn'&&!returnRecipientId)} onClick={()=>act(decision)}>{t("costapproval.apply.decision")}</button>{decision==='managerReturn'&&<select aria-label={t("costapproval.return.to")} value={returnRecipientId} onChange={e=>setReturnRecipientId(e.target.value)} disabled={busy||dirty}><option value="">{t("costapproval.return.to.required")}</option><option value={record.owner_id}>{record.owner_name||record.input.ownerName}{" "}{t("costapproval.quotation.owner")}</option>{users.filter(u=>u.active!==0&&u.roles.includes('OPS')&&u.id!==record.owner_id).map(u=><option key={u.id} value={u.id}>{u.name} · OPS</option>)}</select>}</>}
 </div>
 {['return','reject','managerReject'].includes(decision)&&<small>{t("approval.returnToOwner", {name:record.owner_name||record.input.ownerName})}</small>}
 {decision==='managerReturn'&&<small>{t("costapproval.select.the.quotation.owner.or.ops.for.changes.explain")}</small>}
 <div ref={chat} className="approval-history" aria-label={t("costapproval.request.history")}><h3>{t("costapproval.quotation.discussion")}</h3>{!history.length&&<small>{t("costapproval.discussion.between.tc.ops.and.managers.will.appear.here")}</small>}{history.map((e:any)=><article className={e.message ? "approval-message" : "approval-event"} key={e.id}><header className="approval-message-meta"><strong>{e.actor}{!e.message && <> · {activityLabel(e)}{e.recipientName&&' → '+e.recipientName}</>}</strong><time dateTime={e.time}>{new Date(e.time).toLocaleString('id-ID',{day:'numeric',month:'short',year:'numeric',hour:'2-digit',minute:'2-digit'})}</time></header>{e.message&&<p>{e.message}</p>}</article>)}</div>
 {<><textarea aria-label={t("costapproval.request.message.and.response")} rows={3} maxLength={4000} value={message} onChange={e=>setMessage(e.target.value)} placeholder={t("costapproval.write.a.message.to.the.team.type.to.mention")} disabled={busy}/>
 {mention!==undefined&&<div className="mention-options">{users.filter(u=>u.active!==0&&u.username&&u.username.toLowerCase().startsWith(mention.toLowerCase())).map(u=><button type="button" key={u.id} onClick={()=>setMessage(message.replace(/@[a-zA-Z0-9._-]*$/, '@'+u.username+' '))}>@{u.username} · {u.name}</button>)}</div>}
 <div className="actions">
 <button disabled={busy||dirty||!message.trim()} onClick={()=>act('comment')}>{t("costapproval.send.comment")}</button>
 </div></>}{error&&<p role="alert">{errorMessage(error)}</p>}</>}
 </section>;
}
