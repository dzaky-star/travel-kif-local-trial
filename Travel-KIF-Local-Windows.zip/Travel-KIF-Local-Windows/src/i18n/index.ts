import validationKeys from './validation-keys.json';
import {useSyncExternalStore} from 'react';
import id from './id.json';
import en from './en.json';
export type Language='id'|'en';
export type TranslationKey=keyof typeof id;
let language:Language='id';
let userId:string|null=null;
const listeners=new Set<()=>void>();
export const languageStorageKey=(user:string|null)=>'travel-kif:ui-language:'+(user||'guest');
export function readLanguage(user:string|null):Language {try{const value=localStorage.getItem(languageStorageKey(user));return value==='en'?'en':'id';}catch{return 'id';}}
function emit(){if(typeof document!=='undefined')document.documentElement.lang=language;listeners.forEach(fn=>fn());}
export function setLanguageUser(user:string|null){if(userId===user)return;userId=user;language=readLanguage(user);emit();}
export function setLanguage(next:Language){if(next!=='id'&&next!=='en')return;language=next;try{localStorage.setItem(languageStorageKey(userId),next);}catch{/* In-memory preference remains usable when storage is blocked. */}emit();}
export const getLanguage=()=>language;
export function useLanguage(){return useSyncExternalStore(fn=>{listeners.add(fn);return()=>{listeners.delete(fn);};},getLanguage,()=> 'id' as Language);}
export function t(key:TranslationKey,params:Record<string,string|number>={}):string {
 const dictionary=language==='en'?en:id;
 const value=(dictionary as Record<string,string>)[key]||(id as Record<string,string>)[key];
 if(!value){if((import.meta as any).env?.DEV)console.warn('Missing UI translation:',key);return language==='en'?'Text unavailable':'Teks belum tersedia';}
 return value.replace(/\{(\w+)\}/g,(_,name)=>String(params[name]??''));
}
export const uiLocale=()=>language==='en'?'en-GB':'id-ID';

import stateKeys from './state-keys.json';
import messageKeys from './message-keys.json';
/** Only application enum values or internal save/sync states belong here. */
export function stateLabel(value:string):string {const key=(stateKeys as Record<string,TranslationKey>)[value];return key?t(key):value;}
/** Error/validation/notice boundary only; never pass quotation content or comments. */
export function errorMessage(value:any):string {
 if(!value)return '';
 if(typeof value!=='string')return value.issues?value.issues.map((x:any)=>`${x.path.join('.')}: ${t("common.validationField")}`).join('; '):String(value);
 const key=(messageKeys as Record<string,TranslationKey>)[value];
 if(key)return t(key);
 // Known calculation-message contracts only. Captured business names are inserted verbatim.
 for(const validationKey of validationKeys){const template=id[validationKey as TranslationKey];const [before,after]=template.split('{value}');if(value.startsWith(before)&&value.endsWith(after)&&value.length>=before.length+after.length)return t(validationKey as TranslationKey,{value:value.slice(before.length,after.length?-after.length:undefined)});}
 return value;
}

const activityKeys:Record<string,TranslationKey>={"submit": "activity.submit", "cancel": "activity.cancel", "save": "activity.save", "managerSave": "activity.managerSave", "approve": "activity.approve", "reject": "activity.reject", "return": "activity.return", "managerApprove": "activity.managerApprove", "managerReturn": "activity.managerReturn", "managerReject": "activity.managerReject", "reopen": "activity.reopen", "comment": "activity.comment"};
export function activityLabel(event:{action?:string;label?:string}){const key=activityKeys[event.action||" "];return key?t(key):event.label||"";}
