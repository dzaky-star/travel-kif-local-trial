import {t} from "./i18n";
import type { Quote } from '../shared/model';
function quoteRates(q: Quote) {
  const pairs = new Map<string, [string, string]>();
  for (const l of q.lines.filter(l => !l.addon || l.included))
    if (l.currency !== q.baseCurrency) pairs.set(`${l.currency}/${q.baseCurrency}`, [l.currency, q.baseCurrency]);
  if (q.baseCurrency !== q.sellCurrency) pairs.set(`${q.baseCurrency}/${q.sellCurrency}`, [q.baseCurrency, q.sellCurrency]);
  const rates = [...pairs.values()].map(([from, to]) => ({ from, to,
    fx: q.fx.find(f => f.kind === 'working' && f.from === from && f.to === to)
      ?? q.fx.find(f => f.kind === 'working' && f.from === to && f.to === from)
  }));
  return rates;
}
export function QuoteFx({ q }: { q: Quote }) {
  const rates = quoteRates(q);
  const missing = rates.filter(r => !r.fx);
  return <section className="card" aria-label={t("quotefx.quotation.exchange.rates")}>
    <h3>{t("quotefx.exchange.rates.used.by.this.quotation")}</h3>
    <p>{t("quotefx.rates.are.saved.per.revision.finance.rate.changes.do")}</p>
    {rates.map(({from,to,fx}) => <p key={`${from}/${to}`}>
      <strong>{fx ? `1 ${from} = ${(fx.from === from ? fx.rate : 1 / fx.rate).toLocaleString('id-ID', {maximumFractionDigits: 8})} ${to}` : t("rates.awaitingPair", {from,to})}</strong>
      {fx && <small>{t("pages.source")}{" "}{fx.source}{" "}{t("quotefx.recorded")}{" "}{fx.recordedAt.slice(0,10)}{" "}{t("quotefx.valid")}{" "}{fx.validFrom}–{fx.validTo}{" "}{t("quotefx.version")}{" "}{fx.id}
        {(q.start < fx.validFrom || q.start > fx.validTo) && ' · Di luar masa berlaku untuk tanggal perjalanan'}
      </small>}
    </p>)}
    {!rates.length && <p>{t("quotefx.no.conversion.needed.costs.and.quotation.use.the.same")}</p>}
    {missing.length > 0 && <p role="status">{t("quotefx.tc.can.continue.editing.and.saving.a.draft.converted")}</p>}
    <small>{t("quotefx.use.edit.quotation.exchange.rates.to.apply.current.rates")}</small>
  </section>;
}

export function DashboardFx({ q }: { q: Quote }) {
  const rates = quoteRates(q);
  return <div className="dashboard-fx">
    {!rates.length && <small>{t("quotefx.no.conversion")}{q.sellCurrency})</small>}
    {rates.map(({from,to,fx}) => <div key={`${from}/${to}`}>
      <strong>{fx ? `1 ${from} = ${(fx.from === from ? fx.rate : 1 / fx.rate).toLocaleString('id-ID', {maximumFractionDigits: 8})} ${to}` : t("rates.missingPair", {from,to})}</strong>
      {fx && <small title={t("rates.versionSource", {version:fx.id,source:fx.source})}>{fx.origin === "manual" ? "Koreksi Finance · " : ""}{t("quotefx.rate.date")}{" "}{new Date(fx.effectiveDate ? fx.effectiveDate + "T00:00:00+07:00" : fx.recordedAt).toLocaleDateString('id-ID', {day:'2-digit',month:'short',year:'numeric',timeZone:'Asia/Jakarta'})}{fx.sourceDate && t("rates.sourceDate", {date:fx.sourceDate})}</small>}
    </div>)}
  </div>;
}
