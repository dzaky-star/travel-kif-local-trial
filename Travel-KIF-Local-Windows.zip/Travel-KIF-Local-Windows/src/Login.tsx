import {errorMessage,t} from "./i18n";
import {useState} from 'react';
import {Eye,EyeOff,LoaderCircle} from 'lucide-react';
import {api} from './api';
export function Login({onLogin}:{onLogin:()=>void}){
 const [username,setUsername]=useState(''),[password,setPassword]=useState(''),[show,setShow]=useState(false),[remember,setRemember]=useState(false),[busy,setBusy]=useState(false),[error,setError]=useState('');
 return <main className="login-page"><form className="login-card" onSubmit={async e=>{e.preventDefault();setBusy(true);setError('');try{await api('/login',{username,password,remember});onLogin();}catch(e){setError((e as Error).message);}finally{setBusy(false);}}}>
 <img src="/travel-kif-logo.png" alt="Travel KIF"/>
 <h1>{t("login.sign.in.to.quotations")}</h1><p>{t("login.use.your.team.account")}</p>
 <label>{t("login.username")}<input autoFocus autoComplete="username" value={username} onChange={e=>setUsername(e.target.value)} required disabled={busy}/></label>
 <label>{t("login.password")}<div className="password-field"><input autoComplete="current-password" type={show?'text':'password'} value={password} onChange={e=>setPassword(e.target.value)} required disabled={busy}/><button type="button" aria-label={show?t("login.hide.password"):t("login.show.password")} onClick={()=>setShow(!show)}>{show?<EyeOff size={18}/>:<Eye size={18}/>}</button></div></label>
 <label className="remember-login"><input type="checkbox" checked={remember} onChange={e=>setRemember(e.target.checked)}/>{" "}{t("login.remember.me.on.this.device.for.30.days")}</label>
 {error&&<p role="alert">{errorMessage(error)}</p>}
 <button className="primary" type="submit" disabled={busy}>{busy?<><LoaderCircle className="login-spinner" size={18}/>{" "}{t("login.signing.in")}</>:t("messages.sign.in")}</button>
 </form></main>;
}
