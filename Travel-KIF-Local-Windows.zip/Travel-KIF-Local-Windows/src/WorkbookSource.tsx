import {t} from "./i18n";
import { type Quote, newLine, type CostLine } from "../shared/model";
import { money } from "./api";
export function WorkbookSource({
  q,
  editable,
  onChoose,
}: {
  q: Quote;
  editable: boolean;
  onChoose: (l: CostLine) => void;
}) {
  const s = q.sourceWorkbook!;
  return (
    <details className="card source-panel">
      <summary>{t("workbooksource.workbook.reference")}{" "}{s.sheet}</summary>
      <p>
        <a href={s.url} target="_blank" rel="noreferrer">{t("workbooksource.open.source.tab.in.google.sheets")}</a>{" "}
        ·{" "}
        {s.kind === "ca"
          ? t("workbooksource.cost.analysis")
          : s.kind === "options"
            ? t("workbooksource.service.quotation.options")
            : t("workbooksource.source.reference")}
      </p>
      {s.originalSelling != null && (
        <p>{t("workbooksource.source.total.price")}{" "}
          <strong>
            {money(s.originalSelling, s.originalCurrency || q.sellCurrency)}
          </strong>
          .{" "}
          {s.originalCost != null && (
            <>{t("workbooksource.source.total.cost")}{" "}
              {money(s.originalCost, s.originalCurrency || q.sellCurrency)}.
            </>
          )}
        </p>
      )}
      {s.options.length > 0 && (
        <details>
          <summary>
            {s.options.length}{t("workbooksource.service.options.from.the.workbook.select.those.to.offer")}</summary>
          <p>{t("workbooksource.alternative.options.are.not.automatically.summed.check.currency.quantity")}</p>
          <div className="table-scroll">
            <table>
              <thead>
                <tr>
                  <th>{t("workbooksource.service.source")}</th>
                  <th>{t("workbooksource.source.cost")}</th>
                  <th>{t("workbooksource.source.selling.price")}</th>
                  <th />
                </tr>
              </thead>
              <tbody>
                {s.options.map((o, i) => (
                  <tr key={i}>
                    <td>
                      {o.label}
                      <small>
                        {o.cell} · {o.notes}
                      </small>
                    </td>
                    <td>
                      {o.currency
                        ? money(o.cost, o.currency)
                        : t("workbook.currencyUnconfirmed",{amount:o.cost??"—"})}
                    </td>
                    <td>
                      {o.currency
                        ? money(o.selling, o.currency)
                        : t("workbook.currencyUnconfirmed",{amount:o.selling??"—"})}
                    </td>
                    <td>
                      <button
                        disabled={!editable}
                        onClick={() =>
                          onChoose({
                            ...newLine(),
                            label: o.label,
                            unitPrice: o.currency ? o.cost : null,
                            currency: o.currency || q.baseCurrency,
                            priceStatus: "historical",
                            source: `${s.sheet}!${o.cell}`,
                            notes: `Biaya sumber: ${o.cost ?? "belum ada"}; jual: ${o.selling ?? "belum ada"}; mata uang: ${o.currency ?? "belum jelas"}. ${o.notes}`,
                            basis: "supplier-total",
                          })
                        }
                      >{t("workbooksource.review.add.service")}</button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </details>
      )}
      <details>
        <summary>{t("workbooksource.view.full.source.tab")}{s.rows.length}{t("workbooksource.populated.rows")}</summary>
        <p>{t("workbooksource.source.values.and.formulas.are.kept.as.import.references")}</p>
        <div className="table-scroll">
          <table className="source-grid">
            <tbody>
              {s.rows.map((row, i) => (
                <tr key={i}>
                  {row.map((c) => (
                    <td key={c.cell}>
                      <small>{c.cell}</small>
                      {c.value === null
                        ? t("workbooksource.no.calculated.value")
                        : String(c.value)}
                      {c.formula && (
                        <details>
                          <summary>{t("workbooksource.source.formula")}</summary>
                          {c.formula}
                        </details>
                      )}
                    </td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </details>
    </details>
  );
}
