import {errorMessage,t,type TranslationKey} from "./i18n";
import {placeWebsite} from '../shared/itinerary-options';
import {useState,useRef,useEffect} from 'react';
import {LoaderCircle} from 'lucide-react';
import {api} from './api';
import {consistentHotels,chooseStayHotel,stayGroups,hotelStays} from '../shared/itinerary-stays';
const customPlaceKeys:Record<string,TranslationKey>={"hotels": "itinerary.custom.hotels", "restaurants": "itinerary.custom.restaurants", "activities": "itinerary.custom.activities"};
const placeNameKeys:Record<string,TranslationKey>={"hotels": "itinerary.name.hotels", "restaurants": "itinerary.name.restaurants", "activities": "itinerary.name.activities"};
export function ItineraryAssistant({q,onApply,enabled,editable,active=true}:any){
 const [messages,setMessages]=useState<{role:string;text:string}[]>([]),[prompt,setPrompt]=useState('Susun itinerary berdasarkan informasi perjalanan dan preferensi pelanggan di atas.'),[result,setResult]=useState<any>(),[busy,setBusy]=useState(false),[error,setError]=useState(''),[mode,setMode]=useState('append'),[applied,setApplied]=useState(false);
 const [selected,setSelected]=useState<Record<string,string[]>>({});
 const [custom,setCustom]=useState<Record<string,string>>({}),[rooms,setRooms]=useState<Record<string,number>>({});
 const request=useRef<{id:string;controller:AbortController}|null>(null);
 const [conflict,setConflict]=useState(false);
 function cancel(){const current=request.current;if(!current)return;request.current=null;current.controller.abort();setBusy(false);setError('Permintaan dibatalkan. Anda dapat mencoba lagi.');void api('/ai/cancel',{requestId:current.id}).catch(()=>{setConflict(true);setError('Pembatalan belum terkonfirmasi. Coba batalkan permintaan sebelumnya.');});}
 useEffect(()=>{if(!active)cancel();},[active]);
 useEffect(()=>()=>{const current=request.current;if(current){request.current=null;current.controller.abort();void api('/ai/cancel',{requestId:current.id}).catch(()=>{});}},[]);
 function addCustom(d:any,kind:string){const name=(custom[d.date+kind]||'').trim();if(!name)return;const dates=kind==='hotels'?(stayGroups(result.days).find(g=>g.some(x=>x.date===d.date))||[d]).map(x=>x.date):[d.date];setResult({...result,days:result.days.map((day:any)=>dates.includes(day.date)?{...day,[kind]:[{name,details:'Permintaan klien / tim',price:'',websiteSourceId:null},...(day[kind]||[]).filter((v:any)=>(typeof v==='string'?v:v.name)!==name)].slice(0,8)}:day)});setSelected(old=>({...old,...Object.fromEntries(dates.map((date:string)=>[date+kind,kind==='hotels'?[name]:[...(old[date+kind]||[]).filter(n=>n!==name),name]]))}));setCustom(v=>({...v,[d.date+kind]:''}));setApplied(false);}
 function manualOption(d:any,kind:string){return <details className="ai-custom-place"><summary>{t(customPlaceKeys[kind])}</summary><label>{t(placeNameKeys[kind])}<input maxLength={200} value={custom[d.date+kind]||''} onChange={e=>setCustom(v=>({...v,[d.date+kind]:e.target.value}))}/></label><button disabled={busy||!custom[d.date+kind]?.trim()} onClick={()=>addCustom(d,kind)}>{t("itineraryassistant.add.select")}</button></details>;}
 const venue=(v:any)=>typeof v==='string'?{name:v,details:'',price:'',websiteSourceId:null}:v;
 const maps=(v:any,city:string)=>`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(venue(v).name+' '+city)}`;
 const safeUrl=(value:string)=>/^https?:\/\//.test(value||'')?value:undefined;
 async function send(){
 if(request.current||busy||result?.days?.length)return;
 const current={id:crypto.randomUUID(),controller:new AbortController()};request.current=current;setConflict(false);
 const next=[...messages,{role:'user',text:prompt}];
 setBusy(true);setError('');try{
 const response:any=await api('/ai/itinerary',{requestId:current.id,context:{trip:q.trip,destination:q.destination,start:q.start,end:q.end,entry:q.entry,exit:q.exit,preferences:q.preferences,passengers:q.passengers.map(({category,age,role,foc}:any)=>({category,age,role,foc})),currency:q.sellCurrency},messages:next},undefined,current.controller.signal);
 if(request.current!==current)return;
 const r=response.days?.length?consistentHotels(response):response;
 setMessages([...next,{role:'assistant',text:[r.message,...r.questions].join('\n')}]);
 if(r.days?.length){setResult(r);setSelected({});setApplied(false);}
 setPrompt('');
 }catch(e){if(request.current!==current)return;setConflict((e as any).status===429);setError(/invalid_union|invalid_type|ZodError|unionErrors/.test((e as Error).message)?'Format jawaban AI belum sesuai. Coba kirim ulang; itinerary sebelumnya tetap tersimpan.':(e as Error).message);}finally{if(request.current===current){request.current=null;setBusy(false);}}}
 function editDay(date:string,field:'description'|'notes',value:string){setResult((old:any)=>({...old,days:old.days.map((day:any)=>day.date===date?{...day,[field]:value}:day)}));setApplied(false);}
 function choose(date:string,kind:string,name:string){const key=date+kind;setSelected(old=>kind==='hotels'?chooseStayHotel(result.days,old,date,name):({...old,[key]:old[key]?.includes(name)?old[key].filter(n=>n!==name):[...(old[key]||[]),name]}));setApplied(false);}
 function options(d:any,kind:'hotels'|'restaurants'|'activities'){
 return (d[kind]||[]).map((raw:any,j:number)=>{const v=venue(raw),url=v.websiteSourceId!==null?safeUrl(result.sources[v.websiteSourceId]?.url):undefined;
 return <div key={j} className="ai-place-row">
 <span className="ai-place-number">{j+1}</span><div className="ai-place-main"><strong>{v.name}</strong><small>{v.price?t("itinerary.publicPrice",{price:v.price}):t("itineraryassistant.price.not.found")}</small>{v.details&&<details><summary>{t("itineraryassistant.place.details")}</summary><p>{v.details}</p></details>}</div>
 <div className="ai-place-actions">
 {url?<a href={url} target="_blank" rel="noreferrer">{t("itineraryassistant.website")}</a>:<small>{t("itineraryassistant.website.unavailable")}</small>}
 <a href={maps(v,d.city)} target="_blank" rel="noreferrer">{t("itineraryassistant.google.maps")}</a>
 <button disabled={busy} aria-pressed={!!selected[d.date+kind]?.includes(v.name)} onClick={()=>choose(d.date,kind,v.name)}>{selected[d.date+kind]?.includes(v.name)?t("itineraryassistant.selected"):kind==='hotels'?t("itineraryassistant.select.hotel"):kind==='restaurants'?t("itineraryassistant.select.restaurant"):t("itineraryassistant.select.activity")}</button>
 </div></div>;});
 }
 function optionLines(d:any,kind:string){const names=selected[d.date+kind]||[];return d[kind].map(venue).filter((v:any)=>!names.length||names.includes(v.name)).map((v:any)=>[v.name,v.details,v.price?`Harga publik: ${v.price}`:'Harga belum ditemukan',v.websiteSourceId!==null?result.sources[v.websiteSourceId]?.url:'',maps(v,d.city),'Ketersediaan belum diperiksa'].filter(Boolean).join(' · '));}
 return <section className="itinerary-assistant">
 <section className="ai-context-summary">
 <h3>{t("itineraryassistant.information.used.by.ai")}</h3>
 <dl>
 <div><dt>{t("itineraryassistant.trip.route")}</dt><dd>{q.trip || t("collectivetable.not.entered")} · {q.destination || t("collectivetable.not.entered")}</dd></div>
 <div><dt>{t("itineraryassistant.dates.duration")}</dt><dd>{q.start} – {q.end} · {Math.max(0, Math.round((Date.parse(q.end)-Date.parse(q.start))/86400000)+1)||0}{" "}{t("itineraryassistant.days")}</dd></div>
 <div><dt>{t("itineraryassistant.participants")}</dt><dd>{q.passengers.length}{" "}{t("itineraryassistant.people")}{" "}{q.passengers.filter((p:any)=>p.category==='adult').length}{" "}{t("itineraryassistant.adults")}{" "}{q.passengers.filter((p:any)=>p.category==='child').length}{" "}{t("itineraryassistant.children")}{" "}{q.passengers.filter((p:any)=>p.category==='infant').length} infant</dd></div>
 <div><dt>{t("itineraryassistant.arrival.departure")}</dt><dd>{q.entry||t("collectivetable.not.entered")} → {q.exit||t("collectivetable.not.entered")}</dd></div>
 <div><dt>{t("editor.customer.preferences")}</dt><dd style={{whiteSpace:'pre-wrap'}}>{q.preferences||t("itineraryassistant.no.specific.preferences")}</dd></div>
 </dl>
 <small>{t("itineraryassistant.this.summary.follows.the.quotation.form.add.specific.requirements")}</small>
 </section>
 {!enabled&&<p role="status">{t("itineraryassistant.gemini.tavily.are.not.connected")}</p>}
 {messages.map((m,i)=><div className="info" key={i} style={{whiteSpace:'pre-wrap',marginBottom:10}}><strong>{m.role==='user'?t("messages.you"):t("messages.assistant")}</strong><p>{m.text}</p></div>)}
 {!result?.days?.length&&<><label><textarea aria-label={t("itineraryassistant.message.to.ai")} value={prompt} maxLength={4000} onChange={e=>setPrompt(e.target.value)}/></label>
 <button className="primary" disabled={!enabled||busy||!prompt.trim()||messages.length>=29} onClick={()=>send()}>{busy?t("itineraryassistant.finding.sources.and.preparing.the.schedule"):messages.length?t("itineraryassistant.send.response"):t("editor.generate.itinerary.with.ai")}</button></>}
 {busy&&<div className="ai-loading" role="status" aria-live="polite"><LoaderCircle className="ai-spinner" size={22} aria-hidden="true"/><div><strong>{t("itineraryassistant.ai.is.generating.the.itinerary")}</strong><small>{t("itineraryassistant.finding.places.and.checking.route.continuity.please.wait")}</small></div></div>}
 {busy&&<button onClick={cancel}>{t("itineraryassistant.cancel.ai.request")}</button>}
 {error&&<p role="alert">{errorMessage(error)}</p>}
 {conflict&&!busy&&<button onClick={async()=>{try{await api('/ai/cancel',{});setConflict(false);setError('Permintaan sebelumnya dibatalkan. Silakan coba lagi.');}catch(e){setError((e as Error).message);}}}>{t("itineraryassistant.cancel.previous.request")}</button>}
 {result?.days?.length>0&&<>
 <h3>{t("itineraryassistant.preview")}{" "}{result.days.length}{" "}{t("itineraryassistant.days")}</h3>
 {!!result.reviewNotes?.length&&<details className="info"><summary>{t("itineraryassistant.ai.notes.requiring.review")}</summary><ul>{result.reviewNotes.map((note:string,i:number)=><li key={i}>{note}</li>)}</ul></details>}
 {result.days.map((d:any,i:number)=><article className="card ai-day-card" key={d.date}>
 <h3>{t("collectivetable.day")}{" "}{i+1} · {d.date} · {d.city}</h3><strong>{d.title}</strong><label className="ai-day-description">{t("itineraryassistant.activities.for.day")}{" "}{i+1}<textarea rows={Math.max(5, Math.min(14, d.description.split("\n").length + 1))} aria-label={t("itinerary.descriptionDay", {day:i+1})} disabled={!editable||busy} maxLength={2500} value={d.description} onChange={e=>editDay(d.date,'description',e.target.value)}/></label>
 <small>{t("itineraryassistant.today.s.route")}{" "}{d.startCity||d.city} → {d.endCity||d.city}</small>
 <small>{t("itineraryassistant.the.selected.hotel.applies.to.consecutive.nights.in.the")}</small><div className="ai-place-columns ai-three-options"><section><h4>{t("itineraryassistant.hotel.options")}{" "}<small>({d.hotels.length})</small></h4>{d.hotels.length?options(d,'hotels'):<p>{t("itineraryassistant.no.hotel.options.for.this.day.if.staying.overnight")}</p>}
 {manualOption(d,'hotels')}{selected[d.date+'hotels']?.length>0&&<label>{t("itineraryassistant.number.of.rooms.entire.stay")}<input type="number" min={1} step={1} value={rooms[d.date]||1} onChange={e=>{const n=Math.max(1,Math.floor(Number(e.target.value)||1));const group=stayGroups(result.days).find(g=>g.some(x=>x.date===d.date))||[d];setRooms(old=>({...old,...Object.fromEntries(group.map(x=>[x.date,n]))}));setApplied(false);}}/></label>}</section><section><h4>{t("itineraryassistant.restaurant.options")}{" "}<small>({d.restaurants.length})</small></h4>{d.restaurants.length?options(d,'restaurants'):<p>{t("itineraryassistant.not.found.confirmation.required")}</p>}
 {manualOption(d,'restaurants')}</section><section><h4>{t("itineraryassistant.paid.activities")}{" "}<small>({(d.activities||[]).length})</small></h4>{d.activities?.length?options(d,'activities'):<p>{t("itineraryassistant.no.ticket.or.paid.activity.options.add.activities.manually")}</p>}{manualOption(d,'activities')}</section></div><small>{t("itineraryassistant.room.table.availability.has.not.been.checked.confirm.public")}</small>
 {!!d.sourceIds.length&&<details style={{margin:'16px 0'}}><summary>{t("itineraryassistant.additional.information")}</summary>{d.sourceIds.map((n:number)=>safeUrl(result.sources[n]?.url)&&<p key={n}><a href={result.sources[n].url} target="_blank" rel="noreferrer">{result.sources[n].title}</a></p>)}</details>}
 <label>{t("itineraryassistant.today.s.notes")}<textarea aria-label={t("itinerary.notesDay", {day:i+1})} disabled={!editable||busy} maxLength={1000} value={d.notes||''} onChange={e=>editDay(d.date,'notes',e.target.value)}/></label>
 <small>{t("itineraryassistant.notes.are.included.in.the.itinerary")}</small>
 </article>)}
 <small>{t("itineraryassistant.searched")}{" "}{new Date(result.checkedAt).toLocaleString('id-ID')}{t("itineraryassistant.public.prices.and.availability.are.not.supplier.quotations")}</small>
 {q.itinerary.length>0&&<label>{t("itineraryassistant.existing.itinerary")}<select value={mode} onChange={e=>setMode(e.target.value)}><option value="append">{t("itineraryassistant.append.to.the.existing.itinerary")}</option><option value="replace">{t("itineraryassistant.replace.the.entire.existing.itinerary")}</option></select></label>}
 <button className="primary" disabled={!editable||busy||applied} onClick={()=>{onApply(result.days.map((d:any)=>({id:crypto.randomUUID(),date:d.date,city:d.city,title:d.title,description:d.description,notes:d.notes||'',endCity:d.endCity,selectedHotel:selected[d.date+'hotels']?.[0]||'',selectedRestaurants:selected[d.date+'restaurants']||[],selectedActivities:selected[d.date+'activities']||[],rooms:rooms[d.date]||1,hotels:d.hotels.map((v:any)=>({...venue(v),website:placeWebsite(venue(v),result.sources)})),restaurants:d.restaurants.map((v:any)=>({...venue(v),website:placeWebsite(venue(v),result.sources)})),activities:(d.activities||[]).map((v:any)=>({...venue(v),website:placeWebsite(venue(v),result.sources)})),sources:d.sourceIds.map((n:number)=>result.sources[n]).filter(Boolean).map((s:any)=>({title:s.title||'Source',url:s.url}))})),mode==='replace',hotelStays(result.days,selected,rooms));setApplied(true);}}>{applied?t("itineraryassistant.added.to.the.draft.itinerary"):t("itinerary.applyDays", {count:result.days.length})}</button>
 {applied&&<p role="status">{t("itineraryassistant.all.days.have.been.added.to.the.itinerary.form")}</p>}
 </>}
 <small>{t("itineraryassistant.ai.results.remain.available.while.this.editor.is.open")}</small>
 </section>;
}
