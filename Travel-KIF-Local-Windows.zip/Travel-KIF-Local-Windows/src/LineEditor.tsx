import {errorMessage,t} from "./i18n";
import { useState } from "react";
import { type CostLine, Line } from "../shared/model";
import { lineAmount, formula } from "../shared/calculate";
import { Field, Check, Modal, currencies, categoryOptions } from "./components";
import { money } from "./api";
export function LineEditor({
  line,
  onSave,
  onClose,
  title = t("common.service.details"),
}: {
  line: CostLine;
  onSave: (l: CostLine) => void;
  onClose: () => void;
  title?: string;
}) {
  const [advanced, setAdvanced] = useState(false);
  const [l, set] = useState(line),
    [error, err] = useState<any>("");
  const put = (k: keyof CostLine, v: any) => set({ ...l, [k]: v });
  return (
    <Modal title={title} onClose={onClose} wide>
      <div className="form-grid">
        <Field
          label={t("collectivetable.service.name")}
          value={l.label}
          onChange={(v: any) => put("label", v)}
          wide
        />
        <Field
          label={t("editor.category")}
          value={l.category}
          options={categoryOptions}
          onChange={(v: any) => {
            set({
              ...l,
              category: v,
              side: ["hotel", "meal", "activity"].includes(v)
                ? "individual"
                : "collective",
            });
          }}
        />
        {advanced && <Field
          label={t("lineeditor.ca.group")}
          value={l.side}
          options={["collective", "individual"]}
          onChange={(v: any) => put("side", v)}
        />}
        {advanced && <Field
          label={t("lineeditor.supplier")}
          value={l.supplier}
          onChange={(v: any) => put("supplier", v)}
        />}
        {advanced && <Field
          label={t("lineeditor.city.route")}
          value={l.city}
          onChange={(v: any) => put("city", v)}
        />}
        {advanced && <Field
          label={t("lineeditor.price.source")}
          value={l.source}
          onChange={(v: any) => put("source", v)}
        />}
        {advanced && <Field
          label={t("lineeditor.price.status")}
          value={l.priceStatus}
          options={["estimate", "historical", "validated"]}
          onChange={(v: any) => put("priceStatus", v)}
        />}
        <Field
          label={t("lineeditor.start.check.in")}
          type="date"
          value={l.start}
          onChange={(v: any) => put("start", v)}
        />
        <Field
          label={t("lineeditor.end.check.out")}
          type="date"
          value={l.end}
          onChange={(v: any) => put("end", v)}
        />
        <Field
          label={t("lineeditor.calculation.basis")}
          value={l.basis}
          options={[
            {
              value: "supplier-total",
              label: t("common.supplier.total.total.stay.once"),
            },
            { value: "vehicle-day", label: t("common.vehicles.days.rate") },
            { value: "room-night", label: t("common.rooms.nights.rate") },
            { value: "pax-day", label: t("common.people.days.meals.rate") },
            {
              value: "unit",
              label: t("common.units.room.nights.pax.days.already.totalled"),
            },
          ]}
          onChange={(v: any) => put("basis", v)}
        />
        <Field
          label={t("lineeditor.cost.currency")}
          value={l.currency}
          options={currencies}
          onChange={(v: any) => put("currency", v)}
        />
        {l.basis !== "supplier-total" && (
          <>
            <Field
              label={l.category==="hotel"?t("itineraryplaces.number.of.rooms"):t("lineeditor.number.of.units")}
              type="number"
              value={l.quantity}
              onChange={(v: any) => put("quantity", v)}
            />
            {advanced && <Field
              label={t("lineeditor.quantity.unit")}
              value={l.unit}
              onChange={(v: any) => put("unit", v)}
            />}
          </>
        )}
        {["vehicle-day", "room-night", "pax-day"].includes(l.basis) && (
          <Field
            label={l.category==="hotel"?t("lineeditor.number.of.nights"):t("lineeditor.number.of.days.uses")}
            type="number"
            value={l.factor}
            onChange={(v: any) => put("factor", v)}
          />
        )}
        <Field
          label={t("lineeditor.supplier.price.blank.unknown")}
          type="number"
          nullable
          value={l.unitPrice}
          onChange={(v: any) => put("unitPrice", v)}
        />
        {advanced && <Field
          label={t("lineeditor.tax.basis")}
          value={l.taxBasis}
          onChange={(v: any) => put("taxBasis", v)}
        />}
        {advanced && l.category === "transport" && <Field
          label={t("lineeditor.seats.per.vehicle")}
          type="number"
          nullable
          value={l.capacity}
          onChange={(v: any) => put("capacity", v)}
        />}
        {advanced && l.category === "transport" && <Field
          label={t("lineeditor.luggage.capacity.per.vehicle")}
          type="number"
          nullable
          value={l.bagCapacity}
          onChange={(v: any) => put("bagCapacity", v)}
        />}
        <Field
          label={t("lineeditor.already.included.comma.separated")}
          value={l.includedCosts.join(", ")}
          onChange={(v: string) =>
            put(
              "includedCosts",
              v
                .split(",")
                .map((x) => x.trim())
                .filter(Boolean),
            )
          }
          wide
        />
        <Field
          label={t("lineeditor.notes.occupancy.breakfast.extra.bed.cancellation")}
          type="textarea"
          value={l.notes}
          onChange={(v: any) => put("notes", v)}
          wide
        />
        <Check
          label={t("lineeditor.make.this.an.optional.add.on")}
          value={l.addon}
          onChange={(v: any) => put("addon", v)}
        />
        {l.addon && (
          <>
            <Check
              label={t("lineeditor.include.in.quotation")}
              value={l.included}
              onChange={(v: any) => put("included", v)}
            />
            <Field
              label={t("lineeditor.total.add.on.selling.price.quotation.currency")}
              type="number"
              nullable
              value={l.selling}
              onChange={(v: any) => put("selling", v)}
            />
          </>
        )}
        {l.category === "route" && (
          <div className="wide">
            <h3>{t("lineeditor.reusable.itinerary.template")}</h3>
            {(l.routeDays ?? []).map((d, i) => (
              <div className="form-grid" key={i}>
                {(["offset", "city", "title", "description"] as const).map(
                  (k) => (
                    <Field
                      key={k}
                      label={
                        {
                          offset: t("common.day.index.starting.at.0"),
                          city: "Kota",
                          title: "Judul",
                          description: "Deskripsi",
                        }[k]
                      }
                      type={
                        k === "offset"
                          ? "number"
                          : k === "description"
                            ? "textarea"
                            : "text"
                      }
                      value={d[k]}
                      onChange={(v: any) =>
                        put(
                          "routeDays",
                          l.routeDays.map((x, j) =>
                            j === i ? { ...x, [k]: v } : x,
                          ),
                        )
                      }
                    />
                  ),
                )}
              </div>
            ))}
            <button
              onClick={() =>
                put("routeDays", [
                  ...(l.routeDays ?? []),
                  {
                    offset: (l.routeDays ?? []).length,
                    city: l.city,
                    title: "Hari baru",
                    description: "",
                  },
                ])
              }
            >{t("lineeditor.add.template.day")}</button>
          </div>
        )}
      </div>
      <button className="text-button" onClick={()=>setAdvanced(!advanced)}>{advanced?t("lineeditor.hide.additional.details"):t("lineeditor.additional.details.supplier.price.source.and.settings")}</button>
      <div className="calc-box">
        <span>{l.basis === "supplier-total" ? t("common.supplierTotalOnce") : `${l.quantity} ${l.unit} ${["vehicle-day","room-night","pax-day"].includes(l.basis) ? "× "+t("common.periodFactor",{factor:l.factor})+" " : ""}× ${l.unitPrice ?? t("common.noPrice")}`}</span>
        <strong>{money(lineAmount(l), l.currency)}</strong>
      </div>
      {error && <p className="error">{errorMessage(error)}</p>}
      <footer>
        <button onClick={onClose}>{t("common.cancel")}</button>
        <button
          className="primary"
          onClick={() => {
            const parsed = Line.safeParse(l);
            if (!parsed.success) {
              err({issues:parsed.error.issues});
              return;
            }
            onSave(parsed.data);
          }}
        >{t("lineeditor.apply.service")}</button>
      </footer>
    </Modal>
  );
}
