import { z } from "zod";
export const DraftProposal = z
  .object({
    trip: z.string().max(200),
    destination: z.string().max(400),
    start: z.string().max(10),
    end: z.string().max(10),
    declaredPax: z.number().int().min(0).max(500).nullable(),
    passengers: z
      .array(
        z.object({
          name: z.string().max(200),
          category: z.enum(["adult", "child", "infant"]),
          age: z.number().int().min(0).max(120).nullable(),
        }),
      )
      .max(500),
    itinerary: z
      .array(
        z.object({
          date: z.string().max(10),
          city: z.string().max(200),
          title: z.string().max(200),
          description: z.string().max(4000),
        }),
      )
      .max(100),
  })
  .strict();
const string = { type: "string" },
  nullableNumber = { type: ["integer", "null"] };
export const draftTool = {
  type: "function",
  name: "propose_trip_draft",
  description:
    "Usulkan ekstraksi permintaan / itinerary untuk pratinjau TC. Tidak menulis database. Pertahankan angka jumlah yang dinyatakan pelanggan pada declaredPax, rincikan setiap orang secara terpisah sehingga ketidaksesuaian dapat diperiksa. Tanggal tidak diketahui: string kosong; umur tidak diketahui: null. Jangan mengarang harga atau kelayakan rute.",
  strict: true,
  parameters: {
    type: "object",
    additionalProperties: false,
    properties: {
      trip: string,
      destination: string,
      start: string,
      end: string,
      declaredPax: nullableNumber,
      passengers: {
        type: "array",
        items: {
          type: "object",
          additionalProperties: false,
          properties: {
            name: string,
            category: { type: "string", enum: ["adult", "child", "infant"] },
            age: nullableNumber,
          },
          required: ["name", "category", "age"],
        },
      },
      itinerary: {
        type: "array",
        items: {
          type: "object",
          additionalProperties: false,
          properties: {
            date: string,
            city: string,
            title: string,
            description: string,
          },
          required: ["date", "city", "title", "description"],
        },
      },
    },
    required: [
      "trip",
      "destination",
      "start",
      "end",
      "declaredPax",
      "passengers",
      "itinerary",
    ],
  },
};
