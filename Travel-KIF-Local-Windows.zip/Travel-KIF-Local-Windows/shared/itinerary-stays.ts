// Consecutive nights in the same overnight city form one hotel stay.
const key=(s:string)=>s.trim().normalize('NFKC').toLocaleLowerCase();
export function stayGroups(days:any[]){
 const groups:any[][]=[];
 for(let i=0;i<days.length-1;i++){
  const day=days[i],city=key(day.endCity||day.city||'');
  const last=groups.at(-1),prev=last?.at(-1);
  if(city&&prev&&key(prev.endCity||prev.city||'')===city&&Date.parse(day.date)-Date.parse(prev.date)===86400000)last!.push(day);
  else groups.push([day]);
 }
 return groups;
}
export function consistentHotels<T extends {days:any[]}>(plan:T):T{
 const hotels=new Map<string,any[]>();
 for(const group of stayGroups(plan.days)){
  const choices:any[]=[],seen=new Set<string>();
  for(const day of group)for(const hotel of day.hotels){const name=key(typeof hotel==='string'?hotel:hotel.name);if(!seen.has(name)){seen.add(name);choices.push(hotel);}}
  for(const day of group)hotels.set(day.date,choices.slice(0,8));
 }
 return {...plan,days:plan.days.map(day=>hotels.has(day.date)?{...day,hotels:hotels.get(day.date)!}:day)};
}
export function chooseStayHotel(days:any[],selected:Record<string,string[]>,date:string,name:string){
 const next={...selected},value=selected[date+'hotels']?.includes(name)?[]:[name];
 const group=stayGroups(days).find(g=>g.some(d=>d.date===date))||[{date}];
 for(const day of group)next[day.date+'hotels']=value;
 return next;
}

export function hotelStays(days:any[],selected:Record<string,string[]>,rooms:Record<string,number>){
 return stayGroups(days).flatMap(group=>{
 const first=group[0],name=selected[first.date+'hotels']?.[0];
 if(!name)return [];
 const last=group.at(-1)!;
 return [{name,city:first.endCity||first.city,start:first.date,end:new Date(Date.parse(last.date)+86400000).toISOString().slice(0,10),nights:group.length,rooms:rooms[first.date]||1}];
 });
}
