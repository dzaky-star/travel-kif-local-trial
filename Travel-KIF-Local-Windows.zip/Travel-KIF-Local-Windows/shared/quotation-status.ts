// Persisted values remain unchanged; all presentation uses this definition.
export const salesStatuses=['Draft','Sent','Negotiation','Confirmed','Lost'];
export const normalizeSalesStatus=(value:string)=>value==='Cancelled'?'Lost':value;
export const salesStatusLabel=(value:string)=>value==='Confirmed'?'Deal':normalizeSalesStatus(value);
export const workspaceDay=(date=new Date())=>new Date(date.getTime()+7*3600000).toISOString().slice(0,10);
export const workspaceMonth=(date:string)=>workspaceDay(new Date(date)).slice(0,7);
