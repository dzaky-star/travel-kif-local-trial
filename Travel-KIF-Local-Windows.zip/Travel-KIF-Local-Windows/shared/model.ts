import { z } from "zod";
const text = z.string().max(4000);
const number = z.number().finite().nonnegative().max(1e12);
export const Currency = z.enum(["EUR", "IDR", "USD", "GBP", "CHF"]);
export const Status = z.enum([
  "Draft",
  "Sent",
  "Negotiation",
  "Confirmed",
  "Lost",
  "Cancelled",
]);
export const Passenger = z.object({
  id: z.string(),
  name: text,
  category: z.enum(["adult", "child", "infant"]),
  age: z.number().int().min(0).max(120).nullable(),
  role: z.enum(["customer", "TL", "staff"]),
  foc: z.boolean(),
  usesVehicle: z.boolean(),
  bags: z.number().int().min(0).max(20),
});
export const Line = z.object({
  id: z.string(),
  label: text.min(1),
  category: z.enum([
    "transport",
    "hotel",
    "meal",
    "guide",
    "activity",
    "operational",
    "additional",
    "route",
  ]),
  side: z.enum(["collective", "individual"]),
  caSection: z.string().optional(),
  supplier: text,
  source: text,
  catalogId: z.string().optional(),
  priceId: z.string().optional(),
  priceStatus: z.enum(["estimate", "historical", "validated"]),
  recordedAt: text,
  start: text,
  end: text,
  city: text,
  basis: z.enum([
    "vehicle-day",
    "room-night",
    "pax-day",
    "unit",
    "supplier-total",
  ]),
  quantity: number,
  factor: number,
  unit: text,
  unitPrice: number.nullable(),
  currency: Currency,
  addon: z.boolean(),
  included: z.boolean(),
  selling: number.nullable(),
  notes: text,
  includedCosts: z.array(text),
  capacity: number.nullable(),
  bagCapacity: number.nullable(),
  taxBasis: text,
  routeDays: z
    .array(
      z.object({
        offset: z.number().int().min(0).max(99),
        city: text,
        title: text,
        description: text,
      }),
    )
    .max(100)
    .default([]),
});
export const Fx = z.object({
  id: z.string(),
  from: Currency,
  to: Currency,
  rate: z.number().positive().finite(),
  source: text,
  recordedAt: text,
  validFrom: text,
  validTo: text,
  kind: z.enum(["working", "reference"]),
  sourceDate: z.string().optional(),
  effectiveDate: z.string().optional(),
  origin: z.enum(["automatic", "manual"]).optional(),
});
export const Policy = z.object({
  id: z.string(),
  approved: z.boolean(),
  weights: z.object({ adult: number, child: number, infant: number }),
  rounding: z.number().positive().max(1e6),
  minimumMargin: z.number().min(0).max(0.99),
  ageRule: text,
  childMinAge: z.number().int().min(0).max(120).nullable().optional(),
  childMaxAge: z.number().int().min(0).max(120).nullable().optional(),
  infantMaxAge: z.number().int().min(0).max(120).nullable().optional(),
  roomRule: text,
  reviewBelowMargin: z.boolean(),
  fxBuffer: number,
  notes: text,
});
export const QuoteInput = z.object({
  exampleAssumptions: z.array(z.string()).optional(),
  sellCurrencyConfirmed: z.boolean().default(true),
  sourceWorkbook: z
    .object({
      title: z.string(),
      sheet: z.string(),
      sheetId: z.number(),
      url: z.string().url(),
      importedAt: z.string(),
      kind: z.enum(["ca", "options", "reference"]),
      reviewed: z.boolean(),
      warnings: z.array(z.string()),
      originalSelling: z.number().nullable(),
      originalCost: z.number().nullable(),
      originalCurrency: Currency.nullable(),
      rows: z.array(
        z.array(
          z.object({
            cell: z.string(),
            value: z.union([z.string(), z.number(), z.boolean(), z.null()]),
            formula: z.string().nullable(),
            format: z.string(),
          }),
        ),
      ),
      options: z.array(
        z.object({
          label: z.string(),
          cell: z.string(),
          cost: z.number().nullable(),
          selling: z.number().nullable(),
          currency: Currency.nullable(),
          notes: z.string(),
        }),
      ),
    })
    .optional(),
  ownerName: z.string().trim().max(120).default(""),
  images: z
    .array(
      z.object({
        id: z.string(),
        caption: text,
        rights: text.min(1),
        source: text.min(1),
        dataUrl: z
          .string()
          .max(280000)
          .regex(/^data:image\/png;base64,[A-Za-z0-9+/=]+$/),
      }),
    )
    .max(3)
    .default([]),
  customer: text.min(1),
  agent: text,
  trip: text.min(1),
  mode: z.enum(["trip", "transfer", "hotel", "ticket", "custom"]),
  start: text,
  end: text,
  destination: text,
  entry: text,
  exit: text,
  preferences: text,
  notes: text,
  validUntil: text,
  baseCurrency: Currency,
  sellCurrency: Currency,
  declaredPax: z.number().int().nonnegative().nullable(),
  passengers: z.array(Passenger).max(500),
  itinerary: z
    .array(
      z.object({
        id: z.string(),
        date: text,
        city: text,
        title: text,
        description: text,
        notes: text.optional(),
        endCity: text.optional(),
        selectedHotel: text.optional(),
        selectedRestaurants: z.array(text).optional(),
        selectedActivities: z.array(text).optional(),
        rooms: z.number().positive().optional(),
        hotels: z.array(z.object({name:text,details:text,price:text,website:text.optional()})).optional(),
        restaurants: z.array(z.object({name:text,details:text,price:text,website:text.optional()})).optional(),
        activities: z.array(z.object({name:text,details:text,price:text,website:text.optional()})).optional(),
        sources: z.array(z.object({title:text,url:text})).optional(),
      }),
    )
    .max(100),
  lines: z.array(Line).max(500),
  pricing: z.object({
    basis: z.enum(["weighted", "group", "unit"]),
    units: z.number().positive(),
    targetType: z.enum(["markup", "margin"]),
    target: z.number().min(0).max(10),
    targetAfterCommission: z.boolean(),
    overrides: z.object({
      adult: number.nullable(),
      child: number.nullable(),
      infant: number.nullable(),
      group: number.nullable(),
    }),
    discount: number,
    finalRounding: z.number().positive().max(1e6).optional(),
    commission: z.object({
      kind: z.enum(["none", "fixed", "percent"]),
      value: number,
      recipient: text,
      basis: z.enum(["land", "grand"]),
    }),
  }),
  fx: z.array(Fx),
  policy: Policy,
  policyConfirmed: z.boolean(),
  reviewConfirmed: z.boolean(),
  inclusions: text,
  exclusions: text,
  terms: text,
});
export type Quote = z.infer<typeof QuoteInput>;
export type CostLine = z.infer<typeof Line>;
export type PolicyType = z.infer<typeof Policy>;
export type FxType = z.infer<typeof Fx>;
export const demoPolicy: PolicyType = {
  id: "policy-demo-v1",
  approved: false,
  weights: { adult: 1, child: 0.75, infant: 0.5 },
  rounding: 0.01,
  minimumMargin: 0.15,
  ageRule: "Belum disetujui: workbook 0–2 / 3–10; meeting mulai 2 tahun.",
  roomRule: "Kamar dan extra bed diisi berdasarkan kebutuhan aktual.",
  reviewBelowMargin: true,
  fxBuffer: 0,
  notes: "Metode bobot jual adalah usulan desain. Bukan faktor biaya supplier.",
};
export function blankQuote(): Quote {
  const today = new Date().toISOString().slice(0, 10);
  return {
    ownerName: "",
    images: [],
    customer: "",
    agent: "",
    trip: "",
    mode: "trip",
    start: today,
    end: today,
    destination: "",
    entry: "",
    exit: "",
    preferences: "",
    notes: "",
    validUntil: today,
    baseCurrency: "EUR",
    sellCurrency: "IDR",
    sellCurrencyConfirmed: false,
    declaredPax: null,
    passengers: [],
    itinerary: [],
    lines: [],
    pricing: {
      basis: "weighted",
      units: 1,
      targetType: "markup",
      target: 0.2,
      targetAfterCommission: false,
      overrides: { adult: null, child: null, infant: null, group: null },
      discount: 0,
      commission: { kind: "none", value: 0, recipient: "", basis: "grand" },
    },
    fx: [],
    policy: demoPolicy,
    policyConfirmed: false,
    reviewConfirmed: false,
    inclusions: "",
    exclusions: "",
    terms: "",
  };
}
export function newLine(): CostLine {
  return {
    id: crypto.randomUUID(),
    label: "Layanan baru",
    category: "transport",
    side: "collective",
    supplier: "",
    source: "Input manual",
    priceStatus: "estimate",
    recordedAt: new Date().toISOString(),
    start: "",
    end: "",
    city: "",
    basis: "supplier-total",
    quantity: 1,
    factor: 1,
    unit: "layanan",
    unitPrice: null,
    currency: "EUR",
    addon: false,
    included: true,
    selling: null,
    notes: "",
    includedCosts: [],
    capacity: null,
    bagCapacity: null,
    taxBasis: "Belum diketahui",
    routeDays: [],
  };
}
export const roles = ["TC", "OPS", "Finance", "Director", "Admin"] as const;
