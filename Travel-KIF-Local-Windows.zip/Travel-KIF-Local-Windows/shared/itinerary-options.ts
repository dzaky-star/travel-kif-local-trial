import {hotelStays, stayGroups} from './itinerary-stays';
import {newLine} from './model';
export function structuredDay(day:any){
 if(day.hotels || !day.description?.includes('Pilihan hotel:'))return day;
 const [activity,rest]=day.description.split('Pilihan hotel:');
 const [hotelText,restaurantText='']=rest.split('Pilihan restoran:');
 const parse=(s:string)=>s.split('\n').filter(l=>l.includes(' · ')&&!l.startsWith('Dicari ')).map(l=>{const [name,details,price]=l.split(' · ');return {name,details,price:price||'',website:''};});
 return {...day,description:activity.trim(),hotels:parse(hotelText),restaurants:parse(restaurantText.split('Sumber:')[0]),sources:[...day.description.matchAll(/Sumber: (https?:\/\/\S+)/g)].map(m=>({title:'Sumber terkait',url:m[1]}))};
}
export function updateHotel(days:any[],date:string,name:string,rooms?:number){
 const group=stayGroups(days).find(g=>g.some(d=>d.date===date))||days.filter(d=>d.date===date);
 return days.map(d=>group.includes(d)?{...d,selectedHotel:name,rooms:rooms??d.rooms??1}:d);
}
export function hotelLines(days:any[],lines:any[]){
 const selected=Object.fromEntries(days.map(d=>[d.date+'hotels',d.selectedHotel?[d.selectedHotel]:[]]));
 const rooms=Object.fromEntries(days.map(d=>[d.date,d.rooms||1]));
 const generated=hotelStays(days,selected,rooms).map(stay=>{const source=`Pilihan hotel itinerary | ${stay.start} | ${stay.end}`;const old=lines.find(l=>l.source===source&&l.label===stay.name);return {...(old||newLine()),label:stay.name,category:'hotel',side:'individual',supplier:stay.name,city:stay.city,start:stay.start,end:stay.end,basis:'room-night',unit:'kamar',quantity:stay.rooms,factor:stay.nights,source,notes:'Hotel pilihan klien/tim. Tarif diisi manual; ketersediaan belum dikonfirmasi.'};});
 return [...lines.filter(l=>!l.source.startsWith('Pilihan hotel itinerary | ')),...generated];
}
// Only expose a place link when the source identifies this specific venue.
export function placeWebsite(place:any,sources:any[]){
 const s=sources[place.websiteSourceId];if(!s||!/^https?:\/\//.test(s.url))return '';
 const norm=(v:string)=>v.normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().replace(/[^a-z0-9]+/g,' ').trim();
 const name=norm(place.name),hay=norm(s.title+' '+s.url);
 return name.length>4&&hay.includes(name)?s.url:'';
}
