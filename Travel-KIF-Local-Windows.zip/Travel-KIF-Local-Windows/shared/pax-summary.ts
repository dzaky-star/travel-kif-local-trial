import type { Quote } from "./model";
import type { Calculation } from "./calculate";

// Allocate the existing final total for display; never recalculate the quotation.
export function paxSummary(q: Quote, c: Calculation) {
  const categories = ["adult", "child", "infant"] as const;
  const weights = Object.fromEntries(categories.map(k => [k,
    q.pricing.basis === "weighted" ? c.prices[k].applied : q.policy.weights[k]
  ])) as Record<typeof categories[number], number>;
  const totalWeight = categories.reduce((sum, k) => sum + c.counts[k] * weights[k], 0);
  return Object.fromEntries(categories.map(k => [k,
    !c.counts[k] || c.grandTotal == null || totalWeight <= 0
      ? null : c.grandTotal * weights[k] / totalWeight
  ])) as Record<typeof categories[number], number | null>;
}
