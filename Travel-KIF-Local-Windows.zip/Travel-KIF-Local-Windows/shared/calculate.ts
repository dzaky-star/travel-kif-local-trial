import Decimal from "decimal.js";
import { QuoteInput, type Quote, type CostLine } from "./model";
export const ENGINE_VERSION = "1.0.0";
const D = (n: Decimal.Value) => new Decimal(n);
const sum = (ns: number[]) => ns.reduce((a, n) => a.plus(n), D(0));
export const money = (n: Decimal.Value) =>
  D(n).toDecimalPlaces(2, Decimal.ROUND_HALF_UP).toNumber();
export function dateOK(s: string) {
  return (
    /^\d{4}-\d{2}-\d{2}$/.test(s) &&
    !isNaN(Date.parse(s)) &&
    new Date(s).toISOString().slice(0, 10) === s
  );
}
export function days(start: string, end: string) {
  if (!dateOK(start) || !dateOK(end) || end < start)
    throw Error("Tanggal tidak valid atau tanggal selesai mendahului mulai.");
  return (Date.parse(end) - Date.parse(start)) / 864e5;
}
export function convert(n: number, from: string, to: string, q: Quote) {
  if (from === to) return n;
  const direct = q.fx.find(
    (r) => r.kind === "working" && r.from === from && r.to === to,
  );
  if (direct) return D(n).mul(direct.rate).toNumber();
  const reverse = q.fx.find(
    (r) => r.kind === "working" && r.from === to && r.to === from,
  );
  if (reverse) return D(n).div(reverse.rate).toNumber();
  throw Error(`Kurs kerja ${from} → ${to} belum tersedia.`);
}
export function lineAmount(l: CostLine) {
  if (l.unitPrice === null) return null;
  return money(
    D(l.unitPrice)
      .mul(l.basis === "supplier-total" ? 1 : l.quantity)
      .mul(
        ["vehicle-day", "room-night", "pax-day"].includes(l.basis)
          ? l.factor
          : 1,
      ),
  );
}
export function formula(l: CostLine) {
  return l.basis === "supplier-total"
    ? "Total supplier (sekali)"
    : `${l.quantity} ${l.unit} ${["vehicle-day", "room-night", "pax-day"].includes(l.basis) ? "× " + l.factor + " periode " : ""}× ${l.unitPrice ?? "belum ada harga"}`;
}
export function calculate(input: Quote) {
  const q = QuoteInput.parse(input);
  const errors: string[] = [],
    warnings: string[] = [];
  if (!q.sellCurrencyConfirmed)
    errors.push("Pilih mata uang penawaran ke klien terlebih dahulu.");
  let duration = 0;
  try {
    duration = days(q.start, q.end) + 1;
  } catch (e) {
    errors.push((e as Error).message);
  }
  if (!dateOK(q.validUntil))
    errors.push("Tanggal berlaku penawaran tidak valid.");
  for (const d of q.itinerary)
    if (!dateOK(d.date) || d.date < q.start || d.date > q.end)
      errors.push(`Tanggal itinerary tidak sesuai periode trip: ${d.title}`);
  for (const p of q.passengers) {
    if (p.age === null) continue;
    if (
      p.category === "adult" &&
      q.policy.childMaxAge != null &&
      p.age <= q.policy.childMaxAge
    )
      errors.push(
        `Umur ${p.name} masih termasuk anak/infant menurut kebijakan quotation.`,
      );
    if (
      p.category === "child" &&
      ((q.policy.childMinAge != null && p.age < q.policy.childMinAge) ||
        (q.policy.childMaxAge != null && p.age > q.policy.childMaxAge))
    )
      errors.push(
        `Umur ${p.name} di luar aturan kategori anak pada snapshot kebijakan.`,
      );
    if (
      p.category === "infant" &&
      q.policy.infantMaxAge != null &&
      p.age > q.policy.infantMaxAge
    )
      errors.push(
        `Umur ${p.name} di luar aturan infant pada snapshot kebijakan.`,
      );
  }
  const ids = q.passengers.map((p) => p.id);
  if (new Set(ids).size !== ids.length) errors.push("ID peserta duplikat.");
  if (new Set(q.lines.map((l) => l.id)).size !== q.lines.length)
    errors.push("ID layanan duplikat.");
  const paying = q.passengers.filter((p) => !p.foc && p.role === "customer");
  const counts = {
    adult: paying.filter((p) => p.category === "adult").length,
    child: paying.filter((p) => p.category === "child").length,
    infant: paying.filter((p) => p.category === "infant").length,
  };
  if (q.passengers.some((p) => p.category === "child" && p.age === null))
    errors.push("Umur anak saat perjalanan harus diisi.");
  const active = q.lines.filter((l) => !l.addon || l.included);
  if (!active.length) errors.push("Belum ada layanan dalam penawaran.");
  const converted = q.lines.map((l) => {
    let amount = lineAmount(l);
    if (active.includes(l)) {
      if (amount === null) errors.push(`Harga belum tersedia: ${l.label}`);
      if (l.start && l.end) {
        try {
          const n = days(l.start, l.end);
          if (l.basis === "room-night" && n !== l.factor)
            errors.push(
              `Malam hotel ${l.label} tidak cocok dengan check-in/check-out.`,
            );
        } catch (e) {
          errors.push((e as Error).message);
        }
      }
      if (
        l.category === "transport" &&
        l.capacity !== null &&
        l.capacity * l.quantity <
          q.passengers.filter((p) => p.usesVehicle).length
      )
        warnings.push(`Kapasitas kursi belum cukup: ${l.label}`);
      if (
        l.category === "transport" &&
        l.bagCapacity !== null &&
        l.bagCapacity * l.quantity <
          q.passengers
            .filter((p) => p.usesVehicle)
            .reduce((n, p) => n + p.bags, 0)
      )
        warnings.push(`Kapasitas bagasi belum cukup: ${l.label}`);
      if (l.priceStatus !== "validated")
        warnings.push(
          `${l.label}: harga ${l.priceStatus === "historical" ? "historis" : "estimasi"}, periksa tanggal dan kondisi.`,
        );
    }
    try {
      amount =
        amount === null
          ? null
          : money(convert(amount, l.currency, q.baseCurrency, q));
    } catch (e) {
      if (active.includes(l)) errors.push((e as Error).message);
      amount = null;
    }
    return { id: l.id, total: amount, formula: formula(l) };
  });
  const get = (l: CostLine) => converted.find((x) => x.id === l.id)?.total ?? 0;
  const baseCost = money(sum(active.filter((l) => !l.addon).map(get)));
  const addonCost = money(sum(active.filter((l) => l.addon).map(get)));
  const totalCost = money(D(baseCost).plus(addonCost));
  let baseSellCost = 0,
    totalSellCost = 0;
  try {
    baseSellCost = convert(baseCost, q.baseCurrency, q.sellCurrency, q);
    totalSellCost = convert(totalCost, q.baseCurrency, q.sellCurrency, q);
  } catch (e) {
    errors.push((e as Error).message);
  }
  const p = q.pricing,
    c = p.commission;
  const rate = c.kind === "percent" ? c.value / 100 : 0;
  const fixed = c.kind === "fixed" ? c.value : 0;
  if (rate >= 1) errors.push("Komisi persentase harus kurang dari 100%.");
  if (c.kind !== "none" && !c.recipient.trim())
    errors.push("Penerima komisi wajib diisi.");
  if (p.targetType === "margin" && p.target >= 1)
    errors.push("Target margin harus kurang dari 100%.");
  const addonRevenue = money(
    sum(
      active
        .filter((l) => l.addon)
        .map((l) => {
          if (l.selling === null) {
            errors.push(`Harga jual add-on belum tersedia: ${l.label}`);
            return 0;
          }
          return l.selling;
        }),
    ),
  );
  let targetRevenue = 0;
  let targetLand = 0;
  const after = p.targetAfterCommission;
  const r = after ? rate : 0,
    f = after ? fixed : 0;
  // Solve on entire quote, including selected add-ons and explicit discount. Commission is deducted exactly once.
  const denominator = p.targetType === "margin" ? 1 - p.target - r : 1 - r;
  if (!after && !(p.targetType === "margin" && p.target >= 1)) {
    targetLand =
      p.targetType === "markup"
        ? D(baseSellCost)
            .mul(1 + p.target)
            .toNumber()
        : D(baseSellCost)
            .div(1 - p.target)
            .toNumber();
    targetRevenue = targetLand;
  } else if (denominator <= 0)
    errors.push("Target dan komisi tidak memungkinkan revenue positif.");
  else {
    const targetProfit =
      p.targetType === "markup" ? totalSellCost * p.target : 0;
    const adjustment =
      after && c.basis === "land" ? r * (addonRevenue - p.discount) : 0;
    targetRevenue = D(totalSellCost)
      .plus(targetProfit)
      .plus(f)
      .minus(adjustment)
      .div(denominator)
      .toNumber();
    targetLand = D(targetRevenue)
      .minus(addonRevenue)
      .plus(p.discount)
      .toNumber();
    if (targetLand < 0) {
      warnings.push(
        "Pendapatan add-on sudah melampaui target; land usulan dibatasi nol.",
      );
      targetLand = 0;
    }
  }
  const weight = D(counts.adult)
    .mul(q.policy.weights.adult)
    .plus(D(counts.child).mul(q.policy.weights.child))
    .plus(D(counts.infant).mul(q.policy.weights.infant));
  if (p.basis === "weighted" && weight.isZero())
    errors.push(
      "Tidak ada peserta membayar berbobot; gunakan harga total grup/layanan.",
    );
  const unit = weight.gt(0) ? D(targetLand).div(weight) : D(0);
  const sellingIncrement = p.finalRounding ?? q.policy.rounding;
  const prices = Object.fromEntries(
    (["adult", "child", "infant"] as const).map((k) => {
      const calculated = counts[k] > 0 ? unit.mul(q.policy.weights[k]).toNumber() : 0;
      const rounded = money(
        D(calculated).div(sellingIncrement).ceil().mul(sellingIncrement),
      );
      return [
        k,
        {
          count: counts[k],
          calculated,
          rounded,
          applied: counts[k] > 0 ? p.overrides[k] ?? rounded : 0,
          subtotal: money(D(p.overrides[k] ?? rounded).mul(counts[k])),
        },
      ];
    }),
  ) as Record<
    keyof typeof counts,
    {
      count: number;
      calculated: number;
      rounded: number;
      applied: number;
      subtotal: number;
    }
  >;
  const groupCalculated = D(targetLand).div(p.basis === "unit" ? p.units : 1).toNumber();
  const groupSuggested = money(
    D(targetLand)
      .div(p.basis === "unit" ? p.units : 1)
      .div(sellingIncrement)
      .ceil()
      .mul(sellingIncrement),
  );
  const landRevenue =
    p.basis === "weighted"
      ? money(sum(Object.values(prices).map((x) => x.subtotal)))
      : money(
          D(p.overrides.group ?? groupSuggested).mul(
            p.basis === "unit" ? p.units : 1,
          ),
        );
  // Report the rounding already embedded in applied suggestions; overrides are not rounding.
  const packageRoundingAdjustment = p.basis === 'weighted'
    ? money(sum((['adult','child','infant'] as const).map(k=>p.overrides[k] == null ? D(prices[k].rounded).minus(prices[k].calculated).mul(counts[k]).toNumber() : 0)))
    : p.overrides.group == null ? money(D(groupSuggested).minus(groupCalculated).mul(p.basis==='unit'?p.units:1)) : 0;
  const unroundedTotal = money(D(landRevenue).plus(addonRevenue).minus(p.discount));
  const grandTotal = p.finalRounding ? money(D(unroundedTotal).div(p.finalRounding).ceil().mul(p.finalRounding)) : unroundedTotal;
  const roundingAdjustment = money(D(grandTotal).minus(unroundedTotal));
  if (unroundedTotal < 0) errors.push("Diskon melebihi nilai penawaran.");
  const commission = money(
    c.kind === "fixed"
      ? c.value
      : c.kind === "percent"
        ? D(c.basis === "land" ? landRevenue : Math.max(0, grandTotal)).mul(
            rate,
          )
        : 0,
  );
  const profitBeforeCommission = money(D(grandTotal).minus(totalSellCost));
  const profit = money(D(profitBeforeCommission).minus(commission));
  const margin = grandTotal > 0 ? D(profit).div(grandTotal).toNumber() : null;
  const markup =
    totalSellCost > 0 ? D(profit).div(totalSellCost).toNumber() : null;
  for (const fx of q.fx)
    if (
      fx.kind === "working" && !fx.effectiveDate &&
      (fx.validTo < q.start || fx.validFrom > q.start)
    )
      warnings.push(
        `Kurs ${fx.from}/${fx.to} di luar masa berlaku untuk trip.`,
      );
  if (
    q.policy.reviewBelowMargin &&
    margin !== null &&
    margin < q.policy.minimumMargin &&
    !q.reviewConfirmed
  )
    warnings.push(
      "Margin di bawah batas yang ditetapkan; periksa harga penawaran.",
    );
  const costComplete =
    active.length > 0 &&
    active.every(
      (l) =>
        get(l) !== undefined &&
        converted.find((x) => x.id === l.id)?.total !== null,
    ) &&
    !errors.some((e) => e.startsWith("Kurs kerja"));
  return {
    costComplete,
    knownCostSubtotal: totalCost,
    engine: ENGINE_VERSION,
    duration,
    travelers: q.passengers.length,
    paying: paying.length,
    counts,
    weight: weight.toNumber(),
    lines: converted,
    baseCost: costComplete ? baseCost : null,
    addonCost: costComplete ? addonCost : null,
    totalCost: costComplete ? totalCost : null,
    totalCostSelling: costComplete ? money(totalSellCost) : null,
    baseCostSelling: costComplete ? money(baseSellCost) : null,
    prices,
    targetRevenue,
    targetLand,
    groupCalculated,
    groupSuggested,
    landRevenue,
    addonRevenue,
    discount: p.discount,
    unroundedTotal: costComplete ? unroundedTotal : null,
    roundingAdjustment: costComplete ? roundingAdjustment : null,
    packageRoundingAdjustment: costComplete ? packageRoundingAdjustment : null,
    totalRoundingAdjustment: costComplete ? money(D(packageRoundingAdjustment).plus(roundingAdjustment)) : null,
    grandTotal: costComplete ? grandTotal : null,
    commission,
    profitBeforeCommission: costComplete ? profitBeforeCommission : null,
    profit: costComplete ? profit : null,
    margin: costComplete ? margin : null,
    markup: costComplete ? markup : null,
    costPerPaying:
      costComplete && paying.length
        ? money(D(totalCost).div(paying.length))
        : null,
    errors: [...new Set(errors)],
    warnings: [...new Set(warnings)],
    complete: errors.length === 0,
  };
}
export type Calculation = ReturnType<typeof calculate>;
