import { blankQuote, newLine, demoPolicy, type Quote } from "./model";
export const fxDemo = {
  id: "fx-demo-v1",
  from: "EUR" as const,
  to: "IDR" as const,
  rate: 20850,
  source: "Contoh dummy; bukan kurs nyata",
  recordedAt: "2026-09-21T00:00:00Z",
  validFrom: "2026-01-01",
  validTo: "2027-12-31",
  kind: "working" as const,
};
export function passenger(
  category: "adult" | "child" | "infant" = "adult",
  foc = false,
  role: "customer" | "TL" | "staff" = "customer",
) {
  return {
    id: crypto.randomUUID(),
    name:
      category === "adult"
        ? "Dewasa"
        : category === "child"
          ? "Anak"
          : "Infant",
    category,
    age: category === "child" ? 7 : category === "infant" ? 1 : 35,
    role,
    foc,
    usesVehicle: true,
    bags: 1,
  };
}
export function transfer(): Quote {
  const q = blankQuote();
  Object.assign(q, {
    ownerName: "Hani",
    sellCurrency: "EUR",
    sellCurrencyConfirmed: true,
    customer: "Bapak Arif · DEMO",
    trip: "CDG → Paris · Airport transfer",
    mode: "transfer",
    start: "2026-10-12",
    end: "2026-10-12",
    validUntil: "2026-10-01",
    destination: "Paris",
    entry: "CDG",
    exit: "Paris",
    inclusions: "Transfer privat CDG ke hotel Paris.",
    exclusions: "Layanan di luar rute yang disepakati.",
    terms: "Harga dummy untuk pengujian. Bukan tarif layanan nyata.",
    fx: [fxDemo],
  });
  q.passengers = [passenger(), passenger()];
  q.pricing.basis = "group";
  q.lines = [
    {
      ...newLine(),
      label: "Airport transfer · MPV",
      supplier: "Partner Demo Paris",
      city: "Paris",
      unitPrice: 180,
      priceStatus: "validated",
      source: "Fixture penerimaan / bukan tarif nyata",
      capacity: 4,
      bagCapacity: 4,
    },
  ];
  return q;
}
export function family(): Quote {
  const q = transfer();
  Object.assign(q, {
    customer: "Keluarga Danysa · DEMO",
    trip: "Paris, Grenoble & Lyon",
    mode: "trip",
    start: "2026-10-12",
    end: "2026-10-16",
    destination: "Paris → Grenoble → Lyon",
    entry: "CDG Paris",
    exit: "Lyon",
    declaredPax: 5,
    preferences:
      "Perjalanan keluarga, dua anak. Jadwal perlu validasi operasional.",
    policyConfirmed: false,
  });
  q.passengers = [
    passenger(),
    passenger(),
    passenger(),
    passenger("child"),
    passenger("child"),
  ];
  q.pricing.basis = "weighted";
  q.pricing.targetType = "margin";
  q.pricing.target = 0.2;
  q.itinerary = [
    "Bonjour, Paris",
    "Paris bersama keluarga",
    "Menuju Grenoble",
    "Grenoble → Lyon",
    "Au revoir, Lyon",
  ].map((title, i) => ({
    id: crypto.randomUUID(),
    date: `2026-10-${12 + i}`,
    city: ["Paris", "Paris", "Grenoble", "Lyon", "Lyon"][i],
    title,
    description:
      "Draft itinerary dummy. Rute, waktu tempuh dan kelayakan driver perlu diperiksa.",
  }));
  q.lines = [
    {
      ...newLine(),
      label: "Transport privat · 5 hari",
      city: "Paris → Grenoble → Lyon",
      supplier: "Partner Demo",
      basis: "vehicle-day",
      quantity: 1,
      factor: 5,
      unit: "kendaraan",
      unitPrice: 400,
      capacity: 7,
      bagCapacity: 7,
      includedCosts: ["driver", "fuel"],
      notes: "Hotel/makan driver belum termasuk.",
    },
    {
      ...newLine(),
      label: "Hotel pelanggan · 2 kamar / 4 malam",
      category: "hotel",
      side: "individual",
      basis: "room-night",
      quantity: 2,
      factor: 4,
      unit: "kamar",
      unitPrice: 200,
      start: "2026-10-12",
      end: "2026-10-16",
      supplier: "Hotel Demo",
      city: "Multi-city",
      notes: "Total 8 room-night; rincian hotel per kota harus dikonfirmasi.",
    },
    {
      ...newLine(),
      label: "Tiket dan aktivitas keluarga",
      category: "activity",
      side: "individual",
      basis: "supplier-total",
      unitPrice: 400,
      supplier: "Supplier Demo",
      city: "Paris",
    },
  ];
  return q;
}
export const catalogSeed = [
  {
    ...newLine(),
    id: "CAT-TRANSFER-PARIS",
    label: "CDG → Paris · MPV privat",
    category: "transport" as const,
    city: "Paris",
    supplier: "Partner Demo Paris",
    unitPrice: 180,
    capacity: 4,
    bagCapacity: 4,
    priceStatus: "historical" as const,
    source: "Contoh katalog, pernah dikutip; bukan bukti pemesanan",
    start: "2026-10-01",
    end: "2026-10-31",
  },
  {
    ...newLine(),
    id: "CAT-HOTEL-LYON",
    label: "Hotel Demo Lyon · Twin + breakfast",
    category: "hotel" as const,
    city: "Lyon",
    side: "individual" as const,
    basis: "room-night" as const,
    unit: "kamar",
    unitPrice: 200,
    supplier: "Hotel Demo Lyon",
    start: "2026-10-15",
    end: "2026-10-16",
    notes: "Okupansi 2. Extra bed dan city tax perlu konfirmasi.",
    source: "Tarif dummy musim contoh",
  },
  {
    ...newLine(),
    id: "CAT-MEAL-PARIS",
    label: "Menu grup · restoran demo",
    category: "meal" as const,
    city: "Paris",
    side: "individual" as const,
    basis: "unit" as const,
    unit: "orang",
    unitPrice: 28,
    supplier: "Restoran Demo",
    notes: "Halal, kapasitas dan diet belum dikonfirmasi.",
    source: "Data dummy",
  },
];
