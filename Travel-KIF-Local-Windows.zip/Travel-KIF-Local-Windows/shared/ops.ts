/** One calendar month after completion, clamped to the last day of the next month. */
export function opsArchiveAt(completedAt: string): string {
  const d = new Date(completedAt);
  const day = d.getUTCDate();
  d.setUTCDate(1);
  d.setUTCMonth(d.getUTCMonth() + 1);
  const last = new Date(Date.UTC(d.getUTCFullYear(), d.getUTCMonth() + 1, 0)).getUTCDate();
  d.setUTCDate(Math.min(day, last));
  return d.toISOString();
}
export function isOpsArchived(o: {status: string; updated_at: string}, now = Date.now()) {
  return o.status === 'Completed' && new Date(opsArchiveAt(o.updated_at)).getTime() <= now;
}
