CREATE TABLE IF NOT EXISTS email_settings(id INTEGER PRIMARY KEY CHECK(id=1),enabled INTEGER NOT NULL DEFAULT 0,sender_email TEXT NOT NULL DEFAULT '',sender_name TEXT NOT NULL DEFAULT 'Travel KIF Quotation Workbook',reply_to TEXT NOT NULL DEFAULT '',timezone TEXT NOT NULL DEFAULT 'Asia/Jakarta');
INSERT OR IGNORE INTO email_settings(id) VALUES(1);
CREATE TABLE IF NOT EXISTS email_preferences(user_id TEXT PRIMARY KEY REFERENCES users(id),email TEXT NOT NULL,enabled INTEGER NOT NULL DEFAULT 0,timezone TEXT NOT NULL DEFAULT 'Asia/Jakarta');
CREATE TABLE IF NOT EXISTS email_outbox(id TEXT PRIMARY KEY,event_id TEXT NOT NULL,quote_id TEXT NOT NULL REFERENCES quotations(id),recipient_id TEXT NOT NULL REFERENCES users(id),recipient_email TEXT NOT NULL,payload TEXT NOT NULL,status TEXT NOT NULL DEFAULT 'pending',attempts INTEGER NOT NULL DEFAULT 0,next_attempt TEXT NOT NULL,created_at TEXT NOT NULL,first_attempt TEXT,sent_at TEXT,provider_id TEXT,last_error TEXT,UNIQUE(event_id,recipient_id));
CREATE INDEX IF NOT EXISTS email_outbox_due ON email_outbox(status,next_attempt);
CREATE INDEX IF NOT EXISTS email_outbox_recent ON email_outbox(created_at DESC);
