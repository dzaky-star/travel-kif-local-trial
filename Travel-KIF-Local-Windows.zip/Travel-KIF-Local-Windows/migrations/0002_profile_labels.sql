UPDATE users SET name='Hani' WHERE id='demo-tc' AND name='Nadia';
UPDATE users SET name='OPS' WHERE id='demo-ops';
UPDATE users SET name='Finance' WHERE id='demo-finance';
UPDATE users SET name='Manager' WHERE id='demo-director';
