CREATE INDEX IF NOT EXISTS notifications_user_unread_created ON notifications(user_id,read_at,created_at DESC);
