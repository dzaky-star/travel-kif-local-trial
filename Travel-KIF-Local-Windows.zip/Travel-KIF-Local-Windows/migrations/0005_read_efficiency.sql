CREATE INDEX IF NOT EXISTS audit_entity_action ON audit_events(entity_id,action);
CREATE INDEX IF NOT EXISTS audit_action_created ON audit_events(action,created_at DESC);
CREATE INDEX IF NOT EXISTS notifications_user_created ON notifications(user_id,created_at DESC);
CREATE INDEX IF NOT EXISTS notifications_quote_user_read ON notifications(quote_id,user_id,read_at);
CREATE INDEX IF NOT EXISTS ops_quote_updated ON ops_requests(quote_id,updated_at DESC);
