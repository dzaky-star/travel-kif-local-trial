@echo off
setlocal
cd /d "%~dp0"
title Travel KIF - Localhost
node local-windows/start.mjs
pause
