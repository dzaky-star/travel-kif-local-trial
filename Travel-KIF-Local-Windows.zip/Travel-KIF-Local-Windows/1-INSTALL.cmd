@echo off
setlocal
cd /d "%~dp0"
title Travel KIF - Install Lokal
where node >nul 2>&1
if errorlevel 1 (
 echo Instal Node.js LTS dari https://nodejs.org/en/download dahulu.
 pause
 exit /b 1
)
node -e "const v=process.versions.node.split('.').map(Number);if(v[0]<22||(v[0]===22&&v[1]<13)){console.error('Perlu Node.js 22.13 atau lebih baru.');process.exit(1)}"
if errorlevel 1 goto failed
set WRANGLER_SEND_METRICS=false
call npm ci --no-audit --no-fund
if errorlevel 1 goto failed
call npm run build
if errorlevel 1 goto failed
call npm run setup:local
if errorlevel 1 goto failed
echo.
echo SELESAI. Buka AKSES-LOKAL.txt lalu klik 2-JALANKAN.cmd.
pause
exit /b 0
:failed
echo Instalasi belum selesai. Simpan pesan error di jendela ini untuk diperiksa.
pause
exit /b 1
