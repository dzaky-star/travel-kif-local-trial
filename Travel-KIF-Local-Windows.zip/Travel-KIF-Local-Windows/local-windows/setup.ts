import fs from 'node:fs';
import {spawnSync} from 'node:child_process';
import {randomBytes} from 'node:crypto';
import {passwordHash} from '../server/login';
import {demoPolicy} from '../shared/model';
import {family,transfer,fxDemo} from '../shared/fixtures';
import {calculate} from '../shared/calculate';
const run=(args:string[])=>{const r=spawnSync(process.execPath,['node_modules/wrangler/bin/wrangler.js',...args,'--config','wrangler.local.json'],{stdio:['ignore','inherit','inherit'],env:{...process.env,WRANGLER_SEND_METRICS:'false'}});if(r.status!==0)throw Error('Setup failed; retry 1-INSTALL.cmd.');};
const config=JSON.parse(fs.readFileSync('wrangler.local.json','utf8'));
if(config.name!=='travel-kif-local-trial'||config.d1_databases[0].database_id!=='00000000-0000-0000-0000-000000000001'||config.main!=='local-windows/worker.ts')throw Error('Local configuration changed. Setup stopped.');
fs.mkdirSync('local-data',{recursive:true});
run(['d1','migrations','apply','DB','--local','--persist-to','local-data']);
if(fs.existsSync('local-data/initialized.json')){console.log('Database lokal sudah ada. Data tetap dipertahankan.');process.exit(0);}
const literal=(x:unknown)=>typeof x==='number'?String(x):x===null?'NULL':"'"+String(x).replaceAll("'","''")+"'";
const sql:string[]=[];
const insert=(table:string,values:unknown[])=>sql.push(`INSERT OR IGNORE INTO ${table} VALUES(${values.map(literal).join(',')});`);
const profiles=[['admin','Admin Lokal','Admin'],['tc','TC Percobaan','TC'],['ops','OPS Percobaan','OPS'],['artha','Artha - Percobaan','Director'],['finance','Finance Percobaan','Finance']];
const accessPath='local-data/access.json';
const access=fs.existsSync(accessPath)?JSON.parse(fs.readFileSync(accessPath,'utf8')):Object.fromEntries(profiles.map(([id])=>[id,randomBytes(12).toString('base64url')]));
fs.writeFileSync(accessPath,JSON.stringify(access),{mode:0o600});
for(const [id,name,role] of profiles){
 insert('users',[`trial-${id}`,`${id}@trial.invalid`,name,JSON.stringify([role]),1,0]);
 const salt=randomBytes(16).toString('hex');insert('login_credentials',[`trial-${id}`,id,await passwordHash(access[id],salt),salt]);
}
const now=new Date().toISOString();
insert('policies',[demoPolicy.id,JSON.stringify(demoPolicy),now,'trial-finance']);
insert('fx_rates',[fxDemo.id,JSON.stringify(fxDemo),now,'trial-finance']);
for(const [i,q] of [family(),transfer()].entries()){
 const id=`LOCAL-TRIAL-${i+1}`;q.customer=`Pelanggan contoh ${i+1} - BUKAN DATA ASLI`;q.trip=`PERCOBAAN LOKAL ${i+1}`;q.ownerName='TC Percobaan';
 insert('customers',[`trial-client-${i}`,q.customer,q.agent]);
 insert('quotations',[id,`trial-client-${i}`,'trial-tc',1,now,now,null,null]);
 insert('revisions',[id,1,'Draft',JSON.stringify(q),JSON.stringify(calculate(q)),'trial-tc',now,`trial-initial-${i}`]);
 for(const [table,items] of [['passengers',q.passengers],['itinerary',q.itinerary],['cost_lines',q.lines]] as const)for(const item of items)insert(table,[id,1,item.id,JSON.stringify(item)]);
}
fs.writeFileSync('local-data/initialize.sql',sql.join('\n'),{mode:0o600});
run(['d1','execute','DB','--local','--persist-to','local-data','--file','local-data/initialize.sql']);
fs.writeFileSync('AKSES-LOKAL.txt','AKSES PERCOBAAN LOKAL - BUKAN AKUN ONLINE\r\nhttp://127.0.0.1:8787\r\n\r\n'+profiles.map(([id,name])=>`${name}\r\nUsername: ${id}\r\nPassword: ${access[id]}\r\n`).join('\r\n')+'\r\nLogin admin untuk pindah profil TC / OPS / Artha / Finance.\r\nPassword dibuat unik di komputer ini. Jangan publikasikan file ini.\r\n',{mode:0o600});
fs.writeFileSync('local-data/initialized.json',JSON.stringify({createdAt:now}));fs.unlinkSync('local-data/initialize.sql');
console.log('Selesai. Buka AKSES-LOKAL.txt untuk login, lalu 2-JALANKAN.cmd.');
