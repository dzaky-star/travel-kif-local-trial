import app from '../server/index';
import {authenticate, type Env} from '../server/auth';
// This entry point belongs only to the isolated desktop trial package.
export default {
 async fetch(req:Request, bindings:Env, ctx:ExecutionContext) {
  const url=new URL(req.url);
  if(!['127.0.0.1','localhost','[::1]'].includes(url.hostname))return new Response('Local trial only',{status:403});
  // Explicit allowlist: no production authentication, email or Google credentials.
  const env:Env={DB:bindings.DB,ASSETS:bindings.ASSETS,APP_ENV:'local',
   GEMINI_API_KEY:bindings.GEMINI_API_KEY,TAVILY_API_KEY:bindings.TAVILY_API_KEY,
   GEMINI_MODEL:bindings.GEMINI_MODEL,AI_DAILY_REQUEST_LIMIT:'20'};
  if(['/api/sync','/api/sync/tick','/api/sheets/setup','/api/import/sheets','/api/fx/tick'].includes(url.pathname))
   return Response.json({error:'Integrasi online dinonaktifkan pada paket percobaan lokal.'},{status:403});
  if(url.pathname==='/api/settings'){
   try{await authenticate(req,env);}catch{return Response.json({error:'Silakan masuk.'},{status:401});}
   const policies=(await env.DB.prepare('SELECT data FROM policies ORDER BY created_at DESC').all()).results.map((r:any)=>JSON.parse(r.data));
   const fx=(await env.DB.prepare('SELECT data FROM fx_rates ORDER BY created_at DESC').all()).results.map((r:any)=>JSON.parse(r.data));
   return Response.json({policies,fx,dailyFx:{state:'local-trial'}},{headers:{'Cache-Control':'no-store'}});
  }
  return app.fetch(req,env,ctx);
 }
};
