import { QuoteInput, Status, Policy, Fx, type Quote } from "../shared/model";
import { calculate } from "../shared/calculate";
import { fail, canEdit, type User, type Env } from "./auth";
export const now = () => new Date().toISOString();
export function audit(
  db: D1Database,
  u: User,
  action: string,
  id: string,
  detail = "",
) {
  return db
    .prepare("INSERT INTO audit_events VALUES(?,?,?,?,?,?)")
    .bind(crypto.randomUUID(), u.id, action, id, detail, now());
}
export async function getQuoteVersion(db: D1Database, id: string) {
  const row = await db.prepare("SELECT q.id,q.current_revision FROM quotations q WHERE q.id=? AND NOT EXISTS (SELECT 1 FROM audit_events a WHERE a.entity_id=q.id AND a.action='quote.delete')").bind(id).first();
  if (!row) fail(404, "Quotation tidak ditemukan.");
  return row as {id:string;current_revision:number};
}
export async function getQuote(db: D1Database, id: string, revision?: number) {
  const row: any = await db
    .prepare(
      "SELECT q.*,COALESCE(NULLIF(json_extract(r.input_json,'$.ownerName'),''),(SELECT name FROM users WHERE id=q.owner_id)) AS owner_name,(SELECT state FROM sync_jobs s WHERE s.quote_id=q.id AND s.revision=r.revision) AS sync_state,r.status,r.input_json,r.result_json,r.actor_id,r.created_at AS revision_created,r.revision FROM quotations q JOIN revisions r ON r.quote_id=q.id AND r.revision=COALESCE(?,q.current_revision) WHERE q.id=? AND NOT EXISTS (SELECT 1 FROM audit_events a WHERE a.entity_id=q.id AND a.action='quote.delete')",
    )
    .bind(revision ?? null, id)
    .first();
  if (!row) fail(404, "Quotation tidak ditemukan.");
  return {
    ...row,
    costReview: await db.prepare("SELECT id,status,revision,response,context FROM ops_requests WHERE quote_id=? AND json_extract(context,'$.kind')='cost-approval' ORDER BY updated_at DESC LIMIT 1").bind(id).first(),
    input: JSON.parse(row.input_json),
    result: JSON.parse(row.result_json),
    input_json: undefined,
    result_json: undefined,
  };
}
export async function saveQuote(env: Env, u: User, b: any, id?: string, review?: {statements: D1PreparedStatement[]}) {
  const requestId = String(b.requestId || "");
  if (!/^[a-zA-Z0-9-]{16,80}$/.test(requestId))
    fail(400, "Request ID wajib valid.");
  const input = QuoteInput.parse(b.input),
    status = Status.parse(b.status ?? "Draft");
  const prev = id ? await getQuote(env.DB, id) : null;
  input.ownerName = prev ? (prev.input.ownerName || prev.owner_name) : u.name;
  if (prev && !review && ['Confirmed','Lost','Cancelled'].includes(prev.status) &&
      (status !== prev.status || JSON.stringify(input) !== JSON.stringify(prev.input)) &&
      !(b.reopen === true && ['Draft','Sent','Negotiation','Confirmed','Lost'].includes(status) && JSON.stringify(input) === JSON.stringify(prev.input)))
    fail(409, 'Gunakan Buka kembali sebagai Draft untuk membuka quotation final.');
  if (prev?.status === 'Sent' && !review) {
    if (JSON.stringify(input) !== JSON.stringify(prev.input))
      fail(409, 'Quotation Sent terkunci. Gunakan Ubah quotation terlebih dahulu.');
    if (status === 'Draft' && b.reopen !== true)
      fail(409, 'Gunakan Ubah quotation untuk kembali ke Draft.');
  }

  if (prev && !review && prev.costReview?.status === "ApprovalWaiting") {
    const reviewed=(q:any)=>JSON.stringify([q.lines,q.itinerary,q.start,q.end,q.destination,q.passengers,q.entry,q.exit,q.preferences,q.baseCurrency,q.fx]);
    if(reviewed(input)!==reviewed(prev.input)) fail(409,"Itinerary dan CA sedang diperiksa OPS. Batalkan pengajuan untuk mengubahnya; harga penawaran tetap dapat diedit.");
  }
  if (prev && !review && ["ManagerWaiting","ApprovalApproved"].includes(prev.costReview?.status) && JSON.stringify(input)!==JSON.stringify(prev.input)) {
    fail(409,"Quotation sedang diperiksa Manager. Batalkan pengajuan sebelum mengubahnya.");
  }
  if (prev && !review && !canEdit(u, prev.owner_id))
    fail(403, "Quotation ini tidak dapat diedit.");
  if (
    !prev &&
    !u.roles.some(
      (r) => ["TC","OPS","Finance","Admin"].includes(r) || (r === "Director" && u.can_edit),
    )
  )
    fail(403, "Tidak dapat membuat quotation.");

  const duplicate: any = await env.DB.prepare(
    "SELECT quote_id,revision,actor_id FROM revisions WHERE request_id=?",
  )
    .bind(requestId)
    .first();
  if (duplicate) {
    if (duplicate.actor_id !== u.id || (id && duplicate.quote_id !== id))
      fail(409, "Request ID sudah dipakai.");
    return getQuote(env.DB, duplicate.quote_id, duplicate.revision);
  }
  if (prev && b.expectedRevision !== prev.current_revision)
    fail(
      409,
      "Quotation sudah diubah pengguna lain. Muat revisi terbaru sebelum menyimpan.",
    );
  // Policy and FX snapshots may only be taken from current server records or preserved old snapshots.
  const knownPolicy: any = await env.DB.prepare(
    "SELECT data FROM policies WHERE id=?",
  )
    .bind(input.policy.id)
    .first();
  if (
    !knownPolicy ||
    JSON.stringify(Policy.parse(JSON.parse(knownPolicy.data))) !==
      JSON.stringify(input.policy)
  )
    fail(400, "Snapshot kebijakan tidak dikenali.");
  for (const fx of input.fx) {
    const row: any = await env.DB.prepare(
      "SELECT data FROM fx_rates WHERE id=?",
    )
      .bind(fx.id)
      .first();
    if (
      !row ||
      JSON.stringify(Fx.parse(JSON.parse(row.data))) !== JSON.stringify(fx)
    )
      fail(400, "Snapshot kurs tidak dikenali.");
  }
  for (const image of input.images) {
    const bytes = Uint8Array.from(atob(image.dataUrl.split(",")[1]), (c) =>
      c.charCodeAt(0),
    );
    if (
      bytes.length > 200000 ||
      bytes.length < 24 ||
      bytes[0] !== 137 ||
      String.fromCharCode(...bytes.slice(1, 4)) !== "PNG"
    )
      fail(422, "Gambar harus PNG maksimal 200 KB.");
    const view = new DataView(bytes.buffer);
    if (view.getUint32(16) > 3000 || view.getUint32(20) > 3000)
      fail(422, "Ukuran gambar maksimal 3000 × 3000 piksel.");
  }
  for (const image of input.images) {
    try {
      const { PDFDocument } = await import("pdf-lib");
      const pdf = await PDFDocument.create();
      await pdf.embedPng(image.dataUrl);
    } catch {
      fail(422, "File PNG tidak dapat dibaca. Pilih gambar yang valid.");
    }
  }
  const result = calculate(input);
  const offerStatus = ["Sent", "Negotiation", "Confirmed"].includes(status);
  if (offerStatus && !result.complete) fail(422, result.errors.join(" "));
  const quoteId =
    id ?? "KIF-" + new Date().getUTCFullYear() + "-" + crypto.randomUUID();
  const rev = prev ? prev.current_revision + 1 : 1;
  const time = now();
  const customerId = prev?.customer_id ?? crypto.randomUUID();
  const statements: D1PreparedStatement[] = [];
  if (!prev) {
    statements.push(
      env.DB.prepare("INSERT INTO customers VALUES(?,?,?)").bind(
        customerId,
        input.customer,
        input.agent,
      ),
    );
    statements.push(
      env.DB.prepare("INSERT INTO quotations VALUES(?,?,?,?,?,?,?,?)").bind(
        quoteId,
        customerId,
        u.id,
        rev,
        time,
        time,
        offerStatus ? result.grandTotal : null,
        offerStatus ? input.sellCurrency : null,
      ),
    );
  }
  // Unique (quote,revision) fences concurrent edits; D1 batch rolls the full transaction back on collision.
  statements.push(
    env.DB.prepare("INSERT INTO revisions VALUES(?,?,?,?,?,?,?,?)").bind(
      quoteId,
      rev,
      status,
      JSON.stringify(input),
      JSON.stringify(result),
      u.id,
      time,
      requestId,
    ),
  );
  if (prev) {
    statements.push(
      env.DB.prepare(
        "UPDATE quotations SET current_revision=?,updated_at=?,initial_offer=COALESCE(initial_offer,?),initial_currency=COALESCE(initial_currency,?) WHERE id=? AND current_revision=?",
      ).bind(
        rev,
        time,
        offerStatus ? result.grandTotal : null,
        offerStatus ? input.sellCurrency : null,
        quoteId,
        prev.current_revision,
      ),
    );
    statements.push(
      env.DB.prepare("UPDATE customers SET name=?,agent=? WHERE id=?").bind(
        input.customer,
        input.agent,
        customerId,
      ),
    );
  }
  for (const [table, items] of [
    ["passengers", input.passengers],
    ["itinerary", input.itinerary],
    ["cost_lines", input.lines],
  ] as const)
    if (items.length)
      statements.push(
        env.DB.prepare(
          `INSERT INTO ${table} SELECT ?,?,json_extract(value,'$.id'),value FROM json_each(?)`,
        ).bind(quoteId, rev, JSON.stringify(items)),
      );
  statements.push(
    env.DB.prepare("INSERT INTO negotiations VALUES(?,?,?,?,?)").bind(
      crypto.randomUUID(),
      quoteId,
      rev,
      JSON.stringify({
        pricing: input.pricing,
        total: result.grandTotal,
        currency: input.sellCurrency,
      }),
      time,
    ),
  );
  statements.push(
    env.DB.prepare(
      "INSERT INTO sync_jobs(id,quote_id,revision,next_attempt,updated_at) VALUES(?,?,?,?,?)",
    ).bind(crypto.randomUUID(), quoteId, rev, time, time),
  );
  if(review) statements.push(...review.statements);
  statements.push(audit(env.DB, u, "quote.save", quoteId, `revision ${rev}`));
  try {
    await env.DB.batch(statements);
  } catch (e) {
    if (String(e).includes("UNIQUE")) {
      const dup: any = await env.DB.prepare(
        "SELECT quote_id,revision,actor_id FROM revisions WHERE request_id=?",
      )
        .bind(requestId)
        .first();
      if (dup?.actor_id === u.id)
        return getQuote(env.DB, dup.quote_id, dup.revision);
      fail(409, "Konflik revisi. Muat ulang data terbaru.");
    }
    throw e;
  }
  return getQuote(env.DB, quoteId);
}
export const backupTables = [
  "users",
  "customers",
  "quotations",
  "revisions",
  "passengers",
  "itinerary",
  "cost_lines",
  "negotiations",
  "suppliers",
  "catalog",
  "price_history",
  "ops_requests",
  "notifications",
  "policies",
  "fx_rates",
  "documents",
  "audit_events",
  "sync_jobs",
] as const;
export async function backup(db: D1Database) {
  const data: Record<string, unknown[]> = {};
  const results = await db.batch(
    backupTables.map((table) => db.prepare(`SELECT * FROM ${table}`)),
  );
  backupTables.forEach((table, i) => (data[table] = results[i].results));
  return { schema: 1, createdAt: now(), tables: data };
}
export function sqlLiteral(v: unknown) {
  return v === null
    ? "NULL"
    : typeof v === "number"
      ? String(v)
      : "'" + String(v).replaceAll("'", "''") + "'";
}
export function backupSQL(b: Awaited<ReturnType<typeof backup>>) {
  return (
    "PRAGMA foreign_keys=OFF;\n" +
    backupTables
      .flatMap((t) =>
        b.tables[t].map(
          (r: any) =>
            `INSERT INTO ${t} (${Object.keys(r).join(",")}) VALUES (${Object.values(r).map(sqlLiteral).join(",")});`,
        ),
      )
      .join("\n") +
    "\nPRAGMA foreign_keys=ON;\n"
  );
}

export async function deleteQuote(env:Env,u:User,id:string){
 const q=await getQuote(env.DB,id);
 if(u.id!==q.owner_id&&!u.roles.includes('Admin'))fail(403,'Hanya pemilik quotation atau Admin yang dapat menghapus.');
 await env.DB.batch([
  audit(env.DB,u,'quote.delete',id,'Dihapus dari workspace; riwayat dipertahankan.'),
  env.DB.prepare("UPDATE notifications SET read_at=? WHERE quote_id=?").bind(now(),id),
  env.DB.prepare("UPDATE sync_jobs SET state='cancelled',updated_at=? WHERE quote_id=? AND state IN ('pending','failed')").bind(now(),id),
  env.DB.prepare("UPDATE sync_jobs SET state='pending',error=NULL,next_attempt=?,updated_at=? WHERE quote_id=? AND revision=?").bind(now(),now(),id,q.current_revision)
 ]);
 return {deleted:true};
}

export async function duplicateQuote(env:Env,u:User,id:string,requestId:string){
 const source=await getQuote(env.DB,id),input=structuredClone(source.input);
 input.trip+=' (salinan)';input.policyConfirmed=false;input.reviewConfirmed=false;
 input.notes+='\nSalinan: periksa ulang tanggal, kurs, layanan dan harga.';
 input.lines.forEach((line:any)=>{line.priceStatus='historical';});
 // A new quotation ID starts a fresh approval, discussion and revision history.
 return saveQuote(env,u,{input,status:'Draft',requestId});
}
