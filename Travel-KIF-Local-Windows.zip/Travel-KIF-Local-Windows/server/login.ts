import {body,fail,type Env} from './auth';
const hex=(b:ArrayBuffer)=>Array.from(new Uint8Array(b),x=>x.toString(16).padStart(2,'0')).join('');
export async function digest(s:string){return hex(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(s)));}
export async function passwordHash(password:string,salt:string){
 const key=await crypto.subtle.importKey('raw',new TextEncoder().encode(password),'PBKDF2',false,['deriveBits']);
 return hex(await crypto.subtle.deriveBits({name:'PBKDF2',hash:'SHA-256',salt:new TextEncoder().encode(salt),iterations:100000},key,256));
}
export function sessionToken(req:Request){return req.headers.get('cookie')?.match(/(?:^|;\s*)kif_session=([^;]+)/)?.[1]||'';}
const cookie=(req:Request,value:string,age?:number)=>`kif_session=${value}; Path=/; HttpOnly; SameSite=Strict${new URL(req.url).protocol==='https:'?'; Secure':''}${age===undefined?'':'; Max-Age='+age}`;
export async function loginRoute(req:Request,env:Env){
 const path=new URL(req.url).pathname;
 if(req.method!=='POST')fail(405,'Metode tidak tersedia.');
 if(path==='/api/logout'){
   await env.DB.prepare('DELETE FROM login_sessions WHERE token_hash=?').bind(await digest(sessionToken(req))).run();
   return Response.json({}, {headers:{'Set-Cookie':cookie(req,'',0)}});
 }
 const b=await body(req);
 const username=String(b.username||'').trim().toLowerCase(),password=String(b.password||'');
 if(!username||username.length>80||!password||password.length>256)fail(400,'Isi username dan password.');
 const key=await digest(username+'|'+(req.headers.get('CF-Connecting-IP')||'local'));
 const now=Date.now();
 const attempt:any=await env.DB.prepare('SELECT * FROM login_attempts WHERE key=?').bind(key).first();
 if(attempt&&attempt.expires_at>now&&attempt.attempts>=10)fail(429,'Terlalu banyak percobaan. Coba lagi dalam 15 menit.');
 await env.DB.prepare('INSERT INTO login_attempts VALUES(?,1,?) ON CONFLICT(key) DO UPDATE SET attempts=CASE WHEN expires_at<? THEN 1 ELSE attempts+1 END,expires_at=CASE WHEN expires_at<? THEN excluded.expires_at ELSE expires_at END').bind(key,now+900000,now,now).run();
 const row:any=await env.DB.prepare('SELECT c.*,u.active FROM login_credentials c JOIN users u ON u.id=c.user_id WHERE c.username=?').bind(username).first();
 const actual=await passwordHash(password,row?.salt||'unknown-account');
 if(!row||!row.active||actual!==row.password_hash)fail(401,'Username atau password salah.');
 const token=crypto.randomUUID()+crypto.randomUUID(),seconds=b.remember===true?30*86400:8*3600;
 await env.DB.batch([
 env.DB.prepare('DELETE FROM login_attempts WHERE key=?').bind(key),
 env.DB.prepare('DELETE FROM login_sessions WHERE expires_at<?').bind(now),
 env.DB.prepare('INSERT INTO login_sessions VALUES(?,?,NULL,?)').bind(await digest(token),row.user_id,now+seconds*1000)
 ]);
 return Response.json({}, {headers:{'Set-Cookie':cookie(req,token,b.remember===true?seconds:undefined),'Cache-Control':'no-store'}});
}
export async function sessionUser(req:Request,env:Env){
 const token=sessionToken(req);if(!token)return null;
 const session:any=await env.DB.prepare('SELECT * FROM login_sessions WHERE token_hash=? AND expires_at>?').bind(await digest(token),Date.now()).first();
 if(!session)return null;
 const original:any=await env.DB.prepare('SELECT * FROM users WHERE id=? AND active=1').bind(session.user_id).first();
 if(!original)return null;
 const admin=JSON.parse(original.roles).includes('Admin');
 const row:any=session.profile_id&&admin?await env.DB.prepare('SELECT * FROM users WHERE id=? AND active=1').bind(session.profile_id).first():original;
 if(!row)return null;
 return {...row,roles:JSON.parse(row.roles),sessionAdmin:admin,sessionOwner:original.id};
}
export async function switchProfile(req:Request,env:Env){
 const u=await sessionUser(req,env);if(!u?.sessionAdmin)fail(403,'Hanya Admin dapat pindah profil.');
 const b=await body(req);
 const target=await env.DB.prepare('SELECT u.id FROM users u JOIN login_credentials c ON c.user_id=u.id WHERE u.id=? AND u.active=1').bind(b.id).first();
 if(!target)fail(404,'Profil tidak tersedia.');
 await env.DB.batch([
 env.DB.prepare('UPDATE login_sessions SET profile_id=? WHERE token_hash=?').bind(b.id,await digest(sessionToken(req))),
 env.DB.prepare('INSERT INTO audit_events VALUES(?,?,?,?,?,?)').bind(crypto.randomUUID(),u.sessionOwner,'profile.switch',b.id,'Admin berpindah profil',new Date().toISOString())
 ]);
 return Response.json({});
}
