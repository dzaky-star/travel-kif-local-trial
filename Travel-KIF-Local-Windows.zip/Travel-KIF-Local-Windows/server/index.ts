import {emailAdmin,deliverMentionEmails} from './email';
import {approvalParticipantSQL} from './approval-scope';
import {dashboard} from './dashboard';
import {aiTransportError} from './ai-error';
import {withAI,cancelAI} from './ai-access';
import {itineraryAI} from './itinerary-ai';
import {travelSearch} from './travel-search';
import {loginRoute,switchProfile} from "./login";
import {costApprovalRoute,approvalEventLabels} from './cost-approval';
import { ensureDailyFx, wibDay } from './daily-fx';
import { z } from "zod";
import {
  authenticate,
  body,
  csrf,
  fail,
  HttpError,
  local,
  requireRoles,
  canEdit,
  type Env,
} from "./auth";
import { duplicateQuote, deleteQuote, saveQuote, getQuote, getQuoteVersion, backup, backupSQL, audit, now } from "./store";
import { calculate } from "../shared/calculate";
import { QuoteInput, Policy, Fx, Line, roles, newLine } from "../shared/model";
import { applyImport, previewImport, csv, saveCatalogEntry } from "./catalog";
import {
  integrationStatus,
  sync,
  setupSheets,
  readSheet,
  normalizeRow,
} from "./integrations";
import { customerDocument, generatePdf } from "./documents";
const json = (b: any, status = 200) => Response.json(b, { status });
async function route(req: Request, env: Env, ctx?: ExecutionContext) {
  const url = new URL(req.url),
    path = url.pathname,
    method = req.method;
  if (!path.startsWith("/api/")) return env.ASSETS.fetch(req);
  csrf(req);
  if (["/api/login","/api/logout"].includes(path)) return loginRoute(req,env);
  if(path==="/api/switch-profile")return switchProfile(req,env);
  const u = await authenticate(req, env);
  if(path==="/api/dashboard"&&method==="GET")return json(await dashboard(env,u,url.searchParams));
  if(path==="/api/email-settings")return json(await emailAdmin(env,u,method,method==='PUT'?await body(req):{}));
  if(path.startsWith("/api/cost-approvals")) {const result:any=await costApprovalRoute(env,u,path,method,method==="GET"?{}:await body(req));if(result?.emailQueued)ctx?.waitUntil(deliverMentionEmails(env));return json(result);}
  if (path === "/api/me")
    return json({
      user: u,
      local: local(req, env),
      integrations: integrationStatus(env),
    });
  if (path === "/api/users") {
    if (method === "GET") {
      const all = (
        await env.DB.prepare(
          "SELECT u.id,u.name,u.email,u.roles,u.active,u.can_edit,c.username FROM users u LEFT JOIN login_credentials c ON c.user_id=u.id",
        ).all()
      ).results;
      return json(all.map((r: any) => ({ ...r, roles: JSON.parse(r.roles) })));
    }
    requireRoles(u, "Admin");
    const b = z
      .object({
        id: z.string(),
        email: z.string().email(),
        name: z.string().min(1),
        roles: z.array(z.enum(roles)).min(1),
        active: z.boolean(),
        can_edit: z.boolean(),
      })
      .parse(await body(req));
    if (b.id === u.id && (!b.active || !b.roles.includes("Admin")))
      fail(400, "Jangan menonaktifkan admin yang sedang digunakan.");
    await env.DB.batch([
      env.DB.prepare(
        "INSERT INTO users VALUES(?,?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET email=excluded.email,name=excluded.name,roles=excluded.roles,active=excluded.active,can_edit=excluded.can_edit",
      ).bind(
        b.id,
        b.email,
        b.name,
        JSON.stringify(b.roles),
        +b.active,
        +b.can_edit,
      ),
      audit(env.DB, u, "user.update", b.id),
    ]);
    return json({ saved: true });
  }
  if (path === "/api/calculate" && method === "POST")
    return json(calculate(QuoteInput.parse(await body(req))));
  if (path === "/api/quotes") {
    if (method === "POST")
      return json(await saveQuote(env, u, await body(req)), 201);
    const rows = (
      await env.DB.prepare(
        "SELECT q.*,r.status,r.input_json,r.result_json,COALESCE(NULLIF(json_extract(r.input_json,'$.ownerName'),''),u.name) AS owner_name,(SELECT COUNT(*) FROM ops_requests o WHERE o.quote_id=q.id AND o.status IN ('Waiting','ApprovalWaiting')) AS waiting_ops,(SELECT o.status FROM ops_requests o WHERE o.quote_id=q.id AND json_extract(o.context,'$.kind')='cost-approval' ORDER BY o.updated_at DESC LIMIT 1) AS approval_status,(SELECT json_extract(o.context,'$.directToManager') FROM ops_requests o WHERE o.quote_id=q.id AND json_extract(o.context,'$.kind')='cost-approval' ORDER BY o.updated_at DESC LIMIT 1) AS direct_to_manager FROM quotations q JOIN revisions r ON r.quote_id=q.id AND r.revision=q.current_revision JOIN users u ON u.id=q.owner_id WHERE NOT EXISTS (SELECT 1 FROM audit_events a WHERE a.entity_id=q.id AND a.action='quote.delete') ORDER BY q.created_at DESC",
      ).all()
    ).results;
    return json(
      rows.map((r: any) => ({
        ...r,
        input: JSON.parse(r.input_json),
        result: JSON.parse(r.result_json),
        input_json: undefined,
        result_json: undefined,
      })),
    );
  }
  const match = path.match(/^\/api\/quotes\/([^/]+)(?:\/(.+))?$/);
  if (match) {
    const id = decodeURIComponent(match[1]),
      action = match[2];
    if (action === "version" && method === "GET") return json(await getQuoteVersion(env.DB,id));
    const record = await getQuote(
      env.DB,
      id,
      url.searchParams.has("revision")
        ? Number(url.searchParams.get("revision"))
        : undefined,
    );
    if (!action) {
      if (method === "DELETE") return json(await deleteQuote(env,u,id));
      if (method === "GET") return json(record);
      if (method === "PUT")
        return json(await saveQuote(env, u, await body(req), id));
    }
    if (action === "promote" && method === "POST") {
      if (!canEdit(u, record.owner_id)) fail(403, "Tidak diizinkan.");
      const b = await body(req);
      const source = record.input.lines.find((l: any) => l.id === b.lineId);
      if (!source)
        fail(404, "Simpan layanan ini di quotation terlebih dahulu.");
      const line = {
        ...source,
        id: "HIST-" + record.id.slice(-36) + "-" + source.id,
        priceStatus: "historical",
        source:
          `Pernah dikutip: ${record.id} revisi ${record.revision}. ${source.source}`.slice(
            0,
            4000,
          ),
      };
      await applyImport(env.DB, u, [line]);
      return json({ saved: true, id: line.id });
    }
    if (action === "revisions")
      return json(
        (
          await env.DB.prepare(
            "SELECT r.revision,r.status,r.created_at,u.name AS actor FROM revisions r JOIN users u ON u.id=r.actor_id WHERE quote_id=? ORDER BY revision DESC",
          )
            .bind(id)
            .all()
        ).results,
      );
    if (action === "duplicate" && method === "POST") {
      return json(await duplicateQuote(env,u,id,(await body(req)).requestId),201);
    }
    if (action === "customer") return json(customerDocument(record));
    if (action === "pdf" || action === "ca.pdf") {
      const internal = action === "ca.pdf";
      const brandAsset = await env.ASSETS.fetch(
        new Request(new URL("/travel-kif-logo.png", req.url)),
      );
      const bytes = await generatePdf(
        record,
        internal,
        brandAsset.ok
          ? new Uint8Array(await brandAsset.arrayBuffer())
          : undefined,
      );
      await env.DB.prepare("INSERT INTO documents VALUES(?,?,?,?,?,?)")
        .bind(
          crypto.randomUUID(),
          id,
          record.revision,
          internal ? "internal" : "customer",
          now(),
          u.id,
        )
        .run();
      return new Response(bytes as any, {
        headers: {
          "Content-Type": "application/pdf",
          "Content-Disposition": `attachment; filename="${id}-v${record.revision}-${internal ? "CA" : "quotation"}.pdf"`,
        },
      });
    }
    if (action === "refresh" && method === "GET") {
      if (record.status !== "Draft")
        fail(409, "Buat revisi Draft dahulu untuk memperbarui snapshot.");
      const latest: any = await env.DB.prepare(
        "SELECT data FROM policies ORDER BY created_at DESC LIMIT 1",
      ).first();
      const fx = (
        await env.DB.prepare(
          "SELECT data FROM fx_rates WHERE id NOT LIKE 'ca-fx-%' ORDER BY created_at",
        ).all()
      ).results.map((r: any) => JSON.parse(r.data));
      const latestFx = Array.from(
        new Map(
          fx.map((f: any) => [f.from + "/" + f.to + "/" + f.kind, f]),
        ).values(),
      );
      const candidate = structuredClone(record.input);
      candidate.policy = JSON.parse(latest.data);
      candidate.fx = latestFx;
      candidate.policyConfirmed = false;
      for (const l of candidate.lines) {
        if (l.catalogId) {
          const cat: any = await env.DB.prepare(
            "SELECT data FROM catalog WHERE id=?",
          )
            .bind(l.catalogId)
            .first();
          if (cat) {
            const fresh = JSON.parse(cat.data);
            Object.assign(l, {
              unitPrice: fresh.unitPrice,
              currency: fresh.currency,
              source: fresh.source,
              priceStatus: fresh.priceStatus,
              recordedAt: fresh.recordedAt,
            });
          }
        }
      }
      return json({
        before: record.result,
        after: calculate(candidate),
        input: candidate,
      });
    }
    if (action === "ops" && method === "POST") {
      if (!canEdit(u, record.owner_id)) fail(403, "Tidak diizinkan.");
      const b = await body(req);
      const rid = crypto.randomUUID();
      const context = {
        trip: record.input.trip,
        route: record.input.destination,
        start: record.input.start,
        end: record.input.end,
        travelers: record.result.travelers,
        passengers: record.input.passengers,
        transport: record.input.lines.filter(
          (l: any) => l.category === "transport",
        ),
        notes: String(b.notes || "").slice(0, 4000),
      };
      await env.DB.batch([
        env.DB.prepare(
          "INSERT INTO ops_requests VALUES(?,?,?,?,?,?,?,?,?)",
        ).bind(
          rid,
          id,
          record.revision,
          u.id,
          b.assignee || null,
          "Waiting",
          JSON.stringify(context),
          null,
          now(),
        ),
        audit(env.DB, u, "ops.request", id),
      ]);
      return json({ id: rid });
    }
  }
  if (path === "/api/catalog") {
    if (method === "GET") {
      const query = url.searchParams.get("q") || "";
      return json(
        (
          await env.DB.prepare(
            "SELECT * FROM catalog WHERE label LIKE ? OR city LIKE ? ORDER BY city,label",
          )
            .bind("%" + query + "%", "%" + query + "%")
            .all()
        ).results.map((r: any) => ({ ...r, data: JSON.parse(r.data) })),
      );
    }
    const b = await body(req);
    return json(await saveCatalogEntry(env.DB, u, b));
  }
  const hist = path.match(/^\/api\/catalog\/([^/]+)\/history$/);
  if (hist)
    return json(
      (
        await env.DB.prepare(
          "SELECT * FROM price_history WHERE catalog_id=? ORDER BY created_at DESC",
        )
          .bind(hist[1])
          .all()
      ).results.map((r: any) => ({ ...r, data: JSON.parse(r.data) })),
    );
  if (path === "/api/import/preview" || path === "/api/import/apply") {
    requireRoles(u, "Admin", "OPS");
    const incoming = await body(req);
    if (!Array.isArray(incoming.rows)) fail(400, "rows harus berupa array.");
    const rows = incoming.rows.map(normalizeRow);
    return json(
      path.endsWith("preview")
        ? await previewImport(env.DB, rows)
        : await applyImport(env.DB, u, rows),
    );
  }
  if (path === "/api/import/sheets") {
    requireRoles(u, "Admin", "OPS");
    return json(await readSheet(env, (await body(req)).tab));
  }
  if (path === "/api/ops")
    return json(
      (
        await env.DB.prepare(
          "SELECT o.*,u.name AS requester FROM ops_requests o JOIN users u ON u.id=o.requester_id WHERE COALESCE(json_extract(o.context,'$.kind'),'')!='cost-approval' ORDER BY o.updated_at DESC",
        ).all()
      ).results.map((r: any) => ({
        ...r,
        context: JSON.parse(r.context),
        response: r.response ? JSON.parse(r.response) : null,
      })),
    );
  const ops = path.match(/^\/api\/ops\/([^/]+)(?:\/(apply))?$/);
  if (ops && method === "POST") {
    const row: any = await env.DB.prepare(
      "SELECT * FROM ops_requests WHERE id=?",
    )
      .bind(ops[1])
      .first();
    if (!row) fail(404, "Permintaan tidak ditemukan.");
    const b = await body(req);
    if (JSON.parse(row.context).kind === 'cost-approval') fail(400,'Gunakan alur persetujuan itinerary & CA.');
    if (ops[2] === "apply") {
      const q = await getQuote(env.DB, row.quote_id);
      if (!canEdit(u, q.owner_id)) fail(403, "Tidak diizinkan.");
      if (q.status !== "Draft")
        fail(
          409,
          "Quotation terkirim tidak diubah. Simpan revisi Draft terlebih dahulu.",
        );
      if (!row.response) fail(400, "OPS belum menjawab.");
      const line = JSON.parse(row.response);
      const replace = b.replaceLineId;
      if (replace && !q.input.lines.some((l: any) => l.id === replace))
        fail(400, "Layanan pengganti tidak ditemukan.");
      q.input.lines = replace
        ? q.input.lines.map((l: any) =>
            l.id === replace ? { ...line, id: replace } : l,
          )
        : [...q.input.lines, { ...line, id: crypto.randomUUID() }];
      const saved = await saveQuote(
          env,
          u,
          {
            input: q.input,
            status: "Draft",
            expectedRevision: b.expectedRevision,
            requestId: b.requestId,
          },
          q.id,
        );
      await env.DB.prepare("UPDATE ops_requests SET status='Completed',updated_at=? WHERE id=?").bind(now(), row.id).run();
      return json(saved);
    }
    requireRoles(u, "OPS", "Admin");
    if (row.status === "Completed") fail(409, "Jawaban sudah dipakai. Buat permintaan baru untuk perubahan harga.");
    const answer = Line.parse(b.line);
    if (answer.unitPrice === null || !answer.supplier)
      fail(422, "Supplier dan harga wajib diisi.");
    await env.DB.batch([
      env.DB.prepare(
        "UPDATE ops_requests SET status='Answered',assignee_id=?,response=?,updated_at=? WHERE id=?",
      ).bind(u.id, JSON.stringify(answer), now(), ops[1]),
      env.DB.prepare("INSERT INTO notifications VALUES(?,?,?,?,?,?)").bind(
        crypto.randomUUID(),
        row.requester_id,
        row.quote_id,
        "Jawaban harga OPS tersedia",
        null,
        now(),
      ),
      audit(env.DB, u, "ops.answer", ops[1]),
    ]);
    return json({ saved: true });
  }
  if(path==="/api/notifications/clear" && method==="POST"){
    await env.DB.prepare("UPDATE notifications SET read_at=? WHERE user_id=? AND read_at IS NULL").bind(now(),u.id).run();
    return json({cleared:true});
  }
  if(path==="/api/notifications" && method==="GET"){
    const rows=(await env.DB.prepare(`SELECT n.*,
 (SELECT e.value FROM ops_requests o,json_each(o.response) e WHERE o.quote_id=n.quote_id AND json_extract(o.context,'$.kind')='cost-approval' AND json_extract(e.value,'$.time')=n.created_at ORDER BY o.updated_at DESC LIMIT 1) event_json,
 (SELECT json_extract(r.input_json,'$.trip') FROM quotations q JOIN revisions r ON r.quote_id=q.id AND r.revision=q.current_revision WHERE q.id=n.quote_id) quotation_title
 FROM notifications n WHERE n.user_id=? AND n.read_at IS NULL AND NOT EXISTS(SELECT 1 FROM audit_events a WHERE a.entity_id=n.quote_id AND a.action='quote.delete') AND (n.message LIKE 'Menyebut Anda · %' OR NOT EXISTS(SELECT 1 FROM ops_requests o WHERE o.quote_id=n.quote_id AND json_extract(o.context,'$.kind')='cost-approval') OR EXISTS(SELECT 1 FROM quotations q JOIN ops_requests o ON o.quote_id=q.id WHERE q.id=n.quote_id AND json_extract(o.context,'$.kind')='cost-approval' AND ${approvalParticipantSQL('q.owner_id','o.context','o.response')})) ORDER BY n.created_at DESC LIMIT 100`).bind(u.id,u.id,u.id,u.id,u.id).all()).results as any[];
    return json(rows.map(({event_json,quotation_title,...note})=>{
      if(!event_json)return note;
      const event=JSON.parse(event_json),mentioned=event.mentions?.some((m:any)=>m.userId===u.id)||false;
      const expected=`${mentioned?'Menyebut Anda · ':''}${quotation_title} · ${event.actor}: ${approvalEventLabels[event.action]}${event.message?' — '+event.message:''}`;
      if(!approvalEventLabels[event.action]||note.message!==expected)return note;
      return {...note,uiEvent:{action:event.action,actor:event.actor,quotation:quotation_title,message:event.message||'',mentioned}};
    }));
  }
  if (path === "/api/fx/tick" && method === "POST") {
    const b = await body(req);
    if (b.ecbXml) {
      requireRoles(u, "Admin");
      if (!local(req, env)) fail(403, "Local development only");
      if (typeof b.ecbXml !== "string" || b.ecbXml.length > 20000) fail(400, "Invalid feed");
      await env.DB.prepare("DELETE FROM integration_locks WHERE id='fx-fetch'").run();
      return json(await ensureDailyFx(env, new Date(), (async () => new Response(b.ecbXml)) as typeof fetch));
    }
    return json(await ensureDailyFx(env));
  }
  if (path === "/api/settings") {
    const dailyFx = await ensureDailyFx(env);
    const policies = (
      await env.DB.prepare(
        "SELECT * FROM policies ORDER BY created_at DESC",
      ).all()
    ).results.map((r: any) => JSON.parse(r.data));
    const fx = (
      await env.DB.prepare(
        "SELECT f.*,u.name AS updated_by FROM fx_rates f LEFT JOIN users u ON u.id=f.actor_id WHERE f.id NOT LIKE 'ca-fx-%' ORDER BY f.created_at DESC",
      ).all()
    ).results.map((r: any) => ({...JSON.parse(r.data),updatedBy:r.updated_by}));
    return json({ policies, fx, dailyFx });
  }
  if (path === "/api/policies" && method === "POST") {
    requireRoles(u, "Admin");
    const p = Policy.parse({ ...(await body(req)), id: crypto.randomUUID() });
    await env.DB.batch([
      env.DB.prepare("INSERT INTO policies VALUES(?,?,?,?)").bind(
        p.id,
        JSON.stringify(p),
        now(),
        u.id,
      ),
      audit(env.DB, u, "policy.create", p.id),
    ]);
    return json(p);
  }
  if (path === "/api/fx" && method === "POST") {
    requireRoles(u, "Finance", "Admin");
    const f = Fx.parse({
      ...(await body(req)),
      id: crypto.randomUUID(),
      recordedAt: now(),
      origin: "manual",
      effectiveDate: wibDay(),
    });
    if (
      !/^\d{4}-\d{2}-\d{2}$/.test(f.validFrom) ||
      f.validTo < f.validFrom ||
      f.from === f.to
    )
      fail(422, "Arah atau tanggal kurs tidak valid.");
    await env.DB.batch([
      env.DB.prepare("INSERT INTO fx_rates VALUES(?,?,?,?)").bind(
        f.id,
        JSON.stringify(f),
        now(),
        u.id,
      ),
      audit(env.DB, u, "fx.create", f.id),
    ]);
    return json(f);
  }
  if (path === "/api/integrations") {
    requireRoles(u, "Admin", "Finance");
    return json({
      status: integrationStatus(env),
      jobs: (
        await env.DB.prepare(
          "SELECT * FROM sync_jobs ORDER BY updated_at DESC LIMIT 100",
        ).all()
      ).results,
      audit: (
        await env.DB.prepare(
          "SELECT * FROM audit_events ORDER BY created_at DESC LIMIT 100",
        ).all()
      ).results,
    });
  }
  if (path === "/api/sync/tick" && method === "POST") {
    await ensureDailyFx(env);
    if (!integrationStatus(env).sheets) return json({ state: "disconnected" });
    const clock = await env.DB.prepare(
      "INSERT INTO integration_locks VALUES('sheets-clock','tick',?) ON CONFLICT(id) DO UPDATE SET expires_at=excluded.expires_at WHERE integration_locks.expires_at<? RETURNING token",
    ).bind(new Date(Date.now() + 15000).toISOString(), now()).first();
    if (!clock) return json({ state: "waiting" });
    return json(await sync(env));
  }
  if (path === "/api/sync" && method === "POST") {
    requireRoles(u, "Admin");
    await env.DB.prepare("UPDATE sync_jobs SET state='pending',next_attempt=?")
      .bind(now())
      .run();
    return json(await sync(env));
  }
  if (path === "/api/sheets/setup" && method === "POST") {
    requireRoles(u, "Admin");
    return json(await setupSheets(env));
  }
  if (path === "/api/backup") {
    requireRoles(u, "Admin");
    const b = await backup(env.DB),
      format = url.searchParams.get("format");
    if (format === "sql")
      return new Response(backupSQL(b), {
        headers: {
          "Content-Type": "application/sql",
          "Content-Disposition": `attachment; filename="kif-${now().slice(0, 10)}.sql"`,
        },
      });
    if (format === "csv") {
      const rows: any[] = Object.entries(b.tables).flatMap(([table, records]) =>
        records.map((record) => [table, JSON.stringify(record)]),
      );
      return new Response(csv([["Table", "Record_JSON"], ...rows]), {
        headers: {
          "Content-Type": "text/csv",
          "Content-Disposition": 'attachment; filename="kif-full-backup.csv"',
        },
      });
    }
    return new Response(JSON.stringify(b, null, 2), {
      headers: {
        "Content-Type": "application/json",
        "Content-Disposition": `attachment; filename="kif-${now().slice(0, 10)}.json"`,
      },
    });
  }
  if(path==='/api/ai/cancel'&&method==='POST'){
    requireRoles(u,'TC','OPS','Finance','Admin');const input=await body(req);return json(await cancelAI(env,u,input.requestId));
  }
  if ((path === '/api/ai/itinerary' || path === '/api/ai') && method === 'POST') {
    requireRoles(u,'TC','OPS','Finance','Admin');
    const input=await body(req);
    try {
      return json(await withAI<unknown>(env,u,signal=>{const cancellable:typeof fetch=(url,init)=>{signal.throwIfAborted();return fetch(url,{...init,signal:AbortSignal.any([signal,...(init?.signal?[init.signal]:[])])});};return path === '/api/ai/itinerary'?itineraryAI(env,u,input,cancellable):travelSearch(env,u,input.prompt,cancellable);},input.requestId));
    } catch(error) {
      const transport=aiTransportError(error);
      if(!transport)throw error;
      const requestId=crypto.randomUUID();
      console.warn(JSON.stringify({event:'ai.transport.failure',requestId,code:transport.code,status:transport.status}));
      return json({error:transport.error+' Kode penelusuran: '+requestId,code:transport.code,requestId},transport.status);
    }
  }
  return fail(404, "Endpoint tidak ditemukan.");
}
export default {
  async fetch(req: Request, env: Env, ctx?: ExecutionContext) {
    try {
      const response = await route(req, env, ctx);
      const headers = new Headers(response.headers);
      headers.set("X-Content-Type-Options", "nosniff");
      headers.set("Referrer-Policy", "same-origin");
      headers.set("X-Frame-Options", "DENY");
      headers.set(
        "Content-Security-Policy",
        "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; connect-src 'self'; frame-src 'self'; object-src 'none'; base-uri 'self'; frame-ancestors 'none'",
      );
      if (new URL(req.url).pathname.startsWith("/api/"))
        headers.set("Cache-Control", "no-store");
      return new Response(response.body, { status: response.status, headers });
    } catch (e) {
      if (/exceeded.*(?:daily|row|read|write|free tier)|D1.*(?:quota|limit)/i.test(String((e as Error).message))) return json({error:"Kuota database harian habis. Akses tersedia kembali setelah reset pukul 07.00 WIB.",code:"DATABASE_DAILY_LIMIT"},503);
      const status =
        e instanceof HttpError ? e.status : e instanceof z.ZodError ? 422 : 500;
      return json(
        {
          error:
            e instanceof z.ZodError
              ? e.issues
                  .map((x) => x.path.join(".") + ": " + x.message)
                  .join("; ")
              : status === 500
                ? "Terjadi kesalahan server. Data belum dipastikan tersimpan."
                : (e as Error).message,
        },
        status,
      );
    }
  },
  async scheduled(_event: ScheduledEvent, env: Env, ctx: ExecutionContext) {
    ctx.waitUntil(deliverMentionEmails(env));
    ctx.waitUntil(ensureDailyFx(env).then(() => sync(env)));
  },
};
