// Read-side scope for the personal approval inbox. Quote workspace visibility stays unchanged.
export const approvalParticipantSQL=(owner:string,context:string,response:string,admin=false)=>`(${admin?1:0}=1 OR ${owner}=? OR json_extract(${context},'$.opsReviewerId')=? OR json_extract(${context},'$.managerReviewerId')=? OR EXISTS(SELECT 1 FROM json_each(COALESCE(${response},'[]')) pe WHERE json_extract(pe.value,'$.actorId')=? AND json_extract(pe.value,'$.action') IN ('approve','managerApprove','return','managerReturn','reject','managerReject')))`;
export function approvalArchived(row:any,clock=Date.now()){
 const context=typeof row.context==='string'?JSON.parse(row.context):row.context||{};
 if(context.archived)return true;
 if(row.status!=='ManagerApproved'||context.archiveRestoredAt)return false;
 const events=JSON.parse(row.response||'[]');const final=[...events].reverse().find((e:any)=>e.action==='managerApprove');
 return !!final&&Number.isFinite(Date.parse(final.time))&&clock-Date.parse(final.time)>=20*86400000;
}
