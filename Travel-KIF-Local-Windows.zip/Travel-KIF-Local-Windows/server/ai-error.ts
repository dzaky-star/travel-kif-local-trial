/** Transport failures are distinct from provider HTTP errors and schema failures. */
export function aiTransportError(error:unknown){
 const name=error instanceof Error?error.name:'';
 if(name==='TimeoutError')return {status:504,code:'AI_TIMEOUT',error:'Proses AI melewati batas waktu. Draft sebelumnya tidak diubah. Silakan coba lagi.'};
 if(name==='AbortError')return {status:499,code:'AI_CANCELLED',error:'Proses AI dibatalkan. Draft sebelumnya tidak diubah.'};
 if(error instanceof TypeError&&/fetch failed|network|failed to fetch/i.test(error.message))return {status:502,code:'AI_NETWORK',error:'Koneksi ke layanan AI terputus. Draft sebelumnya tidak diubah. Silakan coba lagi.'};
 return undefined;
}
