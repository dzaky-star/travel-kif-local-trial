import Decimal from 'decimal.js';
import type { Env } from './auth';
export const ECB_URL = 'https://www.ecb.europa.eu/stats/eurofxref/eurofxref-daily.xml';
export const wibDay = (date = new Date()) => new Date(date.getTime() + 7 * 3600000).toISOString().slice(0, 10);
export function parseECB(xml: string) {
  const date = xml.match(/time=['"](\d{4}-\d{2}-\d{2})['"]/)?.[1];
  const rates: Record<string, number> = { EUR: 1 };
  for (const m of xml.matchAll(/currency=['"]([A-Z]{3})['"]\s+rate=['"]([\d.]+)['"]/g)) rates[m[1]] = Number(m[2]);
  if (!date || ['IDR','USD','GBP','CHF'].some(c => !Number.isFinite(rates[c]) || rates[c] <= 0)) throw Error('Data ECB tidak lengkap');
  return { date, rates };
}
export async function ensureDailyFx(env: Env, date = new Date(), fetcher: typeof fetch = fetch) {
  const day = wibDay(date), timestamp = date.toISOString(), key = `fx-day:${day}`;
  if (await env.DB.prepare('SELECT id FROM integration_locks WHERE id=?').bind(key).first()) return { state: 'ready', day };
  const token = crypto.randomUUID();
  const lock = await env.DB.prepare("INSERT INTO integration_locks VALUES('fx-fetch',?,?) ON CONFLICT(id) DO UPDATE SET token=excluded.token,expires_at=excluded.expires_at WHERE integration_locks.expires_at<? RETURNING token").bind(token,new Date(date.getTime()+60000).toISOString(),timestamp).first();
  if (!lock) return {state:'waiting',day};
  try {
    let source: ReturnType<typeof parseECB>;
    let fallback = false;
    try {
      const r = await fetcher(ECB_URL, {signal: AbortSignal.timeout(15000)});
      if (!r.ok) throw Error(`ECB HTTP ${r.status}`);
      source = parseECB(await r.text());
      if (source.date > day) throw Error('Tanggal sumber di masa depan');
    } catch (error) {
      console.warn("ECB fetch failed", String(error));
      const previous: any = await env.DB.prepare("SELECT data FROM fx_rates WHERE id LIKE 'daily-%' AND json_extract(data,'$.from')='EUR' ORDER BY created_at DESC LIMIT 4").all();
      const rows = previous.results.map((r: any)=>JSON.parse(r.data));
      if (rows.length !== 4 || new Set(rows.map((r:any)=>r.sourceDate)).size !== 1) return {state:'unavailable',day,message:'ECB belum tersedia; kurs terakhir tetap digunakan. Sistem mencoba ulang.'};
      source = {date:rows[0].sourceDate,rates:{EUR:1,...Object.fromEntries(rows.map((r:any)=>[r.to,r.rate]))}};
      fallback = true;
    }
    const effective = new Date(`${day}T00:00:00+07:00`).toISOString();
    const currencies = ['EUR','IDR','USD','GBP','CHF'];
    const statements = [env.DB.prepare("INSERT OR IGNORE INTO users VALUES('fx-automation','fx-automation@internal.invalid','Kurs otomatis','[]',0,0)")];
    for (const from of currencies) for (const to of currencies) if (from !== to) {
      const fx = {id:`daily-${day}-${from}-${to}`,from,to,rate:new Decimal(source.rates[to]).div(source.rates[from]).toSignificantDigits(15).toNumber(),source:`ECB referensi ${source.date}; tanpa buffer${fallback ? '; sumber tidak tersedia, memakai publikasi tersimpan' : ''}. ${ECB_URL}`,recordedAt:timestamp,validFrom:day,validTo:day,kind:'working',sourceDate:source.date,effectiveDate:day,origin:'automatic'};
      statements.push(env.DB.prepare('INSERT OR IGNORE INTO fx_rates VALUES(?,?,?,?)').bind(fx.id,JSON.stringify(fx),effective,'fx-automation'));
    }
    statements.push(env.DB.prepare("INSERT OR IGNORE INTO integration_locks VALUES(?,?,'9999-12-31T00:00:00Z')").bind(key,source.date));
    await env.DB.batch(statements);
    return {state:'ready',day,sourceDate:source.date,fallback};
  } finally {
    // Keep the short lease to throttle failures; successful days are immutable.
  }
}
