/** Bounded concurrent search with stable result order and short-lived per-user reuse. */
export async function mapConcurrent<T,R>(items:T[],limit:number,run:(item:T)=>Promise<R>):Promise<R[]>{
 const results:R[]=new Array(items.length);let next=0;
 await Promise.all(Array.from({length:Math.min(limit,items.length)},async()=>{for(;;){const i=next++;if(i>=items.length)return;results[i]=await run(items[i]);}}));
 return results;
}
const cache=new Map<string,{expires:number;value:any[]}>();
export async function cachedSearch(user:string,query:string,run:()=>Promise<any[]>,now=Date.now()){
 const key=JSON.stringify([user,query.trim().toLowerCase()]);
 const hit=cache.get(key);if(hit&&hit.expires>now)return hit.value;
 const value=await run();
 for(const [k,v] of cache)if(v.expires<=now)cache.delete(k);
 if(cache.size>=150)cache.delete(cache.keys().next().value!);
 cache.set(key,{expires:now+15*60*1000,value});return value;
}
