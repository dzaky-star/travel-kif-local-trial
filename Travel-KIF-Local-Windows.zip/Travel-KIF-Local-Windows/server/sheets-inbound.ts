import { QuoteInput } from '../shared/model';
import { calculate } from '../shared/calculate';
import { getQuote, saveQuote } from './store';
import type { Env } from './auth';
// Three-way merge: spreadsheet revision is the base, D1 is current.
// Derived totals stay computed. Editing Total explicitly sets a group price.
export function mergeSheetRow(tab:string, row:any[], base:any, next:any, status:{value:string}, baseStatus:string, result:any, currentResult?:any) {
  const same=(a:any,b:any)=>String(a??'')===String(b??'');
  function field(index:number,obj:any,old:any,key:string,type='text'){
    const raw=row[index]??''; let value:any=raw;
    if(type==='number'&&key==='unitPrice'&&raw===''){value=null;}
    else if(type==='number'){if(raw===''||!Number.isFinite(Number(raw)))throw Error(`${tab}: nilai angka tidak valid`);value=Number(raw);}
    if(type==='bool'){if(!['true','false'].includes(String(raw).toLowerCase()))throw Error(`${tab}: FOC harus TRUE/FALSE`);value=String(raw).toLowerCase()==='true';}
    if(same(value,old[key]))return;
    if(!same(obj[key],old[key])&&!same(obj[key],value))throw Error(`${tab}: konflik ${key}; data D1 dan Sheet sama-sama berubah`);
    obj[key]=value;
  }
  if(tab==='Quote_Summaries'){
    field(3,status,{value:baseStatus},'value');field(4,next,base,'customer');field(5,next,base,'trip');field(6,next,base,'sellCurrency');
    const samePrice=(a:any,b:any)=>a!=null&&b!=null&&a!==''&&b!==''&&Number.isFinite(Number(a))&&Number.isFinite(Number(b))&&Math.round(Number(a)*100)===Math.round(Number(b)*100);
    // Compare the exported FINAL totals, never raw overrides against rounded totals.
    // An untouched Sheet must not overwrite a newer website revision.
    const currentTotal=(currentResult??calculate(next)).grandTotal;
    // A blank exported total cannot distinguish a Sheet edit from a stale cell skipped by older exports.
    if(!(result.grandTotal==null&&currentTotal==null)&&!samePrice(row[7],result.grandTotal)&&!same(row[7],result.grandTotal)){
      if(row[7]===''||!Number.isFinite(Number(row[7]))||Number(row[7])<0)throw Error('Total tidak valid');
      if(!samePrice(currentTotal,row[7])){
        if(!samePrice(currentTotal,result.grandTotal))throw Error(`Konflik harga jual quotation ${row[0]}: harga awal ${result.grandTotal}, website ${currentTotal}, Google Sheet ${row[7]}. Samakan total di Google Sheet dengan harga website untuk memakai versi website; untuk memakai harga Sheet, masukkan harga tersebut melalui editor website lalu sinkronkan ulang.`);
        if(next.lines.some((l:any)=>l.addon&&l.included))throw Error('Edit total dengan add-on melalui website');
        next.pricing.basis='group';next.pricing.overrides.group=Number(row[7]);next.pricing.discount=0;
        // Sheet Total is an explicit final amount, not an unrounded suggestion.
        next.pricing.finalRounding=undefined;
      }
    }
    if(row.length>12)field(12,next,base,'ownerName');
  }else{
    const collection=tab==='Quote_Lines'?'lines':tab==='Passengers'?'passengers':'itinerary';
    const old=base[collection].find((x:any)=>x.id===row[3]),obj=next[collection].find((x:any)=>x.id===row[3]);
    if(!old)throw Error(`${tab}: ID baris tidak dikenal`);
    const mapping:any=tab==='Quote_Lines'?[[4,'label'],[5,'side'],[6,'currency'],[7,'unitPrice','number'],[8,'quantity','number'],[9,'factor','number'],[10,'basis'],[11,'source']]:tab==='Passengers'?[[4,'name'],[5,'category'],[6,'role'],[7,'foc','bool']]:[[4,'date'],[5,'city'],[6,'title'],[7,'description']];
    if(!obj){
      for(const [index,key,type] of mapping){
        const raw=row[index]??'';
        const value=type==='bool'?String(raw).toLowerCase()==='true':type==='number'?(key==='unitPrice'&&raw===''?null:Number(raw)):raw;
        if(!same(value,old[key]))throw Error(`${tab}: baris dihapus di website tetapi diubah di Sheet`);
      }
      return;
    }
    for(const [index,key,type] of mapping)field(index,obj,old,key,type);
  }
}
export async function importSheetChanges(env:Env,tables:Record<string,any[][]>){
  const plans=new Map<string,any>(), bases=new Map<string,any>();const seen=new Set<string>();
  for(const tab of ['Quote_Summaries','Quote_Lines','Passengers','Itinerary']){
    for(const row of (tables[tab]||[]).slice(1)){
      if(!row[0])continue;
      const id=String(row[0]),rev=Number(row[1]),key=id+':'+rev;
      if(!Number.isInteger(rev)||rev<1)throw Error('Revision Sheet tidak valid');
      const unique=tab+':'+key+':'+(tab==='Quote_Summaries'?'':row[3]);if(seen.has(unique))throw Error('Baris Sheet duplikat');seen.add(unique);
      let base=bases.get(key);if(!base){base=await getQuote(env.DB,id,rev);bases.set(key,base);}
      let p=plans.get(id);if(!p){const current=await getQuote(env.DB,id);p={current,input:structuredClone(current.input),status:{value:current.status}};plans.set(id,p);}
      mergeSheetRow(tab,row,base.input,p.input,p.status,base.status,base.result,p.current.result);
    }
  }
  const changed=[...plans.values()].filter(p=>JSON.stringify(p.current.input)!==JSON.stringify(p.input)||p.status.value!==p.current.status);
  for(const p of changed){p.input=QuoteInput.parse(p.input);const c=calculate(p.input);if(p.status.value!=='Draft'&&!c.complete)throw Error(c.errors.join(' '));}
  if(changed.length)await env.DB.prepare("INSERT OR IGNORE INTO users VALUES('sheets-sync','sheets-sync@internal.invalid','Google Sheets','[\"Admin\"]',0,0)").run();
  for(const p of changed)await saveQuote(env,{id:'sheets-sync',email:'sheets-sync@internal.invalid',name:'Google Sheets',roles:['Admin'],can_edit:0},{input:p.input,status:p.status.value,expectedRevision:p.current.current_revision,requestId:crypto.randomUUID()},p.current.id);
  return changed.length;
}
