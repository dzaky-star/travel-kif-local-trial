import {type Env} from './auth';
// Bound recovery attempts; never retry authentication, invalid input, or quota errors.
export async function geminiFetch(env:Env,init:RequestInit,fetcher:typeof fetch=fetch,wait=(ms:number)=>new Promise<void>(resolve=>setTimeout(resolve,ms))){
 const primary=env.GEMINI_MODEL||'gemini-3.1-flash-lite';
 const fallback=env.GEMINI_FALLBACK_MODEL;
 const models=[primary,primary,...(fallback&&fallback!==primary?[fallback]:[])];
 let response:Response|undefined;
 for(let i=0;i<models.length;i++){
  if(init.signal?.aborted)throw init.signal.reason;
  if(i)await wait(1000*i);
  if(init.signal?.aborted)throw init.signal.reason;
  try{
   response=await fetcher(`https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(models[i])}:generateContent`,{...init,signal:init.signal||AbortSignal.timeout(25000)});
   if(![500,502,503,504].includes(response.status)||i===models.length-1)return response;
   await response.body?.cancel();
  }catch(error){if(init.signal?.aborted||i===models.length-1)throw error;}
 }
 return response!;
}
