import { z } from "zod";
import { Line, type CostLine } from "../shared/model";
import { fail, requireRoles, type User } from "./auth";
import { audit, now } from "./store";
export const ImportRow = Line.extend({ id: z.string().min(1).max(100) });
export async function previewImport(db: D1Database, rows: unknown[]) {
  if (!Array.isArray(rows) || rows.length > 1000)
    fail(400, "Import maksimal 1.000 baris.");
  const existingRows = (await db.prepare("SELECT id,data FROM catalog").all())
    .results;
  const existingMap = new Map(existingRows.map((r: any) => [r.id, r]));
  const seen = new Set<string>();
  const result = [];
  for (let i = 0; i < rows.length; i++) {
    const parsed = ImportRow.safeParse(rows[i]);
    if (!parsed.success) {
      result.push({
        row: i + 1,
        state: "error",
        message: parsed.error.issues
          .map((x) => x.path.join(".") + ": " + x.message)
          .join("; "),
      });
      continue;
    }
    const r = parsed.data;
    if (seen.has(r.id)) {
      result.push({
        row: i + 1,
        state: "duplicate",
        message: `ID ${r.id} duplikat dalam file.`,
      });
      continue;
    }
    seen.add(r.id);
    const existing: any = existingMap.get(r.id);
    const same =
      existing &&
      JSON.stringify(JSON.parse(existing.data)) === JSON.stringify(r);
    result.push({
      row: i + 1,
      state: same ? "unchanged" : existing ? "changed" : "new",
      data: r,
    });
  }
  return result;
}
export async function applyImport(db: D1Database, u: User, rows: unknown[]) {
  const preview = await previewImport(db, rows);
  if (preview.some((x) => ["error", "duplicate"].includes(x.state)))
    fail(422, "Perbaiki baris error/duplikat sebelum menerapkan.");
  const changed = preview
    .filter((x) => x.state !== "unchanged" && x.data)
    .map((x) => x.data!);
  const statements = [];
  if (changed.length) {
    const data = JSON.stringify(changed),
      time = now();
    statements.push(
      db
        .prepare(
          "INSERT INTO catalog SELECT json_extract(value,'$.id'),json_extract(value,'$.label'),json_extract(value,'$.category'),json_extract(value,'$.city'),value,? FROM json_each(?) WHERE true ON CONFLICT(id) DO UPDATE SET label=excluded.label,category=excluded.category,city=excluded.city,data=excluded.data,updated_at=excluded.updated_at",
        )
        .bind(time, data),
    );
    const history = changed.map((r) => ({
      id: crypto.randomUUID(),
      catalog: r.id,
      data: r,
    }));
    statements.push(
      db
        .prepare(
          "INSERT INTO price_history SELECT json_extract(value,'$.id'),json_extract(value,'$.catalog'),json_extract(value,'$.data'),?,? FROM json_each(?)",
        )
        .bind(time, u.id, JSON.stringify(history)),
    );
    statements.push(
      db
        .prepare(
          "INSERT OR IGNORE INTO suppliers SELECT lower(hex(randomblob(16))),json_extract(value,'$.supplier') FROM json_each(?) WHERE json_extract(value,'$.supplier')!=''",
        )
        .bind(data),
    );
  }
  statements.push(
    audit(db, u, "catalog.import", "catalog", `${rows.length} rows`),
  );
  await db.batch(statements);
  return preview;
}
export function csvSafe(v: unknown) {
  const value = String(v ?? "");
  return (
    '"' +
    (/^[\s]*[=+@-]/.test(value) ? "'" + value : value).replaceAll('"', '""') +
    '"'
  );
}
export function csv(rows: unknown[][]) {
  return rows.map((r) => r.map(csvSafe).join(",")).join("\r\n");
}

export async function saveCatalogEntry(db:D1Database,u:User,data:unknown){
 requireRoles(u,'Admin','OPS','TC','Finance','Director');
 const entry=ImportRow.parse(data);
 if(!u.roles.some(r=>['Admin','OPS'].includes(r))){
  const existing=await db.prepare('SELECT id FROM catalog WHERE id=?').bind(entry.id).first();
  if(!existing)fail(403,'Hanya OPS atau Admin yang dapat menambah layanan.');
 }
 return applyImport(db,u,[entry]);
}
