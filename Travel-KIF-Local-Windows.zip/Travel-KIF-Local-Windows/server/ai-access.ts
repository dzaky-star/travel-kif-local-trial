import {fail,type Env,type User} from './auth';
const requestToken=(id?:string)=>{if(id&&!/^[a-zA-Z0-9-]{16,80}$/.test(id))fail(400,'Request ID AI tidak valid.');return id||crypto.randomUUID();};
export async function cancelAI(env:Env,user:User,requestId?:string){
 const account='ai-user:'+user.id;
 const row=await env.DB.prepare('SELECT token FROM integration_locks WHERE id=?').bind(account).first<{token:string}>();
 const token=requestId?user.id+':'+requestToken(requestId):row?.token;
 if(!token)return {cancelled:true};
 await env.DB.batch([
  env.DB.prepare('INSERT OR REPLACE INTO integration_locks VALUES(?,?,?)').bind('ai-cancel:'+user.id+':'+token,token,new Date(Date.now()+240000).toISOString()),
  env.DB.prepare("DELETE FROM integration_locks WHERE token=? AND id LIKE 'ai-slot:%' AND EXISTS(SELECT 1 FROM integration_locks WHERE id=? AND token=?)").bind(token,account,token),
  env.DB.prepare('DELETE FROM integration_locks WHERE id=? AND token=?').bind(account,token),
 ]);
 return {cancelled:true};
}
/** Bounded shared leases, scoped cancellation, and a finite interaction lifetime. */
export async function withAI<T>(env:Env,user:User,run:(signal:AbortSignal)=>Promise<T>,requestId?:string):Promise<T>{
 if(!env.GEMINI_API_KEY||!env.TAVILY_API_KEY)fail(503,'Gemini dan Tavily belum dikonfigurasi. Hubungi Admin.');
 const configured=Number(env.AI_MAX_CONCURRENT??10);
 const capacity=Number.isInteger(configured)&&configured>=1?Math.min(configured,10):10;
 const token=user.id+':'+requestToken(requestId),now=new Date().toISOString(),expires=new Date(Date.now()+185000).toISOString();
 const cancelled='ai-cancel:'+user.id+':'+token;
 await env.DB.prepare("DELETE FROM integration_locks WHERE id LIKE 'ai-cancel:%' AND expires_at<?").bind(now).run();
 if(await env.DB.prepare('SELECT token FROM integration_locks WHERE id=?').bind(cancelled).first())fail(409,'Permintaan AI dibatalkan.');
 const claim=async(id:string)=>{const row=await env.DB.prepare('INSERT INTO integration_locks(id,token,expires_at) VALUES(?,?,?) ON CONFLICT(id) DO UPDATE SET token=excluded.token,expires_at=excluded.expires_at WHERE integration_locks.expires_at<? RETURNING token').bind(id,token,expires,now).first<{token:string}>();return row?.token===token;};
 const release=(id:string)=>env.DB.prepare('DELETE FROM integration_locks WHERE id=? AND token=?').bind(id,token).run();
 const account='ai-user:'+user.id;
 if(!await claim(account))fail(429,'Permintaan AI Anda masih berjalan. Batalkan permintaan sebelumnya sebelum mengirim lagi.');
 let slot:string|undefined,timer:ReturnType<typeof setInterval>|undefined,deadline:ReturnType<typeof setTimeout>|undefined;
 const controller=new AbortController();let checking=false;
 try{
  for(let i=0;i<capacity;i++){const id='ai-slot:'+i;if(await claim(id)){slot=id;break;}}
  if(!slot)fail(429,`Semua ${capacity} slot AI sedang digunakan. Coba lagi setelah salah satu proses selesai.`);
  const check=async()=>{if(checking)return;checking=true;try{const row=await env.DB.prepare('SELECT token FROM integration_locks WHERE id=?').bind(account).first<{token:string}>();if(row?.token!==token||await env.DB.prepare('SELECT token FROM integration_locks WHERE id=?').bind(cancelled).first())controller.abort(new DOMException('Permintaan AI dibatalkan.','AbortError'));}catch{controller.abort(new Error('Status permintaan AI tidak dapat diperiksa.'));}finally{checking=false;}};
  await check();controller.signal.throwIfAborted();timer=setInterval(check,750);
  deadline=setTimeout(()=>controller.abort(new DOMException('Proses AI melewati batas waktu.','TimeoutError')),180000);
  const stopped=new Promise<never>((_,reject)=>controller.signal.addEventListener('abort',()=>reject(controller.signal.reason),{once:true}));
  return await Promise.race([run(controller.signal),stopped]);
 }finally{
  clearInterval(timer);clearTimeout(deadline);
  try{if(slot)await release(slot);}finally{await release(account);}
 }
}
