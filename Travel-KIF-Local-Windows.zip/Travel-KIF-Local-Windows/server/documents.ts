import { PDFDocument, StandardFonts, rgb } from "pdf-lib";
export function customerDocument(record: any) {
  const q = record.input,
    c = record.result;
  return {
    id: record.id,
    revision: record.revision,
    status: record.status,
    images: q.images ?? [],
    customer: q.customer,
    agent: q.agent,
    trip: q.trip,
    start: q.start,
    end: q.end,
    validUntil: q.validUntil,
    currency: q.sellCurrency,
    participants: {
      traveling: c.travelers,
      paying: c.paying,
      adult: c.counts.adult,
      child: c.counts.child,
      infant: c.counts.infant,
    },
    itinerary: q.itinerary.map((d: any) => ({
      date: d.date,
      city: d.city,
      title: d.title,
      description: d.description,
    })),
    services: q.lines
      .filter((l: any) => !l.addon || l.included)
      .map((l: any) => ({ label: l.label, start: l.start, end: l.end })),
    prices:
      q.pricing.basis === "weighted"
        ? Object.entries(c.prices).map(([category, p]: any) => ({
            category,
            count: p.count,
            price: p.applied,
            subtotal: p.subtotal,
          }))
        : [
            {
              category: q.pricing.basis === "unit" ? "unit" : "grup",
              count: q.pricing.basis === "unit" ? q.pricing.units : 1,
              price:
                c.landRevenue /
                (q.pricing.basis === "unit" ? q.pricing.units : 1),
              subtotal: c.landRevenue,
            },
          ],
    options: q.lines
      .filter((l: any) => l.addon)
      .map((l: any) => ({
        label: l.label,
        included: l.included,
        price: l.selling,
      })),
    landRevenue: c.landRevenue,
    addonRevenue: c.addonRevenue,
    discount: c.discount,
    roundingAdjustment: c.roundingAdjustment ?? 0,
    total: c.grandTotal,
    inclusions: q.inclusions,
    exclusions: q.exclusions,
    terms: q.terms,
  };
}
export async function generatePdf(
  record: any,
  internal = false,
  logoBytes?: Uint8Array,
) {
  const pdf = await PDFDocument.create();
  const regular = await pdf.embedFont(StandardFonts.Helvetica),
    bold = await pdf.embedFont(StandardFonts.HelveticaBold);
  let page = pdf.addPage([595.28, 841.89]),
    y = 786;
  const safe = (s: unknown) =>
    String(s ?? "")
      .normalize("NFKD")
      .replace(/[\u0300-\u036f]/g, "")
      .replace(/→/g, " > ")
      .replace(/[–—]/g, "-")
      .replace(/[^\x20-\x7e\xa0-\xff\n]/g, "?");
  const line = (text: unknown, size = 10, heavy = false) => {
    const font = heavy ? bold : regular;
    for (const paragraph of safe(text).split("\n")) {
      let current = "";
      for (const word of paragraph.split(" ")) {
        if (
          font.widthOfTextAtSize(current + " " + word, size) > 495 &&
          current
        ) {
          draw(current);
          current = word;
        } else current += (current ? " " : "") + word;
      }
      draw(current);
    }
    function draw(s: string) {
      if (y < 60) {
        page = pdf.addPage([595.28, 841.89]);
        y = 785;
      }
      page.drawText(s, { x: 48, y, size, font, color: rgb(0.12, 0.23, 0.31) });
      y -= size + 7;
    }
  };
  const c = customerDocument(record),
    fmt = (n: number | null) =>
      n == null ? "Belum tersedia" : `${c.currency} ${n.toFixed(2)}`;
  if (logoBytes) {
    const logo = await pdf.embedPng(logoBytes);
    const width = 230,
      height = (width * logo.height) / logo.width;
    page.drawImage(logo, { x: 48, y: y - height, width, height });
    y -= height + 25;
  } else line("TRAVEL KIF", 24, true);
  page.drawRectangle({
    x: 48,
    y: y + 10,
    width: 365,
    height: 2,
    color: rgb(60 / 255, 191 / 255, 239 / 255),
  });
  page.drawRectangle({
    x: 413,
    y: y + 10,
    width: 134,
    height: 2,
    color: rgb(234 / 255, 173 / 255, 64 / 255),
  });
  line(internal ? "COST ANALYSIS - INTERNAL" : "QUOTATION", 12, true);
  line(`${c.id} / revisi ${c.revision} / ${c.status}`);
  if (c.status === "Draft") line("DRAFT - BELUM SIAP DIKIRIM", 12, true);
  line(c.trip, 18, true);
  line(`Untuk: ${c.customer}${c.agent ? " / " + c.agent : ""}`);
  line(`Perjalanan: ${c.start} - ${c.end} | Berlaku sampai: ${c.validUntil}`);
  line(
    `Peserta bepergian: ${c.participants.traveling} | Membayar: ${c.participants.paying}`,
  );
  y -= 12;
  for (const picture of c.images) {
    const embedded = await pdf.embedPng(picture.dataUrl);
    const scale = Math.min(495 / embedded.width, 190 / embedded.height, 1);
    const w = embedded.width * scale,
      h = embedded.height * scale;
    if (y - h < 80) {
      page = pdf.addPage([595.28, 841.89]);
      y = 785;
    }
    page.drawImage(embedded, { x: 48, y: y - h, width: w, height: h });
    y -= h + 17;
    line(picture.caption, 10);
    line("Sumber: " + picture.source + " | " + picture.rights, 8);
    y -= 10;
  }
  for (const d of c.itinerary) {
    line(`${d.date} | ${d.city} - ${d.title}`, 11, true);
    line(d.description);
  }
  line("LAYANAN", 12, true);
  for (const s of c.services)
    line(`${s.label} ${s.start ? `(${s.start} - ${s.end})` : ""}`);
  line("HARGA PENAWARAN", 12, true);
  for (const p of c.prices)
    line(`${p.category}: ${p.count} x ${fmt(p.price)} = ${fmt(p.subtotal)}`);
  line(`Land Arrangement Revenue: ${fmt(c.landRevenue)}`);
  line(`Included Add-On Revenue: ${fmt(c.addonRevenue)}`);
  line(`Diskon grup: ${fmt(c.discount)}`);
  line(`Pembulatan: ${fmt(c.roundingAdjustment)}`);
  line(`TOTAL HARGA PENAWARAN: ${fmt(c.total)}`, 14, true);
  for (const o of c.options)
    line(
      `${o.included ? "Termasuk" : "Opsi terpisah (tidak masuk total)"}: ${o.label} - ${o.price === null ? "belum tersedia" : fmt(o.price)}`,
    );
  for (const [title, value] of [
    ["Termasuk", c.inclusions],
    ["Tidak termasuk", c.exclusions],
    ["Syarat perusahaan", c.terms],
  ]) {
    line(title, 11, true);
    line(value || "Belum diisi");
  }
  if (internal) {
    line("INFORMASI INTERNAL - JANGAN KIRIM KE PELANGGAN", 13, true);
    for (const side of ["collective", "individual"]) {
      line(side.toUpperCase(), 12, true);
      for (const l of record.input.lines.filter((x: any) => x.side === side)) {
        line(`${l.label} | ${l.supplier} | ${l.source}`);
        const r = record.result.lines.find((x: any) => x.id === l.id);
        line(
          `${r.formula} = ${record.input.baseCurrency} ${r.total ?? "BELUM DIKETAHUI"}`,
        );
      }
    }
    for (const key of [
      "baseCost",
      "addonCost",
      "totalCostSelling",
      "commission",
      "profitBeforeCommission",
      "profit",
    ])
      line(`${key}: ${record.result[key]}`);
    line(
      `Margin Quotation: ${record.result.margin === null ? "n/a" : (record.result.margin * 100).toFixed(4) + "%"}`,
    );
    line(`Engine ${record.result.engine}; policy ${record.input.policy.id}`);
    for (const f of record.input.fx)
      line(`1 ${f.from} = ${f.rate} ${f.to}; ${f.source}; ${f.id}`);
  }
  const pages = pdf.getPages();
  pages.forEach((p, i) =>
    p.drawText(`Travel KIF | ${i + 1}/${pages.length}`, {
      x: 48,
      y: 30,
      size: 9,
      font: regular,
      color: rgb(0.4, 0.5, 0.57),
    }),
  );
  return pdf.save();
}
