import {approvalParticipantSQL} from './approval-scope';
import {type Env,type User,fail,requireRoles} from './auth';
import {workspaceDay} from '../shared/quotation-status';
// Existing workspace read access is shared by authenticated active team roles.
// Ownership/assignment below only determines actionable work, not new edit permission.
const base=`WITH base AS (
 SELECT q.id,q.owner_id,q.created_at,r.status,
 json_extract(r.input_json,'$.trip') trip,json_extract(r.input_json,'$.customer') customer,
 json_extract(r.input_json,'$.start') start,json_extract(r.input_json,'$.sourceWorkbook') imported,
 json_extract(r.input_json,'$.reviewConfirmed') reviewed,json_extract(r.result_json,'$.travelers') pax,
 json_extract(r.result_json,'$.errors') errors,
 o.status approval,o.context, o.response,COALESCE(json_extract(o.context,'$.archived'),0) archived,
 (SELECT json_extract(e.value,'$.time') FROM json_each(COALESCE(o.response,'[]')) e
 WHERE json_extract(e.value,'$.action') IN ('submit','approve','return','reject','managerReturn','managerReject','managerApprove','cancel','reopen') ORDER BY CAST(e.key AS INTEGER) DESC LIMIT 1) stage_at
 FROM quotations q JOIN revisions r ON r.quote_id=q.id AND r.revision=q.current_revision
 LEFT JOIN ops_requests o ON o.id=(SELECT id FROM ops_requests WHERE quote_id=q.id AND json_extract(context,'$.kind')='cost-approval' ORDER BY updated_at DESC,id DESC LIMIT 1)
 WHERE NOT EXISTS(SELECT 1 FROM audit_events a WHERE a.entity_id=q.id AND a.action='quote.delete')
)`;
const waiting="archived=0 AND approval IN ('ApprovalWaiting','ManagerWaiting','ApprovalApproved')";
export async function dashboard(env:Env,u:User,p:URLSearchParams,clock=new Date()){
 requireRoles(u,'TC','OPS','Finance','Director','Admin');
 const active:any=await env.DB.prepare('SELECT active FROM users WHERE id=?').bind(u.id).first();if(!active?.active)fail(403,'Akun tidak aktif.');
 const period=p.get('period')||workspaceDay(clock).slice(0,7),owner=p.get('owner')||'',widget=p.get('widget')||'overview';
 if(!/^\d{4}-(0[1-9]|1[0-2])$/.test(period))fail(400,'Periode tidak valid.');
 const scoped="(?='' OR owner_id=?)",inPeriod="strftime('%Y-%m',created_at,'+7 hours')=?";
 const all=async(sql:string,args:any[]=[])=> (await env.DB.prepare(base+' '+sql).bind(...args).all()).results as any[];
 const mine=`((approval='ApprovalWaiting' AND ?=1 AND (?=1 OR json_extract(context,'$.opsReviewerId')=?)) OR (approval IN ('ManagerWaiting','ApprovalApproved') AND ?=1 AND (?=1 OR json_extract(context,'$.managerReviewerId')=?)) OR (approval IN ('ApprovalReturned','ManagerReturned') AND owner_id=?))`;
 const admin=0,mineArgs=[+(!!admin||u.roles.includes('OPS')),admin,u.id,+(!!admin||u.roles.includes('Director')),admin,u.id,u.id];
 if(widget==='overview'){
  const rows=await all(`SELECT CASE WHEN status='Cancelled' THEN 'Lost' ELSE status END status,COUNT(*) count FROM base WHERE ${scoped} AND ${inPeriod} GROUP BY 1`,[owner,owner,period]);
  const participant=approvalParticipantSQL('owner_id','context','response',u.roles.includes('Admin'));
  const approvals=await all(`SELECT approval,COUNT(*) count FROM base WHERE ${scoped} AND ${inPeriod} AND ${waiting} AND ${participant} GROUP BY approval`,[owner,owner,period,u.id,u.id,u.id,u.id]);
  const owners=await all('SELECT DISTINCT b.owner_id id,u.name FROM base b JOIN users u ON u.id=b.owner_id ORDER BY u.name');
  const counts=Object.fromEntries(rows.map(r=>[r.status,r.count]));
  return {period,owners,counts,total:rows.reduce((n,r)=>n+r.count,0),ops:approvals.find(r=>r.approval==='ApprovalWaiting')?.count||0,manager:approvals.filter(r=>r.approval!=='ApprovalWaiting').reduce((n,r)=>n+r.count,0),updatedAt:clock.toISOString()};
 }
 if(widget==='tasks')return {items:await all(`SELECT id,trip,approval,stage_at FROM base WHERE archived=0 AND ${mine} ORDER BY stage_at IS NULL,stage_at,id LIMIT 5`,mineArgs)};
 if(widget==='approvals')return {items:await all(`SELECT id,trip,approval,context,stage_at,(SELECT COUNT(*) FROM notifications n WHERE n.quote_id=base.id AND n.user_id=? AND n.read_at IS NULL AND (n.id LIKE 'comment:%' OR n.message LIKE '%: Mengirim komentar%')) unread_comments FROM base WHERE ${scoped} AND ${waiting} AND ${approvalParticipantSQL('owner_id','context','response',u.roles.includes('Admin'))} ORDER BY CASE WHEN ${mine} THEN 0 ELSE 1 END,stage_at IS NULL,stage_at,id LIMIT 5`,[u.id,owner,owner,u.id,u.id,u.id,u.id,...mineArgs])};
 if(widget==='trips'){
  const today=workspaceDay(clock),end=workspaceDay(new Date(clock.getTime()+30*86400000));
  return {today,end,items:await all(`SELECT id,trip,start,pax,status FROM base WHERE ${scoped} AND status='Confirmed' AND start>=? AND start<=? AND length(start)=10 AND strftime('%Y-%m-%d',julianday(start))=start AND imported IS NULL ORDER BY start,id LIMIT 5`,[owner,owner,today,end]),limitation:'Tanggal impor tidak dimasukkan karena belum ada penanda verifikasi jadwal yang terpisah.'};
 }
 if(widget==='issues')return {items:await all(`SELECT id,trip,json_array_length(errors) errorCount FROM base WHERE ${scoped} AND status NOT IN ('Lost','Cancelled') AND json_array_length(errors)>0 ORDER BY created_at DESC,id LIMIT 5`,[owner,owner]),unavailable:(await all(`SELECT COUNT(*) count FROM base WHERE ${scoped} AND errors IS NULL`,[owner,owner]))[0].count};
 if(widget==='activity')return {items:await all(`SELECT b.id,b.trip,u.name actor,a.action,a.created_at time FROM audit_events a JOIN base b ON b.id=a.entity_id LEFT JOIN users u ON u.id=a.actor_id WHERE ${scoped.replaceAll('owner_id','b.owner_id')} AND a.action='quote.save' ORDER BY a.created_at DESC,a.id DESC LIMIT 5`,[owner,owner])};
 fail(400,'Widget tidak tersedia.');
}
