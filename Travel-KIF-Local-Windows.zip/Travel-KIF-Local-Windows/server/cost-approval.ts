import {mentionEmailStatements} from './email';
import {approvalParticipantSQL,approvalArchived} from './approval-scope';
import {z} from 'zod';
import {type Env,type User,fail} from './auth';
import {getQuote,getQuoteVersion,saveQuote,now} from './store';
import {Line,QuoteInput} from '../shared/model';
export const approvalEventLabels:Record<string,string>={submit:'Mengajukan validasi itinerary & CA',cancel:'Membatalkan pengajuan',save:'Memperbarui quotation saat pemeriksaan OPS',managerSave:'Memperbarui quotation saat pemeriksaan Manager',approve:'OPS menyetujui · menunggu Manager',reject:'Menolak pengajuan',return:'Mengembalikan ke pembuat',managerApprove:'Manager menyetujui quotation',managerReturn:'Manager mengembalikan ke pembuat',managerReject:'Manager menolak quotation',reopen:'Membatalkan persetujuan · membuka ulang pemeriksaan OPS',comment:'Mengirim komentar'};
export async function costApprovalRoute(env:Env,u:User,path:string,method:string,b:any){
 const id=decodeURIComponent(path.slice('/api/cost-approvals'.length).replace(/^\//,''));
 if(!id){const rows=(await env.DB.prepare(`SELECT o.*,q.created_at AS quote_created_at,q.owner_id,(SELECT COUNT(*) FROM notifications n WHERE n.quote_id=o.quote_id AND n.user_id=? AND n.read_at IS NULL AND (n.id LIKE 'comment:%' OR n.message LIKE '%: Mengirim komentar%')) AS unread_comments,json_extract(r.input_json,'$.trip') AS trip,json_extract(r.input_json,'$.customer') AS customer,u.name AS requester FROM ops_requests o JOIN quotations q ON q.id=o.quote_id JOIN revisions r ON r.quote_id=q.id AND r.revision=q.current_revision JOIN users u ON u.id=o.requester_id WHERE json_extract(o.context,'$.kind')='cost-approval' AND o.id=(SELECT latest.id FROM ops_requests latest WHERE latest.quote_id=q.id AND json_extract(latest.context,'$.kind')='cost-approval' ORDER BY latest.updated_at DESC,latest.id DESC LIMIT 1) AND ${approvalParticipantSQL('q.owner_id','o.context','o.response',u.roles.includes('Admin'))} AND NOT EXISTS (SELECT 1 FROM audit_events a WHERE a.entity_id=q.id AND a.action='quote.delete') ORDER BY o.updated_at DESC`).bind(u.id,u.id,u.id,u.id,u.id).all()).results as any[];return rows.map(row=>({...row,context:JSON.stringify({...JSON.parse(row.context),archived:approvalArchived(row)})}));}
 if(method==='GET'){
  const version=await getQuoteVersion(env.DB,id);
  const review:any=await env.DB.prepare("SELECT status,response FROM ops_requests WHERE quote_id=? AND json_extract(context,'$.kind')='cost-approval' ORDER BY updated_at DESC LIMIT 1").bind(id).first();
  return {status:review?.status||'Draft',history:review?.response?JSON.parse(review.response):[],revision:version.current_revision};
 }
 const q=await getQuote(env.DB,id);const ops=u.roles.some(r=>['OPS','Admin'].includes(r));const tc=((u.roles.some(r=>['TC','OPS','Finance'].includes(r))||(u.roles.includes('Director')&&u.can_edit))&&u.id===q.owner_id)||u.roles.includes('Admin');
 const owner:any=await env.DB.prepare('SELECT roles,(SELECT username FROM login_credentials WHERE user_id=users.id) AS username FROM users WHERE id=?').bind(q.owner_id).first();
 const ownerRoles:string[]=owner?JSON.parse(owner.roles):[];
 const adminOwned=ownerRoles.includes('Admin');
 if(b.action==='submit'&&adminOwned&&b.managerReviewerId)fail(422,'Quotation Admin harus diajukan ke OPS terlebih dahulu.');
 const directManager=!adminOwned&&(!!b.managerReviewerId||(!b.opsReviewerId&&ownerRoles.includes('OPS')&&!ownerRoles.includes('Finance')));
 const manager=u.roles.some(r=>['Director','Admin'].includes(r));
 const row:any=await env.DB.prepare("SELECT * FROM ops_requests WHERE quote_id=? AND json_extract(context,'$.kind')='cost-approval' ORDER BY updated_at DESC LIMIT 1").bind(id).first();
 const history=row?.response?JSON.parse(row.response):[];
 const context=row?.context?JSON.parse(row.context):{kind:'cost-approval'};

 if(b.action==='read'){
  const ids=z.array(z.string()).max(500).parse(b.commentIds||[]);
  const shown=history.filter((e:any)=>e.action==='comment'&&e.message&&ids.includes(e.id));
  if(shown.length)await env.DB.prepare("UPDATE notifications SET read_at=? WHERE user_id=? AND quote_id=? AND read_at IS NULL AND (id IN (SELECT value FROM json_each(?)) OR (id NOT LIKE 'comment:%' AND message LIKE '%: Mengirim komentar%' AND created_at IN (SELECT value FROM json_each(?))))").bind(now(),u.id,id,JSON.stringify(shown.map((e:any)=>'comment:'+e.id+':'+u.id)),JSON.stringify(shown.map((e:any)=>e.time))).run();
  return {read:true};
 }
 if(!ops&&!tc&&!manager&&b.action!=='comment')fail(403,'Tidak diizinkan.');
 if(b.action==='archive'||b.action==='restore'){
 if(!row)fail(404,'Pengajuan tidak ditemukan.');
 const submitted=[...history].reverse().find((e:any)=>e.action==='managerApprove');
 if(b.action==='archive'&&(row.status!=='ManagerApproved'||!submitted||Date.now()-Date.parse(submitted.time)<20*86400000))fail(422,'Arsip tersedia 20 hari setelah persetujuan akhir selesai.');
 const context={...JSON.parse(row.context),archived:b.action==='archive',archiveRestoredAt:b.action==='restore'?now():undefined};
 await env.DB.prepare('UPDATE ops_requests SET context=? WHERE id=?').bind(JSON.stringify(context),row.id).run();
 return {archived:context.archived};
 }
 const action=z.enum(['submit','cancel','save','approve','return','reject','managerApprove','managerReturn','managerReject','managerSave','reopen','comment']).parse(b.action);
 const message=action==='comment'?z.string().max(4000).parse(b.message||'').trim():'';
 if(b.expectedRevision!==q.current_revision)fail(409,'Quotation sudah berubah. Buka versi terbaru sebelum melanjutkan.');
 if(['submit','cancel'].includes(action)&&!tc)fail(403,'Hanya pemilik quotation atau Admin.');
 if(['save','approve','return','reject'].includes(action)&&!ops)fail(403,'Hanya OPS atau Admin.');
 if(action==='submit'&&['ApprovalWaiting','ManagerWaiting','ApprovalApproved'].includes(row?.status))fail(409,'Pengajuan masih menunggu pemeriksaan.');
 if(['save','approve','return','reject'].includes(action)&&row?.status!=='ApprovalWaiting')fail(409,'Pengajuan sudah tidak menunggu OPS.');
 if(action==='reopen'&&!(ops||manager))fail(403,'Hanya OPS atau Manager.');
 if(action==='reopen'&&!ops&&manager&&row?.status!=='ManagerApproved')fail(409,'Manager belum menyetujui quotation ini.');
 if(action==='reopen'&&!['ManagerWaiting','ApprovalApproved','ManagerApproved'].includes(row?.status))fail(409,'Belum ada persetujuan yang dapat dibatalkan.');
 if(action==='cancel'&&!['ApprovalWaiting','ManagerWaiting','ApprovalApproved'].includes(row?.status))fail(409,'Tidak ada pengajuan yang menunggu pemeriksaan.');
 if(action.startsWith('manager')&&!manager)fail(403,'Hanya Manager atau Admin.');
 if(action.startsWith('manager')&&!['ManagerWaiting','ApprovalApproved'].includes(row?.status))fail(409,'Quotation harus disetujui OPS terlebih dahulu.');
 if(action==='managerApprove'&&!q.result.complete)fail(422,'Lengkapi quotation sebelum persetujuan Manager.');
 if((action==='comment')&&!message)fail(422,'Tulis pesan terlebih dahulu.');
 if(adminOwned&&u.id===q.owner_id&&['approve','return','reject','managerApprove','managerReturn','managerReject'].includes(action))fail(403,'Pemilik quotation harus menunggu keputusan reviewer yang ditunjuk.');
 if(!u.roles.includes('Admin')){
  if(['save','approve','return','reject'].includes(action)&&context.opsReviewerId&&context.opsReviewerId!==u.id)fail(403,'Pengajuan ini ditujukan ke OPS lain.');
  if(action.startsWith('manager')&&context.managerReviewerId&&context.managerReviewerId!==u.id)fail(403,'Pengajuan ini ditujukan ke Manager lain.');
 }
 async function reviewer(role:string,id:unknown){
  const eligible=(await env.DB.prepare("SELECT id,name FROM users WHERE active=1 AND EXISTS(SELECT 1 FROM json_each(users.roles) WHERE value=?)").bind(role).all()).results as any[];
  const chosen=id?eligible.find(r=>r.id===id):eligible.length===1?eligible[0]:undefined;
  if(!chosen)fail(422,'Pilih '+(role==='OPS'?'OPS':'Manager')+' penerima pengajuan.');return chosen;
 }
 if(action==='submit'){
  delete context.archiveRestoredAt;
  delete context.managerReviewerId;delete context.managerReviewerName;
  if(directManager){const target=await reviewer('Director',b.managerReviewerId);context.managerReviewerId=target.id;context.managerReviewerName=target.name;}
  if(!directManager){const target=await reviewer('OPS',b.opsReviewerId);context.opsReviewerId=target.id;context.opsReviewerName=target.name;}
  else if(ownerRoles.includes('OPS')){context.opsReviewerId=q.owner_id;context.opsReviewerName=q.owner_name;}
  else{delete context.opsReviewerId;delete context.opsReviewerName;}
  context.directToManager=directManager;
 }
 if(action==='approve'){context.directToManager=false;const target=await reviewer('Director',b.managerReviewerId||context.managerReviewerId);context.managerReviewerId=target.id;context.managerReviewerName=target.name;}
 let returnTarget:any=null;
 if(action==='managerReturn'){
  if(!b.returnRecipientId)fail(422,'Pilih penerima pengembalian.');
  returnTarget=b.returnRecipientId===q.owner_id?{id:q.owner_id,name:q.owner_name}:await reviewer('OPS',b.returnRecipientId);
  if(returnTarget.id!==q.owner_id){context.directToManager=false;context.opsReviewerId=returnTarget.id;context.opsReviewerName=returnTarget.name;}
 }
 let input=q.input;
 if(action==='save'||action==='managerSave'||action==='approve'){
  const lines=z.array(Line).max(500).parse(b.input?.lines??b.lines??q.input.lines);
  // Assigned OPS may revise the full quotation during its review stage.
  input=b.input?QuoteInput.parse(b.input):{...q.input,lines};
  if(action==='approve'&&(!lines.length||lines.some(l=>l.included&&l.unitPrice===null)))fail(422,'Lengkapi harga biaya sebelum menyetujui.');
 }
 if(action==='submit'&&directManager&&(!q.input.lines.length||q.input.lines.some((l:any)=>l.included&&l.unitPrice===null)))fail(422,'Lengkapi harga biaya sebelum mengajukan ke Manager.');
 const status=action==='reopen'?'ApprovalWaiting':action==='submit'?(directManager?'ManagerWaiting':'ApprovalWaiting'):action==='cancel'?'ApprovalCancelled':action==='return'?'ApprovalReturned':action==='reject'?'ApprovalRejected':action==='approve'?'ManagerWaiting':action==='managerApprove'?'ManagerApproved':action==='managerReturn'?(returnTarget.id===q.owner_id?'ManagerReturned':'ApprovalWaiting'):action==='managerReject'?'ManagerRejected':row?.status||'Draft';
 const time=now(),requestId=crypto.randomUUID(),reviewId=row?.id||crypto.randomUUID();
 const mentionNames=action==='comment'?Array.from(message.matchAll(/@([a-zA-Z0-9._-]+)/g),m=>m[1].toLowerCase()):[];
 const directory=mentionNames.length?(await env.DB.prepare("SELECT c.user_id,c.username,u.name,u.roles FROM login_credentials c JOIN users u ON u.id=c.user_id WHERE u.active=1").all()).results as any[]:[];
 const mentions=directory.filter(r=>mentionNames.includes(r.username.toLowerCase())).map(r=>({userId:r.user_id,username:r.username,name:r.name}));
 const mentionedIds=mentions.map(r=>r.userId);
 const event={id:requestId,actor:u.name,actorId:u.id,actorRoles:u.roles,quotationId:id,mentions,opsReviewerId:context.opsReviewerId,managerReviewerId:context.managerReviewerId,returnRecipientId:returnTarget?.id,recipientName:action==='managerReturn'?returnTarget.name:action==='submit'?(directManager?context.managerReviewerName:context.opsReviewerName):action==='approve'?context.managerReviewerName:['return','reject','managerReturn','managerReject'].includes(action)?q.owner_name:undefined,action,label:action==='managerReturn'?'Manager mengembalikan untuk revisi':action==='submit'&&directManager?'Mengajukan quotation langsung ke Manager':approvalEventLabels[action],message,time,revision:q.current_revision+1};
 const statements=[];
 if(row)statements.push(env.DB.prepare('UPDATE ops_requests SET status=?,response=?,revision=?,updated_at=?,context=? WHERE id=?').bind(status,JSON.stringify([...history,event]),q.current_revision+1,time,JSON.stringify({...context,...(action==='comment'?{}:{archived:false})}),reviewId));
 else statements.push(env.DB.prepare('INSERT INTO ops_requests VALUES(?,?,?,?,?,?,?,?,?)').bind(reviewId,id,q.current_revision+1,q.owner_id,null,status,JSON.stringify(context),JSON.stringify([event]),time));
 // Requests go only to their named reviewer. Updates/comments go to actual participants.
 const participants=[q.owner_id,context.opsReviewerId,context.managerReviewerId].filter(Boolean);
 const reviewRecipients=action==='submit'?[directManager?context.managerReviewerId:context.opsReviewerId]:action==='approve'?[context.managerReviewerId]:action==='managerReturn'?[returnTarget.id]:['return','reject','managerReject','managerApprove'].includes(action)?[q.owner_id]:action==='comment'?[...participants,...mentionedIds]:participants;
 const recipients=[...new Set(reviewRecipients)].filter(recipient=>recipient&&recipient!==u.id);
 for(const recipient of recipients)statements.push(env.DB.prepare('INSERT INTO notifications VALUES(?,?,?,?,?,?)').bind(action==='comment'?'comment:'+requestId+':'+recipient:crypto.randomUUID(),recipient,id,`${mentionedIds.includes(recipient)?'Menyebut Anda · ':''}${q.input.trip} · ${u.name}: ${approvalEventLabels[action]}${message?' — '+message:''}`,null,time));
 const emailStatements=action==='comment'?await mentionEmailStatements(env,u,q,event):[];
 statements.push(...emailStatements);
 const saved=await saveQuote(env,u,{input,status:action==='managerApprove'?'Sent':q.status,expectedRevision:q.current_revision,requestId},id,{statements});
 return {...saved,emailQueued:emailStatements.length};
}
