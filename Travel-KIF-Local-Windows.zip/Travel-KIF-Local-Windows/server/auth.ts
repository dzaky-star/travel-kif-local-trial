import {sessionUser} from "./login";
import { createRemoteJWKSet, jwtVerify } from "jose";
export interface Env {
  DB: D1Database;
  RESEND_API_KEY?: string;
  PUBLIC_APP_URL?: string;
  ASSETS: Fetcher;
  APP_ENV: string;
  ACCESS_TEAM_DOMAIN?: string;
  ACCESS_AUD?: string;
  GOOGLE_SERVICE_ACCOUNT_JSON?: string;
  GOOGLE_OUTPUT_SPREADSHEET_ID?: string;
  GOOGLE_INPUT_SPREADSHEET_ID?: string;
  GEMINI_API_KEY?: string;
  AI_MAX_CONCURRENT?: string;
  GEMINI_MODEL?: string;
  GEMINI_FALLBACK_MODEL?: string;
  TAVILY_API_KEY?: string;
  OPENAI_API_KEY?: string;
  OPENAI_MODEL?: string;
  AI_DAILY_REQUEST_LIMIT?: string;
}
export type User = {
  id: string;
  email: string;
  name: string;
  roles: string[];
  can_edit: number;
};
export class HttpError extends Error {
  constructor(
    public status: number,
    message: string,
  ) {
    super(message);
  }
}
export const fail = (status: number, message: string): never => {
  throw new HttpError(status, message);
};
export function local(request: Request, env: Env) {
  return (
    env.APP_ENV === "local" &&
    ["localhost", "127.0.0.1", "[::1]"].includes(new URL(request.url).hostname)
  );
}
export async function authenticate(request: Request, env: Env): Promise<User> {
  const account=await sessionUser(request,env);
  if(account)return account;
  let row: any;
  if (local(request, env)) {
    fail(401,"Silakan masuk.");
  } else {
    if (!env.ACCESS_TEAM_DOMAIN || !env.ACCESS_AUD)
      fail(401, "Silakan masuk.");
    const token = request.headers.get("Cf-Access-Jwt-Assertion");
    if (!token) fail(401, "Login melalui Cloudflare Access diperlukan.");
    try {
      const issuer = env.ACCESS_TEAM_DOMAIN!.replace(/\/$/, "");
      const keys = createRemoteJWKSet(
        new URL(issuer + "/cdn-cgi/access/certs"),
      );
      const { payload } = await jwtVerify(token!, keys, {
        issuer,
        audience: env.ACCESS_AUD,
      });
      row = await env.DB.prepare(
        "SELECT * FROM users WHERE email=? AND active=1",
      )
        .bind(payload.email)
        .first();
    } catch {
      fail(401, "Sesi tidak valid.");
    }
  }
  if (!row) fail(403, "Pengguna belum diberi akses.");
  return { ...row, roles: JSON.parse(row.roles) };
}
export function requireRoles(u: User, ...roles: string[]) {
  if (!u.roles.some((r) => roles.includes(r)))
    fail(403, "Hak akses tidak mengizinkan tindakan ini.");
}
export function canEdit(u: User, owner: string) {
  return (
    u.roles.includes("Admin") ||
    (u.roles.some(r=>["TC","OPS","Finance"].includes(r)) && u.id === owner) ||
    (u.roles.includes("Director") && !!u.can_edit)
  );
}
export function csrf(request: Request) {
  if (!["GET", "HEAD", "OPTIONS"].includes(request.method)) {
    const origin = request.headers.get("Origin");
    if (origin !== new URL(request.url).origin)
      fail(403, "Origin permintaan tidak valid.");
    if (!request.headers.get("Content-Type")?.startsWith("application/json"))
      fail(415, "Gunakan JSON.");
  }
}
export async function body(request: Request) {
  if (Number(request.headers.get("content-length") || 0) > 2e6)
    fail(413, "Data terlalu besar.");
  const raw = await request.text();
  if (raw.length > 2e6) fail(413, "Data terlalu besar.");
  try {
    return JSON.parse(raw);
  } catch {
    fail(400, "JSON tidak valid.");
  }
}
