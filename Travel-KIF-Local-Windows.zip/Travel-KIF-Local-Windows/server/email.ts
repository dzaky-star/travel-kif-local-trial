import {z} from 'zod';
import {type Env,type User,fail,requireRoles} from './auth';
import {audit} from './store';
const zone=z.string().max(80).refine(v=>{try{new Intl.DateTimeFormat('en',{timeZone:v});return true;}catch{return false;}});
const email=z.string().email().max(254).refine(v=>!/[\r\n]/.test(v)&&!v.endsWith('.invalid'));
const optionalEmail=z.union([email,z.literal('')]);
const settingsSchema=z.object({enabled:z.boolean(),sender_email:optionalEmail,sender_name:z.string().min(1).max(100).regex(/^[^<>\r\n]+$/),reply_to:optionalEmail,timezone:zone,users:z.array(z.object({user_id:z.string().min(1),email:optionalEmail,enabled:z.boolean(),timezone:zone})).max(200)});
const escape=(s:unknown)=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]!));
const origin=(env:Env)=>{const value=env.PUBLIC_APP_URL||'https://travel-kif-quotation-workspace.travelkif.workers.dev';const url=new URL(value);if(url.protocol!=='https:')throw Error('Email links require HTTPS');return url.origin;};
export function mentionEmail(env:Env,settings:any,data:{name:string;actor:string;trip:string;client:string;quoteId:string;message:string;time:string;timezone:string}){
 const root=origin(env),link=root+'/?page=Quotations&quote='+encodeURIComponent(data.quoteId)+'&discussion=1';
 const date=new Intl.DateTimeFormat('en-GB',{dateStyle:'medium',timeStyle:'short',timeZone:data.timezone}).format(new Date(data.time))+' ('+data.timezone+')';
 const text=`Hi ${data.name},\n\n${data.actor} mentioned you on a quotation.\n\nTrip: ${data.trip}\n${link}\nClient: ${data.client}\nDate and time: ${date}\n\n${data.message}\n\nThis email was sent by Travel KIF Quotation Workbook.`;
 const html=`<!doctype html><html><body style="margin:0;background:#f3f8fb;font-family:Arial,sans-serif;color:#234252"><table role="presentation" width="100%" cellpadding="0" cellspacing="0"><tr><td style="padding:28px 12px"><table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="max-width:600px;margin:auto;background:white;border:1px solid #dce7ed;border-radius:12px"><tr><td style="padding:30px 24px;text-align:center;background:#123348;border-radius:12px 12px 0 0"><img src="${root}/travel-kif-logo.png" alt="Travel KIF" width="190" style="max-width:100%;height:auto"><p style="color:#b9d8e6;font-size:13px;letter-spacing:2px;margin:12px 0 0">QUOTATION WORKBOOK</p></td></tr><tr><td style="padding:28px 24px"><p>Hi ${escape(data.name)},</p><h2 style="font-size:22px;line-height:1.4">${escape(data.actor)} mentioned you on a quotation.</h2><p style="line-height:1.8"><strong>Trip:</strong> <a href="${escape(link)}" style="color:#087fa6">${escape(data.trip)}</a><br><strong>Client:</strong> ${escape(data.client)}<br><strong>Date and time:</strong> ${escape(date)}</p><div style="background:#edf7fc;border-left:4px solid #34bce7;border-radius:6px;padding:18px;white-space:pre-wrap;overflow-wrap:anywhere;line-height:1.6">${escape(data.message)}</div><p style="font-size:12px;color:#657e8a;margin-top:28px">This email was sent by Travel KIF Quotation Workbook.</p></td></tr></table></td></tr></table></body></html>`;
 return {from:`${settings.sender_name} <${settings.sender_email}>`,subject:`${data.actor.replace(/[\r\n]/g,' ')} mentioned you · ${data.trip.replace(/[\r\n]/g,' ').slice(0,160)}`,html,text,...(settings.reply_to?{reply_to:settings.reply_to}:{})};
}
export async function emailAdmin(env:Env,u:User,method:string,b:any={}){
 requireRoles(u,'Admin');
 if(method==='PUT'){
  const parsed=settingsSchema.safeParse(b);if(!parsed.success)fail(422,'Periksa alamat email dan zona waktu yang diisi.');const value=parsed.data!;
  if(new Set(value.users.map(x=>x.user_id)).size!==value.users.length)fail(422,'Duplicate email recipients.');
  if(value.enabled&&(!env.RESEND_API_KEY||!value.sender_email))fail(422,'Konfigurasi layanan dan alamat pengirim email belum lengkap.');
  if(value.users.some(x=>x.enabled&&!x.email))fail(422,'Alamat email penerima wajib diisi.');
  const ids=(await env.DB.prepare('SELECT id FROM users WHERE active=1').all()).results as any[];
  if(value.users.some(x=>!ids.some(y=>y.id===x.user_id)))fail(422,'Pengguna tidak tersedia.');
  await env.DB.batch([env.DB.prepare('UPDATE email_settings SET enabled=?,sender_email=?,sender_name=?,reply_to=?,timezone=? WHERE id=1').bind(+value.enabled,value.sender_email,value.sender_name,value.reply_to,value.timezone),...value.users.map(x=>env.DB.prepare('INSERT INTO email_preferences(user_id,email,enabled,timezone) VALUES(?,?,?,?) ON CONFLICT(user_id) DO UPDATE SET email=excluded.email,enabled=excluded.enabled,timezone=excluded.timezone').bind(x.user_id,x.email,+x.enabled,x.timezone)),audit(env.DB,u,'email.settings','email','Updated email delivery settings')]);
 }
 if(!['GET','PUT'].includes(method))fail(405,'Metode tidak tersedia.');
 const settings:any=await env.DB.prepare('SELECT * FROM email_settings WHERE id=1').first();
 const users=(await env.DB.prepare("SELECT u.id user_id,u.name,c.username,COALESCE(p.email,CASE WHEN u.email LIKE '%.invalid' THEN '' ELSE u.email END) email,COALESCE(p.enabled,0) enabled,COALESCE(p.timezone,?) timezone FROM users u JOIN login_credentials c ON c.user_id=u.id LEFT JOIN email_preferences p ON p.user_id=u.id WHERE u.active=1 ORDER BY u.name").bind(settings.timezone).all()).results;
 const deliveries=(await env.DB.prepare('SELECT id,recipient_email,status,attempts,created_at,sent_at,last_error FROM email_outbox ORDER BY created_at DESC LIMIT 25').all()).results;
 return {settings,users,deliveries,configured:!!env.RESEND_API_KEY,provider:'Resend',preview:mentionEmail(env,settings,{name:'Joseph',actor:'Hani',trip:'Example quotation',client:'Example client',quoteId:'preview',message:'@joseph, approved',time:new Date().toISOString(),timezone:settings.timezone}).html};
}
// Insert these statements in the same transaction as the comment: never mail an unsaved message.
export async function mentionEmailStatements(env:Env,u:User,q:any,event:any){
 const targets=[...new Set(event.mentions.map((m:any)=>m.userId))].filter(id=>id!==u.id);
 if(!targets.length||!env.RESEND_API_KEY)return [];
 const settings:any=await env.DB.prepare('SELECT * FROM email_settings WHERE id=1').first();if(!settings?.enabled||!settings.sender_email)return [];
 const recipients=(await env.DB.prepare('SELECT p.*,u.name FROM email_preferences p JOIN users u ON u.id=p.user_id WHERE p.enabled=1 AND u.active=1 AND p.user_id IN (SELECT value FROM json_each(?))').bind(JSON.stringify(targets)).all()).results as any[];
 return recipients.filter(r=>email.safeParse(r.email).success).map(r=>{
  const payload={...mentionEmail(env,settings,{name:r.name,actor:u.name,trip:q.input.trip,client:q.input.customer,quoteId:q.id,message:event.message,time:event.time,timezone:r.timezone||settings.timezone}),to:[r.email]};
  return env.DB.prepare('INSERT OR IGNORE INTO email_outbox(id,event_id,quote_id,recipient_id,recipient_email,payload,next_attempt,created_at) VALUES(?,?,?,?,?,?,?,?)').bind('mention:'+event.id+':'+r.user_id,event.id,q.id,r.user_id,r.email,JSON.stringify(payload),event.time,event.time);
 });
}
export async function deliverMentionEmails(env:Env,fetcher:typeof fetch=fetch){
 if(!env.RESEND_API_KEY)return;
 const settings:any=await env.DB.prepare('SELECT enabled FROM email_settings WHERE id=1').first();if(!settings?.enabled)return;
 const time=new Date().toISOString();
 const rows=(await env.DB.prepare("SELECT id FROM email_outbox WHERE status IN ('pending','sending') AND next_attempt<=? ORDER BY next_attempt LIMIT 10").bind(time).all()).results as any[];
 for(const candidate of rows){
  const job:any=await env.DB.prepare("UPDATE email_outbox SET status='sending',attempts=attempts+1,first_attempt=COALESCE(first_attempt,?),next_attempt=? WHERE id=? AND status IN ('pending','sending') AND next_attempt<=? RETURNING *").bind(time,new Date(Date.now()+120000).toISOString(),candidate.id,time).first();if(!job)continue;
  // Retries never exceed the provider's 24-hour idempotency window.
  if(job.attempts>5||Date.now()-Date.parse(job.first_attempt)>20*3600000){await env.DB.prepare("UPDATE email_outbox SET status='failed',last_error='Retry window ended; review delivery before resending.' WHERE id=?").bind(job.id).run();continue;}
  const allowed=await env.DB.prepare("SELECT p.user_id FROM email_preferences p JOIN users u ON u.id=p.user_id WHERE p.user_id=? AND p.enabled=1 AND p.email=? AND u.active=1 AND NOT EXISTS (SELECT 1 FROM audit_events WHERE entity_id=? AND action='quote.delete')").bind(job.recipient_id,job.recipient_email,job.quote_id).first();
  if(!allowed){await env.DB.prepare("UPDATE email_outbox SET status='cancelled',last_error='Recipient settings changed.' WHERE id=?").bind(job.id).run();continue;}
  try{
   const response=await fetcher('https://api.resend.com/emails',{method:'POST',headers:{Authorization:'Bearer '+env.RESEND_API_KEY,'Content-Type':'application/json','Idempotency-Key':job.id},body:job.payload,signal:AbortSignal.timeout(15000)});
   if(!response.ok){const retry=response.status===429||response.status>=500;await env.DB.prepare('UPDATE email_outbox SET status=?,next_attempt=?,last_error=? WHERE id=?').bind(retry&&job.attempts<5?'pending':'failed',new Date(Date.now()+Math.min(3600000,60000*2**job.attempts)).toISOString(),'Email provider HTTP '+response.status,job.id).run();continue;}
   const result:any=await response.json();
   await env.DB.prepare("UPDATE email_outbox SET status='sent',sent_at=?,provider_id=?,last_error=NULL WHERE id=?").bind(new Date().toISOString(),String(result.id||''),job.id).run();
  }catch{
   await env.DB.prepare("UPDATE email_outbox SET status=?,next_attempt=?,last_error='Delivery not confirmed; retry uses the same idempotency key.' WHERE id=?").bind(job.attempts<5?'pending':'failed',new Date(Date.now()+600000).toISOString(),job.id).run();
  }
 }
}
